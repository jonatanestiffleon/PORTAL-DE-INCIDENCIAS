"use strict";

const Datos = (() => {
  // Esta es la clave original del aula. Cambiarla ocultaría los reportes guardados.
  const clave = "unas.bitacora-aula.equipo1.incidentes.v1";
  const tipos = ["Phishing", "Malware", "Acceso indebido", "Pérdida de equipo", "Otro"];
  const severidades = ["Baja", "Media", "Alta", "Crítica"];
  const estados = ["Nuevo", "En análisis", "Cerrado"];
  const campos = ["titulo", "tipo", "severidad", "fecha", "descripcion", "alias"];

  function texto(valor) {
    return typeof valor === "string" ? valor.trim() : "";
  }

  // El campo de fecha del formulario usa la hora local.
  function fechaLocal(fecha) {
    const dos = numero => String(numero).padStart(2, "0");
    return fecha.getFullYear() + "-" + dos(fecha.getMonth() + 1) + "-" + dos(fecha.getDate())
      + "T" + dos(fecha.getHours()) + ":" + dos(fecha.getMinutes());
  }

  function validar(datos) {
    const errores = {};
    const titulo = texto(datos.titulo);
    const descripcion = texto(datos.descripcion);
    const alias = texto(datos.alias);
    const fecha = new Date(datos.fecha);
    if (titulo.length < 3 || titulo.length > 80) errores.titulo = "Escribe entre 3 y 80 caracteres.";
    if (!tipos.includes(datos.tipo)) errores.tipo = "Selecciona un tipo de incidente.";
    if (!severidades.includes(datos.severidad)) errores.severidad = "Selecciona la severidad.";
    if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(datos.fecha) || fechaLocal(fecha) !== datos.fecha) {
      errores.fecha = "Ingresa una fecha y hora válidas.";
    } else if (fecha.getTime() > Date.now()) {
      errores.fecha = "El incidente debe haber ocurrido antes de la hora actual o en este mismo minuto.";
    }
    if (descripcion.length < 20 || descripcion.length > 500) {
      errores.descripcion = "Describe lo ocurrido en 20 a 500 caracteres.";
    }
    if (!alias || alias.length > 40) errores.alias = "Usa un alias ficticio de 1 a 40 caracteres.";
    return errores;
  }

  function leerTexto() {
    try {
      return localStorage.getItem(clave);
    } catch {
      throw new Error("El navegador bloqueó el almacenamiento. Permite guardar datos para este sitio.");
    }
  }

  function leerBase(contenido) {
    if (contenido === null) return { siguiente: 1, ejemplosCargados: false, registros: [] };
    try {
      const base = JSON.parse(contenido);
      if (!Array.isArray(base.registros) || !Number.isSafeInteger(base.siguiente) || base.siguiente < 1
        || typeof base.ejemplosCargados !== "boolean") throw new Error();
      const ids = new Set();
      for (const fila of base.registros) {
        if (!/^INC-\d{3,}$/.test(fila.id) || ids.has(fila.id) || Number(fila.id.slice(4)) >= base.siguiente
          || !estados.includes(fila.estado) || !tipos.includes(fila.tipo) || !severidades.includes(fila.severidad)
          || !campos.every(campo => typeof fila[campo] === "string")) throw new Error();
        ids.add(fila.id);
      }
      return base;
    } catch {
      throw new Error("No se pudieron leer los incidentes guardados en este navegador.");
    }
  }

  function listar() {
    return leerBase(leerTexto()).registros;
  }

  // Antes de guardar comprobamos si otra pestaña cambió los datos.
  function modificar(accion) {
    const antes = leerTexto();
    const base = leerBase(antes);
    const resultado = accion(base);
    if (leerTexto() !== antes) throw new Error("Hubo un cambio en otra pestaña. Recarga y vuelve a intentar.");
    try {
      localStorage.setItem(clave, JSON.stringify(base));
    } catch {
      throw new Error("No se pudo guardar el cambio. Comprueba el espacio disponible y los permisos del navegador.");
    }
    return resultado;
  }

  function buscar(base, id, original) {
    const fila = base.registros.find(registro => registro.id === id);
    if (!fila) throw new Error("El incidente ya no existe. Vuelve a la tabla.");
    if (original && [...campos, "estado"].some(campo => fila[campo] !== original[campo])) {
      throw new Error("El incidente cambió en otra pestaña. Recarga para ver la versión actual.");
    }
    return fila;
  }

  function agregar(base, valores, estado) {
    const id = "INC-" + String(base.siguiente).padStart(3, "0");
    const fila = { id, ...valores, estado };
    base.siguiente++;
    base.registros.push(fila);
    return fila;
  }

  function guardar(datos, id, original) {
    const errores = validar(datos);
    const mensajes = Object.values(errores);
    if (mensajes.length) throw new Error(mensajes[0]);
    const valores = {};
    for (const campo of campos) valores[campo] = texto(datos[campo]);
    return modificar(base => {
      if (!id) return agregar(base, valores, estados[0]);
      const fila = buscar(base, id, original);
      return Object.assign(fila, valores);
    });
  }

  function avanzar(id, original) {
    return modificar(base => {
      const fila = buscar(base, id, original);
      if (fila.estado === "Cerrado") throw new Error("El caso ya está cerrado.");
      fila.estado = estados[estados.indexOf(fila.estado) + 1];
      return fila;
    });
  }

  function eliminar(id, original) {
    return modificar(base => {
      buscar(base, id, original);
      base.registros = base.registros.filter(fila => fila.id !== id);
    });
  }

  // Casos ficticios para la práctica.
  const ejemplos = [
    ["Solicitud de clave por correo", "Phishing", "Crítica", "Nuevo", "Llegó un correo que pedía la contraseña del aula para seguir usando la cuenta."],
    ["Memoria USB en cuarentena", "Malware", "Alta", "En análisis", "Al conectar una memoria USB a la PC 4, el antivirus envió uno de los archivos a cuarentena."],
    ["Sesión desconocida en el aula", "Acceso indebido", "Alta", "Nuevo", "Apareció una sesión abierta en la cuenta del aula a una hora en que el laboratorio estaba cerrado."],
    ["Tableta ausente del inventario", "Pérdida de equipo", "Media", "En análisis", "Al devolver los equipos después de clase, faltaba una tableta en el estante."],
    ["Aviso repetido del filtro", "Otro", "Baja", "Cerrado", "El filtro del laboratorio mostró dos veces la misma alerta al abrir un archivo."],
    ["Carpeta con archivos alterados", "Malware", "Crítica", "En análisis", "Al abrir la carpeta de la práctica, encontramos varios archivos con otra extensión que ya no abrían."],
    ["Permisos de lectura inesperados", "Acceso indebido", "Media", "En análisis", "Desde la cuenta de invitado se podía leer una carpeta reservada para evaluaciones."],
    ["Invitación a una beca ficticia", "Phishing", "Media", "Cerrado", "Llegó un correo sobre una beca. La dirección del remitente era distinta de la que figuraba en el aviso de la universidad."],
    ["Mouse de préstamo extraviado", "Pérdida de equipo", "Baja", "Nuevo", "Después de la práctica faltaba el mouse que se había prestado junto con la laptop."],
    ["Alerta de protección detenida", "Otro", "Alta", "Nuevo", "Al encender la PC del laboratorio apareció un aviso de que el antivirus estaba desactivado."],
    ["Archivo de ensayo bloqueado", "Malware", "Baja", "Cerrado", "Durante la práctica, el antivirus bloqueó un archivo antes de que pudiéramos abrirlo."],
    ["Intentos fuera de horario", "Acceso indebido", "Media", "Nuevo", "En el registro de anoche aparecen varios intentos de iniciar sesión después del cierre del laboratorio."]
  ];

  function cargarEjemplos() {
    return modificar(base => {
      if (base.ejemplosCargados) return 0;
      ejemplos.forEach(([titulo, tipo, severidad, estado, descripcion], indice) => {
        const fecha = fechaLocal(new Date(Date.now() - (indice + 1) * 3600000));
        const alias = "aula-" + String(indice + 1).padStart(2, "0");
        agregar(base, { titulo, tipo, severidad, fecha, descripcion, alias }, estado);
      });
      base.ejemplosCargados = true;
      return ejemplos.length;
    });
  }

  function exportar() {
    return JSON.stringify(listar(), null, 2);
  }

  return { tipos, severidades, estados, listar, validar, guardar, avanzar, eliminar, cargarEjemplos, exportar };
})();
