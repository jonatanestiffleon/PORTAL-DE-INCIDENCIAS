"use strict";

function inicioReporte() {
  const formulario = document.getElementById("form-reporte");
  if (!formulario) return;

  const porId = id => document.getElementById(id);
  const controles = formulario.elements;
  const plantilla = porId("reporte-plantilla");
  const guardado = porId("reporte-guardado");
  const campos = ["titulo", "tipo", "severidad", "fecha", "alias", "descripcion"];
  const consulta = new URLSearchParams(location.hash.split("?")[1] || location.search);
  const id = consulta.get("editar");
  let original = null;

  function minutoActual() {
    const ahora = new Date();
    const local = new Date(ahora.getTime() - ahora.getTimezoneOffset() * 60000);
    return local.toISOString().slice(0, 16);
  }

  function leerCampos() {
    return Object.fromEntries(new FormData(formulario));
  }

  function mostrarError(campo, mensaje) {
    controles[campo].setAttribute("aria-invalid", String(Boolean(mensaje)));
    porId("error-" + campo).textContent = mensaje || "";
  }

  for (const tipo of Datos.tipos) controles.tipo.add(new Option(tipo, tipo));
  for (const nivel of Datos.severidades) controles.severidad.add(new Option(nivel, nivel));
  controles.fecha.max = minutoActual();
  controles.fecha.value = controles.fecha.max;
  controles.fecha.addEventListener("focus", () => { controles.fecha.max = minutoActual(); });
  formulario.querySelector("[data-pagina]").href = enlacePagina("incidentes.html");

  // Guardamos una copia para detectar si el reporte cambia en otra pestaña.
  if (id) {
    try {
      original = Datos.listar().find(fila => fila.id === id);
      if (!original) throw new Error("Este incidente ya no está en la lista. Vuelve a Incidentes para elegir otro.");
      campos.forEach(campo => { controles[campo].value = original[campo]; });
      porId("reporte-titulo").textContent = "Editar " + id;
      porId("reporte-subtitulo").textContent = "Corrige los datos y pulsa Guardar cambios.";
      porId("guardar-reporte").textContent = "Guardar cambios";
    } catch (error) {
      porId("guardar-reporte").disabled = true;
      avisar(error.message, true);
      return;
    }
  }

  let plantillas = [];
  try {
    plantillas = Actualizador.plantillas();
    plantillas.forEach((item, indice) => plantilla.add(new Option(item.titulo, String(indice))));
  } catch (error) {
    plantilla.disabled = true;
    avisar(error.message, true);
  }

  plantilla.addEventListener("change", () => {
    if (plantilla.value === "") return;
    const seleccion = plantillas[Number(plantilla.value)];
    const hayBorrador = controles.titulo.value.trim() || controles.descripcion.value.trim() || controles.tipo.value;
    if (hayBorrador && !confirm("¿Reemplazar el título, el tipo y la descripción con esta plantilla?")) {
      plantilla.value = "";
      return;
    }
    for (const campo of ["titulo", "tipo", "descripcion"]) {
      controles[campo].value = seleccion[campo];
      mostrarError(campo, "");
    }
    guardado.hidden = true;
    controles.severidad.focus();
  });

  for (const campo of campos) {
    controles[campo].addEventListener("blur", () => {
      mostrarError(campo, Datos.validar(leerCampos())[campo]);
    });
    controles[campo].addEventListener("input", () => {
      guardado.hidden = true;
      if (controles[campo].getAttribute("aria-invalid") === "true") {
        mostrarError(campo, Datos.validar(leerCampos())[campo]);
      }
    });
  }

  formulario.addEventListener("submit", evento => {
    evento.preventDefault();
    const datos = leerCampos();
    const errores = Datos.validar(datos);
    campos.forEach(campo => mostrarError(campo, errores[campo]));
    const primerError = campos.find(campo => errores[campo]);
    if (primerError) {
      avisar("Revisa los campos marcados.", true);
      controles[primerError].focus();
      return;
    }

    try {
      const registro = Datos.guardar(datos, id, original);
      porId("reporte-resultado").textContent = id
        ? "Se guardaron los cambios de " + registro.id + "."
        : "Se registró " + registro.id + ".";
      porId("reporte-enlace").href = enlacePagina("incidentes.html?ver=" + encodeURIComponent(registro.id));
      if (id) {
        original = registro;
      } else {
        formulario.reset();
        controles.fecha.value = minutoActual();
      }
      guardado.hidden = false;
      porId("reporte-enlace").focus();
    } catch (error) {
      avisar(error.message, true);
    }
  });
}
