"use strict";

function inicioIncidentes() {
  const filas = document.getElementById("inc-filas");
  if (!filas) return;

  const porId = id => document.getElementById(id);
  const buscar = porId("inc-buscar");
  const tipo = porId("inc-tipo");
  const severidad = porId("inc-severidad");
  const estado = porId("inc-estado");
  const orden = porId("inc-orden");
  const detalle = porId("inc-detalle");
  let seleccionado = null;
  const fechaCorta = new Intl.DateTimeFormat("es-PE", { dateStyle: "short", timeStyle: "short" });

  for (const valor of Datos.tipos) tipo.add(new Option(valor, valor));
  for (const valor of Datos.severidades) severidad.add(new Option(valor, valor));
  for (const valor of Datos.estados) estado.add(new Option(valor, valor));

  function normalizar(texto) {
    return texto.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
  }

  // Los críticos van primero, incluso si se ordena por fecha.
  function comparar(a, b) {
    const prioridad = Number(b.severidad === "Crítica") - Number(a.severidad === "Crítica");
    if (prioridad) return prioridad;
    let diferencia;
    if (orden.value.startsWith("severidad")) {
      diferencia = Datos.severidades.indexOf(a.severidad) - Datos.severidades.indexOf(b.severidad);
    } else {
      diferencia = a.fecha.localeCompare(b.fecha);
    }
    if (orden.value.endsWith("desc")) diferencia *= -1;
    return diferencia || b.fecha.localeCompare(a.fecha) || Number(b.id.slice(4)) - Number(a.id.slice(4));
  }

  function crearElemento(etiqueta, texto, clase) {
    const elemento = document.createElement(etiqueta);
    elemento.textContent = texto;
    if (clase) elemento.className = clase;
    return elemento;
  }

  function crearFila(registro) {
    const fila = document.createElement("tr");
    if (registro.severidad === "Crítica") fila.className = "critical-row";
    const titulo = fila.insertCell();
    titulo.append(crearElemento("span", registro.id, "case-id"), crearElemento("strong", registro.titulo, "case-title"));
    fila.insertCell().textContent = registro.tipo;
    const nivel = "badge sev-" + normalizar(registro.severidad);
    fila.insertCell().append(crearElemento("span", registro.severidad, nivel));
    const clasesEstado = { "Nuevo": "state-new", "En análisis": "state-analysis", "Cerrado": "state-closed" };
    fila.insertCell().append(crearElemento("span", registro.estado, "badge " + clasesEstado[registro.estado]));
    fila.insertCell().textContent = fechaCorta.format(new Date(registro.fecha));
    const boton = crearElemento("button", "Ver", "button subtle small");
    boton.type = "button";
    boton.dataset.id = registro.id;
    boton.setAttribute("aria-label", "Ver detalle de " + registro.id);
    fila.insertCell().append(boton);
    return fila;
  }

  function dibujar() {
    try {
      const registros = Datos.listar();
      const texto = normalizar(buscar.value);
      const visibles = registros.filter(item => {
        const contenido = [item.id, item.titulo, item.descripcion, item.alias, item.tipo, item.severidad, item.estado].join(" ");
        return (!tipo.value || item.tipo === tipo.value)
          && (!severidad.value || item.severidad === severidad.value)
          && (!estado.value || item.estado === estado.value)
          && (!texto || normalizar(contenido).includes(texto));
      }).sort(comparar);
      filas.replaceChildren(...visibles.map(crearFila));
      porId("inc-cuenta").textContent = visibles.length + " de " + registros.length + " incidentes";
      porId("inc-limpiar").disabled = !(buscar.value || tipo.value || severidad.value || estado.value);
      porId("inc-exportar").disabled = !registros.length;
      porId("inc-tabla-caja").hidden = !visibles.length;
      porId("inc-vacio").hidden = Boolean(visibles.length);
      porId("inc-vacio-titulo").textContent = registros.length ? "Sin coincidencias" : "Todavía no hay incidentes";
      porId("inc-vacio-texto").textContent = registros.length
        ? "Prueba con otra palabra o limpia los filtros."
        : "Registra un incidente o pulsa Cargar ejemplos.";
    } catch (error) {
      avisar(error.message, true);
    }
  }

  function mostrarDetalle(registro) {
    seleccionado = registro;
    porId("inc-detalle-id").textContent = registro.id;
    porId("inc-detalle-titulo").textContent = registro.titulo;
    for (const campo of ["tipo", "severidad", "estado", "alias", "descripcion"]) {
      porId("det-" + campo).textContent = registro[campo];
    }
    porId("det-fecha").textContent = fechaCorta.format(new Date(registro.fecha));
    porId("det-editar").href = enlacePagina("reportar.html?editar=" + encodeURIComponent(registro.id));
    const avanzar = porId("det-avanzar");
    avanzar.disabled = registro.estado === "Cerrado";
    const etiquetas = { "Nuevo": "Pasar a análisis", "En análisis": "Cerrar incidente", "Cerrado": "Caso cerrado" };
    avanzar.textContent = etiquetas[registro.estado];
    porId("det-aviso").textContent = "";
    if (!detalle.open) detalle.showModal();
  }

  function abrirDetalle(id) {
    try {
      const registro = Datos.listar().find(item => item.id === id);
      if (!registro) throw new Error("Este incidente ya no está en el registro.");
      mostrarDetalle(registro);
    } catch (error) {
      avisar(error.message, true);
    }
  }

  filas.addEventListener("click", evento => {
    const boton = evento.target.closest("button[data-id]");
    if (boton) abrirDetalle(boton.dataset.id);
  });
  porId("cerrar-detalle").addEventListener("click", () => detalle.close());
  porId("det-avanzar").addEventListener("click", () => {
    try {
      const registro = Datos.avanzar(seleccionado.id, seleccionado);
      mostrarDetalle(registro);
      porId("det-aviso").textContent = "El caso ahora figura como «" + registro.estado + "».";
      dibujar();
    } catch (error) {
      porId("det-aviso").textContent = error.message;
    }
  });
  porId("det-eliminar").addEventListener("click", () => {
    if (!confirm("¿Eliminar " + seleccionado.id + "? Esta acción es definitiva.")) return;
    try {
      Datos.eliminar(seleccionado.id, seleccionado);
      detalle.close();
      dibujar();
      buscar.focus();
      avisar("Se eliminó " + seleccionado.id + ".");
    } catch (error) {
      porId("det-aviso").textContent = error.message;
    }
  });

  buscar.addEventListener("input", dibujar);
  for (const filtro of [tipo, severidad, estado, orden]) filtro.addEventListener("change", dibujar);
  porId("inc-limpiar").addEventListener("click", () => {
    for (const filtro of [buscar, tipo, severidad, estado]) filtro.value = "";
    dibujar();
    buscar.focus();
  });
  porId("inc-cargar").addEventListener("click", () => {
    try {
      const cantidad = Datos.cargarEjemplos();
      dibujar();
      avisar(cantidad ? "Se cargaron " + cantidad + " incidentes ficticios." : "Los ejemplos ya se cargaron.");
    } catch (error) {
      avisar(error.message, true);
    }
  });
  porId("inc-exportar").addEventListener("click", () => {
    try {
      descargarJSON(Datos.exportar(), "lenvrak-incidentes-aula.json");
      avisar("Se inició la descarga de todos los incidentes.");
    } catch (error) {
      avisar(error.message, true);
    }
  });

  window.addEventListener("storage", () => { if (filas.isConnected) dibujar(); });
  dibujar();
  const consulta = new URLSearchParams(location.hash.split("?")[1] || location.search);
  if (consulta.has("ver")) abrirDetalle(consulta.get("ver"));
}
