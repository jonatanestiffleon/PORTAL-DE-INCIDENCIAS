/* Extensión de Inicio, edición 1.0.0. Se distribuye junto al portal. */
function iniciarMejoraAula() {
  document.querySelectorAll("[data-version-modulo]").forEach(etiqueta => {
    etiqueta.textContent = "1.0.0";
  });
}

if (document.readyState === "complete") {
  iniciarMejoraAula();
} else {
  document.addEventListener("DOMContentLoaded", iniciarMejoraAula, { once: true });
}
