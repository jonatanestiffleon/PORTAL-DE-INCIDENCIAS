"use strict";

const paginas = { inicio: "Inicio", reportar: "Reportar", incidentes: "Incidentes", actualizaciones: "Actualizaciones" };
const portatil = document.body.dataset.portatil === "si";

// Al abrir el portal desde el disco, usamos # para que las cuatro vistas compartan los datos.
function enlacePagina(archivo) {
  if (!portatil) return archivo;
  const [ruta, consulta] = archivo.split("?");
  const vista = ruta === "index.html" ? "inicio" : ruta.replace(".html", "");
  return "#" + vista + (consulta ? "?" + consulta : "");
}

let relojAviso;
function avisar(texto, esError = false) {
  const aviso = document.querySelector("#aviso");
  aviso.hidden = false;
  aviso.classList.toggle("is-error", esError);
  aviso.textContent = texto;
  clearTimeout(relojAviso);
  relojAviso = setTimeout(() => { aviso.hidden = true; }, esError ? 15000 : 6500);
}

function descargarJSON(texto, nombre) {
  const url = URL.createObjectURL(new Blob([texto], { type: "application/json" }));
  const enlace = document.createElement("a");
  enlace.href = url;
  enlace.download = nombre;
  document.body.append(enlace);
  enlace.click();
  enlace.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

function elemento(tipo, clase, texto) {
  const nodo = document.createElement(tipo);
  nodo.className = clase;
  nodo.textContent = texto;
  return nodo;
}

function mostrarInicio() {
  const filas = Datos.listar();
  document.querySelector("#res-total").textContent = filas.length + " en total";
  const severidades = document.querySelector("#severidades");
  severidades.replaceChildren();
  for (const nombre of [...Datos.severidades].reverse()) {
    const cantidad = filas.filter(f => f.severidad === nombre).length;
    const marca = nombre.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
    const tarjeta = elemento("div", "stat sev-" + marca, "");
    const label = elemento("div", "stat-name", "");
    label.append(elemento("span", "level-dot", ""), document.createTextNode(nombre));
    const valor = elemento("strong", "stat-value", String(cantidad).padStart(2, "0"));
    const proporcion = filas.length ? Math.round(cantidad / filas.length * 100) : 0;
    tarjeta.append(label, valor, elemento("span", "stat-detail", proporcion + " % del total"));
    severidades.append(tarjeta);
  }
  const recientes = document.querySelector("#recientes");
  recientes.replaceChildren();
  if (!filas.length) {
    recientes.append(document.querySelector("#inicio-sin-registros").content.cloneNode(true));
    document.querySelector("#ejemplos-inicio").addEventListener("click", () => {
      try {
        const n = Datos.cargarEjemplos();
        mostrarInicio();
        avisar(n ? "Se cargaron " + n + " incidentes de ejemplo." : "Los ejemplos ya están cargados.");
      } catch (error) { avisar(error.message, true); }
    });
    return;
  }
  const lista = elemento("ul", "feed", "");
  // Si dos casos tienen la misma fecha, mostramos primero el de mayor código.
  const ultimas = [...filas].sort((a,b) => b.fecha.localeCompare(a.fecha) || Number(b.id.slice(4)) - Number(a.id.slice(4))).slice(0,5);
  for (const fila of ultimas) {
    const li = document.createElement("li");
    const link = elemento("a", "feed-link", "");
    link.href = enlacePagina("incidentes.html?ver=" + encodeURIComponent(fila.id));
    const info = elemento("span", "feed-info", "");
    info.append(elemento("span", "case-id", fila.id), elemento("strong", "feed-title", fila.titulo));
    const severidad = fila.severidad.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
    const tag = elemento("span", "badge sev-" + severidad, fila.severidad);
    link.append(info, tag, elemento("span", "feed-next", "›"));
    li.append(link);
    lista.append(li);
  }
  recientes.append(lista);
}

function iniciarPortal() {
  let vista = document.body.dataset.vista;
  if (location.protocol === "file:" && !portatil) {
    location.replace("modo-local.html#" + vista + location.search);
    return;
  }
  if (portatil) {
    const solicitada = location.hash.slice(1).split("?")[0];
    vista = Object.hasOwn(paginas, solicitada) ? solicitada : "inicio";
    const plantilla = document.querySelector("#vista-" + vista);
    if (plantilla) document.querySelector("main").replaceChildren(plantilla.content.cloneNode(true));
    document.body.dataset.vista = vista;
    document.title = paginas[vista] + " · LENVRAK Incidentes · Edición Aula";
    document.querySelector("#miga").textContent = paginas[vista];
    window.addEventListener("hashchange", () => location.reload());
  }
  for (const link of document.querySelectorAll("[data-pagina]")) {
    link.href = enlacePagina(link.dataset.pagina);
    if (link.closest("nav")) {
      const destino = vista === "inicio" ? "index.html" : vista + ".html";
      if (link.dataset.pagina === destino) link.setAttribute("aria-current", "page");
      else link.removeAttribute("aria-current");
    }
  }
  document.querySelector(".skip").addEventListener("click", evento => {
    evento.preventDefault();
    document.querySelector("main").focus();
  });
  const menu = document.querySelector("#menu-boton");
  menu.addEventListener("click", () => {
    const abierto = menu.getAttribute("aria-expanded") !== "true";
    menu.setAttribute("aria-expanded", String(abierto));
    document.querySelector("#menu").classList.toggle("abierto", abierto);
  });
  if (vista === "inicio") {
    mostrarInicio();
    window.addEventListener("storage", () => {
      try { mostrarInicio(); } catch (error) { avisar(error.message, true); }
    });
  }
  if (vista === "reportar") inicioReporte();
  if (vista === "incidentes") inicioIncidentes();
  if (vista === "actualizaciones") Actualizador.iniciar();
}

try { iniciarPortal(); } catch (error) { avisar(error.message, true); }
