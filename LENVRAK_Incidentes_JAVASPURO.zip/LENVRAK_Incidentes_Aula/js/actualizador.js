// Guardamos las plantillas por separado para poder volver a la versión anterior.
const Actualizador = (() => {
  // Este identificador conserva las plantillas instaladas en versiones anteriores del aula.
  const producto = "unas.bitacora-aula.equipo1";
  const clave = producto + ".catalogo.v1";
  const versionInicial = "1.0.0";
  const iniciales = [
    { titulo: "Mensaje con enlace sospechoso", tipo: "Phishing", descripcion: "Llegó un correo a la cuenta del aula con un enlace para volver a iniciar sesión." },
    { titulo: "Acceso fuera de horario", tipo: "Acceso indebido", descripcion: "En el registro del laboratorio aparece un inicio de sesión después de terminar la clase." }
  ];
  const tipos = ["Phishing", "Malware", "Acceso indebido", "Pérdida de equipo", "Otro"];

  function exigir(condicion, mensaje) {
    if (!condicion) throw new Error(mensaje);
  }

  function camposExactos(objeto, campos) {
    return objeto && typeof objeto === "object" && !Array.isArray(objeto)
      && Object.keys(objeto).length === campos.length
      && campos.every(campo => Object.hasOwn(objeto, campo));
  }

  function textoValido(texto, minimo, maximo) {
    return typeof texto === "string" && texto === texto.trim() && texto.length >= minimo && texto.length <= maximo;
  }

  function versionMayor(version, anterior) {
    if (typeof version !== "string" || !/^(0|[1-9]\d{0,3})(\.(0|[1-9]\d{0,3})){2}$/.test(version)) return false;
    const nueva = version.split(".").map(Number);
    const previa = anterior.split(".").map(Number);
    const cambio = nueva.findIndex((numero, i) => numero !== previa[i]);
    return cambio >= 0 && nueva[cambio] > previa[cambio];
  }

  // Revisamos las plantillas antes de mostrarlas en el formulario.
  function validar(paquete, catalogo) {
    exigir(camposExactos(paquete, ["producto", "formato", "desde", "version", "resumen", "plantillas"]),
      "Elige un paquete de plantillas de LENVRAK Incidentes, Edición Aula.");
    exigir(paquete.producto === producto && paquete.formato === 1, "El paquete corresponde a otra aplicación o formato.");
    exigir(paquete.desde === catalogo.version, "El paquete requiere la versión " + String(paquete.desde).slice(0,24) + ". La instalada es " + catalogo.version + ".");
    exigir(versionMayor(paquete.version, catalogo.version), "La nueva versión debe ser mayor y usar el formato 1.2.3.");
    exigir(textoValido(paquete.resumen, 5, 240), "El resumen debe tener entre 5 y 240 caracteres.");
    exigir(Array.isArray(paquete.plantillas) && paquete.plantillas.length >= 1 && paquete.plantillas.length <= 10,
      "Un paquete debe incluir entre 1 y 10 plantillas.");
    exigir(catalogo.plantillas.length + paquete.plantillas.length <= 80, "El catálogo admite hasta 80 plantillas.");
    const titulos = new Set(catalogo.plantillas.map(p => p.titulo.toLocaleLowerCase("es")));
    for (const plantilla of paquete.plantillas) {
      exigir(camposExactos(plantilla, ["titulo", "tipo", "descripcion"]), "Revisa los campos de cada plantilla.");
      exigir(textoValido(plantilla.titulo, 3, 80) && textoValido(plantilla.descripcion, 20, 500) && tipos.includes(plantilla.tipo),
        "Cada plantilla necesita un título de 3 a 80 caracteres, un tipo válido y una descripción de 20 a 500 caracteres.");
      const titulo = plantilla.titulo.toLocaleLowerCase("es");
      exigir(!titulos.has(titulo), "El título se repite en el catálogo: " + plantilla.titulo);
      titulos.add(titulo);
    }
  }

  function leer() {
    const texto = localStorage.getItem(clave);
    const guardado = texto === null ? { paquetes: [], historial: [] } : JSON.parse(texto);
    exigir(camposExactos(guardado, ["paquetes", "historial"]) && Array.isArray(guardado.paquetes)
      && Array.isArray(guardado.historial), "Revisa el catálogo guardado en este navegador.");
    const catalogo = { version: versionInicial, plantillas: [...iniciales] };
    for (const paquete of guardado.paquetes) {
      validar(paquete, catalogo);
      catalogo.plantillas.push(...paquete.plantillas);
      catalogo.version = paquete.version;
    }
    return { guardado, catalogo };
  }

  function registrar(guardado, accion, version) {
    guardado.historial.unshift({ accion, version, fecha: new Date().toISOString() });
    guardado.historial = guardado.historial.slice(0, 12);
    localStorage.setItem(clave, JSON.stringify(guardado));
  }

  // Si el catálogo no se puede leer, el formulario usa las dos plantillas iniciales.
  function plantillas() {
    try { return leer().catalogo.plantillas; } catch { return [...iniciales]; }
  }
  function version() {
    try { return leer().catalogo.version; } catch { return "No disponible"; }
  }

  function iniciar() {
    const buscar = id => document.getElementById(id);
    const archivo = buscar("act-archivo");
    if (!archivo) return;
    const aplicar = buscar("act-aplicar");
    const revertir = buscar("act-revertir");
    const vista = buscar("act-vista");
    const estado = buscar("act-estado");
    let pendiente = null;
    let mostrada = "";

    function limpiarSeleccion() {
      pendiente = null;
      aplicar.disabled = true;
      vista.hidden = true;
    }

    function elementoLista(texto) {
      const item = document.createElement("li");
      item.textContent = texto;
      return item;
    }

    function informar(texto, error = false) {
      estado.textContent = texto;
      estado.classList.toggle("is-error", error);
    }

    function refrescar() {
      const { guardado, catalogo } = leer();
      mostrada = catalogo.version;
      buscar("act-version").textContent = catalogo.version;
      buscar("act-total").textContent = String(catalogo.plantillas.length);
      revertir.disabled = guardado.paquetes.length === 0;
      const historial = buscar("act-historial");
      historial.replaceChildren();
      for (const paso of guardado.historial) {
        const fecha = new Date(paso.fecha).toLocaleString("es-PE", { dateStyle: "short", timeStyle: "short" });
        historial.append(elementoLista(fecha + " · " + paso.accion + " · " + paso.version));
      }
      if (!historial.children.length) historial.append(elementoLista("Aún no se aplicaron actualizaciones."));
    }

    function mostrarError(error) {
      if (error instanceof SyntaxError) informar("El archivo o el catálogo guardado contiene JSON inválido.", true);
      else if (error.name === "QuotaExceededError") informar("El navegador no tiene espacio para guardar el cambio.", true);
      else if (error.name === "SecurityError") informar("El navegador bloqueó el acceso al almacenamiento local.", true);
      else informar(error.message || "No se pudo completar la operación.", true);
    }

    archivo.addEventListener("change", async () => {
      limpiarSeleccion();
      informar("");
      const elegido = archivo.files[0];
      if (!elegido) return;
      try {
        exigir(elegido.size <= 65536, "El archivo JSON debe pesar como máximo 64 KiB.");
        const paquete = JSON.parse(await elegido.text());
        if (archivo.files[0] !== elegido) return;
        validar(paquete, leer().catalogo);
        buscar("act-destino").textContent = paquete.desde + " → " + paquete.version;
        buscar("act-resumen").textContent = paquete.resumen;
        buscar("act-plantillas").replaceChildren(...paquete.plantillas.map(p => elementoLista(p.titulo + " · " + p.tipo)));
        pendiente = paquete;
        vista.hidden = false;
        aplicar.disabled = false;
        informar("El paquete está listo. Revisa las plantillas y pulsa Aplicar actualización.");
      } catch (error) {
        if (archivo.files[0] === elegido) mostrarError(error);
      }
    });

    aplicar.addEventListener("click", () => {
      if (!pendiente) return;
      try {
        const { guardado, catalogo } = leer();
        validar(pendiente, catalogo);
        guardado.paquetes.push(pendiente);
        registrar(guardado, "Aplicada", pendiente.version);
        archivo.value = "";
        limpiarSeleccion();
        refrescar();
        informar("Ya puedes usar las nuevas plantillas en Reportar.");
      } catch (error) { mostrarError(error); }
    });

    revertir.addEventListener("click", () => {
      if (!window.confirm("¿Volver a la versión anterior de las plantillas?")) return;
      try {
        const { guardado, catalogo } = leer();
        exigir(guardado.paquetes.length && catalogo.version === mostrada, "El catálogo cambió. Recarga esta página.");
        const ultimo = guardado.paquetes.pop();
        registrar(guardado, "Reversión a", ultimo.desde);
        archivo.value = "";
        limpiarSeleccion();
        refrescar();
        informar("Volviste a la versión " + ultimo.desde + ".");
      } catch (error) { mostrarError(error); }
    });

    window.addEventListener("storage", evento => {
      if (evento.key !== clave && evento.key !== null) return;
      archivo.value = "";
      limpiarSeleccion();
      try { refrescar(); informar("El catálogo se actualizó desde otra pestaña."); }
      catch (error) { mostrarError(error); }
    });

    try { refrescar(); } catch (error) { archivo.disabled = true; mostrarError(error); }
  }

  return { plantillas, version, iniciar };
})();
