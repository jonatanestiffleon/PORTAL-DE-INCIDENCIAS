@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>&1
if errorlevel 1 (
    echo Para aplicar una nueva version del modulo necesitas Node.js 18 o posterior.
    echo Puedes usar el portal y actualizar sus plantillas desde el navegador.
    pause
    exit /b 1
)
if not "%~1"=="" (
    node actualizar.cjs aplicar "%~f1"
    pause
    exit /b
)
:menu
echo.
echo LENVRAK Incidentes - Edicion Aula - modulo de Inicio
node actualizar.cjs estado
echo [1] Instalar la opcion Imprimir resumen
echo [2] Volver a la version anterior
echo [3] Salir
choice /c 123 /n /m "Elige una opcion: "
if errorlevel 3 exit /b
if errorlevel 2 goto volver
node actualizar.cjs aplicar
goto menu
:volver
node actualizar.cjs revertir
goto menu
