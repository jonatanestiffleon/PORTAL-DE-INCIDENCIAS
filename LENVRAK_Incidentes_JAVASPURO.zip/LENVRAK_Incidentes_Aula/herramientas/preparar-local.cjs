// Reúne las cuatro pantallas en un HTML para abrir el portal desde el disco.
const fs = require("node:fs");
const path = require("node:path");
const raiz = path.resolve(__dirname, "..");
const leer = nombre => fs.readFileSync(path.join(raiz, nombre + ".html"), "utf8");
const inicio = leer("index");
const vistas = ["reportar", "incidentes", "actualizaciones"].map(nombre => {
  const cuerpo = leer(nombre).match(/<main\b[^>]*>([\s\S]*?)<\/main>/)[1];
  return '<template id="vista-' + nombre + '">' + cuerpo + '</template>';
});
const local = inicio.replace('data-vista="inicio"', 'data-vista="inicio" data-portatil="si"')
  .replace("</body>", vistas.join("\n") + "\n</body>");
fs.writeFileSync(path.join(raiz, "modo-local.html"), local);
