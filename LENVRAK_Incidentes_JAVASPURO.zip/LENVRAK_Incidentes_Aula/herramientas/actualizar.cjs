const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");

const aplicacion = "unas.bitacora-aula.equipo1.modulo-inicio";
const destino = path.join(__dirname, "..", "js", "mejora.js");
const catalogo = require("./versiones.json");
const paqueteIncluido = path.join(__dirname, "modulo-1.1.0.json");
const bloqueo = path.join(__dirname, "actualizacion.en-curso");
const limite = 128 * 1024;

function exigir(condicion, mensaje) {
  if (!condicion) throw new Error(mensaje);
}

function leer(archivo) {
  const info = fs.lstatSync(archivo);
  exigir(info.isFile() && info.size <= limite, "Elige un archivo normal de hasta 128 KiB.");
  return fs.readFileSync(archivo, "utf8");
}

function huella(codigo) {
  // Los saltos de línea de Windows y Linux deben dar la misma huella.
  return crypto.createHash("sha256").update(codigo.replace(/\r\n/g, "\n")).digest("hex");
}

function identificar(codigo) {
  const suma = huella(codigo);
  const version = Object.keys(catalogo).find(n => catalogo[n].sha256 === suma);
  exigir(version, "El módulo no coincide con una versión aprobada. Revisa la carpeta del proyecto.");
  return version;
}

function versionValida(valor) {
  return typeof valor === "string" && /^(0|[1-9]\d{0,3})\.(0|[1-9]\d{0,3})\.(0|[1-9]\d{0,3})$/.test(valor);
}

function valorVersion(version) {
  const [mayor, menor, parche] = version.split(".").map(Number);
  return mayor * 100000000 + menor * 10000 + parche;
}

function copiarAtomico(archivo, contenido) {
  const temporal = archivo + ".tmp-" + crypto.randomUUID();
  try {
    fs.writeFileSync(temporal, contenido, { flag: "wx" });
    fs.renameSync(temporal, archivo);
  } finally {
    fs.rmSync(temporal, { force: true });
  }
}

function respaldo(version) {
  exigir(versionValida(version), "La versión de respaldo es inválida.");
  return path.join(__dirname, "respaldo-" + version + ".bak");
}

function aplicar(archivo, instalado, anterior) {
  const paquete = JSON.parse(leer(archivo));
  exigir(paquete && Object.keys(paquete).sort().join(",") === "aplicacion,codigo,desde,hasta",
    "El formato del paquete es inválido.");
  exigir(paquete.aplicacion === aplicacion, "Este paquete pertenece a otra aplicación.");
  exigir(versionValida(paquete.desde) && versionValida(paquete.hasta), "Versiones inválidas.");
  exigir(paquete.desde === instalado, "El paquete requiere " + paquete.desde + ". Tienes " + instalado + ".");
  exigir(valorVersion(paquete.hasta) > valorVersion(instalado), "Se requiere una versión posterior.");
  const ficha = catalogo[paquete.hasta];
  exigir(ficha && ficha.desde === instalado, "La versión no está aprobada para esta instalación.");
  exigir(typeof paquete.codigo === "string" && huella(paquete.codigo) === ficha.sha256,
    "El contenido no coincide con la huella aprobada.");
  copiarAtomico(respaldo(instalado), anterior);
  copiarAtomico(destino, paquete.codigo);
  return paquete.hasta;
}

function revertir(instalado) {
  const previa = catalogo[instalado].desde;
  exigir(previa, "Ya estás en la versión inicial.");
  const anterior = leer(respaldo(previa));
  exigir(identificar(anterior) === previa, "El respaldo no corresponde a la versión anterior.");
  copiarAtomico(destino, anterior);
  return previa;
}

// El paquete se escribe en stdout y la huella en stderr para poder guardarlos por separado.
function preparar(desde, hasta, archivo) {
  exigir(versionValida(desde) && versionValida(hasta) && valorVersion(hasta) > valorVersion(desde) && archivo,
    "Uso: preparar VERSION_ANTERIOR VERSION_NUEVA ARCHIVO_JS");
  const codigo = leer(archivo);
  const json = JSON.stringify({ aplicacion, desde, hasta, codigo }, null, 2);
  exigir(Buffer.byteLength(json + "\n") <= limite, "El paquete supera 128 KiB.");
  console.error("SHA-256 de la nueva versión: " + huella(codigo));
  process.stdout.write(json + "\n");
}

function ejecutar([accion = "estado", archivo, hasta, entrada]) {
  if (accion === "preparar") return preparar(archivo, hasta, entrada);
  exigir(["estado", "aplicar", "revertir"].includes(accion), "Acciones: estado, aplicar, revertir, preparar.");
  exigir(!fs.lstatSync(path.dirname(destino)).isSymbolicLink(), "La carpeta js debe pertenecer al proyecto.");
  if (accion === "estado") {
    console.log("Módulo de Inicio instalado: " + identificar(leer(destino)));
    return;
  }

  try {
    fs.writeFileSync(bloqueo, String(process.pid), { flag: "wx" });
  } catch (error) {
    if (error.code === "EEXIST") throw new Error("Ya hay una actualización en curso. Consulta LEEME.md.");
    throw error;
  }
  try {
    const anterior = leer(destino);
    const instalado = identificar(anterior);
    const resultado = accion === "aplicar"
      ? aplicar(archivo || paqueteIncluido, instalado, anterior)
      : revertir(instalado);
    console.log("Módulo de Inicio: " + instalado + " → " + resultado + ". Recarga Inicio con Ctrl + F5.");
  } finally {
    fs.unlinkSync(bloqueo);
  }
}

try {
  ejecutar(process.argv.slice(2));
} catch (error) {
  console.error("No se completó la operación. " + error.message);
  process.exitCode = 1;
}
