# LENVRAK Incidentes · Edición Aula

## Imprimir el resumen de incidentes

La versión 1.1.0 del módulo de Inicio agrega el botón **Imprimir resumen**. La hoja que se imprime muestra los totales por severidad y los casos recientes.

## Cómo instalar la actualización en Windows

1. Extrae la carpeta del portal. Para esta actualización necesitas Node.js 18 o posterior.
2. Abre la carpeta **herramientas**, haz doble clic en **ACTUALIZAR.cmd** y pulsa **1**.
3. Cuando aparezca **1.1.0**, abre **Inicio** y presiona **Ctrl + F5**. Pulsa **Imprimir resumen** para elegir una impresora o guardar el resumen como PDF.

Para volver a la versión anterior, abre el mismo menú, pulsa **2** y recarga Inicio. La herramienta cambia `js/mejora.js` y guarda una copia de la versión previa. Los reportes siguen en el navegador. Si el portal está publicado en GitHub Pages, hay que subir el archivo actualizado al repositorio.

Las plantillas del formulario se actualizan desde **Actualizaciones** con el archivo `actualizaciones/plantillas-1.1.0.json`.

## Cómo preparar otra versión del módulo

Por ejemplo, para pasar de 1.1.0 a 1.2.0, guarda el código revisado en `nueva-mejora.js`. Abre **Símbolo del sistema** en la carpeta **herramientas** y ejecuta lo siguiente.

```bat
node actualizar.cjs preparar 1.1.0 1.2.0 nueva-mejora.js > modulo-1.2.0.json
```

El paquete queda en `modulo-1.2.0.json` y la huella SHA-256 aparece en la consola. Después de revisar el código, agrega la versión a `versiones.json` con `desde` igual a `1.1.0` y `sha256` igual a esa huella. Al instalar, el programa compara el código con ese catálogo. Por eso distribuimos el catálogo junto con el proyecto.

```bat
node actualizar.cjs aplicar modulo-1.2.0.json
```

Si aparece «Ya hay una actualización en curso», espera a que la otra ventana termine. Si se interrumpió, revisa en el Administrador de tareas que haya terminado el proceso cuyo número figura en `actualizacion.en-curso`. Entonces puedes borrar ese archivo y consultar la versión instalada con `node actualizar.cjs estado`. Los archivos `respaldo-*.bak` sirven para volver a la versión anterior.
