# LENVRAK Incidentes

**Edición Aula**

**Nikolai Coica y Jonatan Estiff León Santa María**  
Programación II · Equipo 1 · UNAS · 2026-II

LENVRAK Incidentes es nuestro proyecto para registrar incidentes de seguridad en el laboratorio. Si llega un correo que pide la clave del aula, podemos anotar qué decía, asignarle una severidad y volver al mismo reporte cuando alguien lo revise. Cada incidente tiene su propio código. En esta práctica usamos alias y casos ficticios.

## Abrir el portal

1. En Windows, haz clic derecho en el ZIP y elige **Extraer todo**.
2. Abre la carpeta **LENVRAK_Incidentes_Aula** y haz doble clic en **index.html**. Si ves **index** con el ícono de Edge o Chrome, es el mismo archivo.
3. En **Inicio**, pulsa **Cargar 12 ejemplos** para conocer el registro. También puedes ir a **Reportar** y empezar con un caso propio.

La Edición Aula guarda sus reportes en el navegador y funciona sin iniciar los servicios de LENVRAK profesional. Para seguir con los mismos casos otro día, abre la misma carpeta con el mismo perfil. **Incidentes → Exportar JSON** descarga una copia legible del registro completo.

Si ya tenías reportes en la edición académica anterior, expórtalos antes de actualizar y copia los archivos nuevos en la carpeta académica que ya usabas. Al abrir el portal con doble clic, cambiar la ruta del archivo puede hacer que el navegador muestre una lista vacía.

## Del aviso al cierre

En **Reportar** escribimos qué pasó, elegimos el tipo y la severidad y dejamos un alias. Al guardar aparece el código del caso. En **Incidentes** podemos buscarlo por ese código, editarlo o abrir el detalle para pasar de **Nuevo** a **En análisis** y luego a **Cerrado**. La tabla pone los críticos arriba. **Inicio** cuenta todos los casos por severidad y muestra los cinco más recientes.

![Resumen del registro después de agregar un caso crítico](docs/capturas/inicio.png)

![Tabla de reportes con los casos críticos al comienzo](docs/capturas/incidentes.png)

## Dos cambios que se pueden probar

| Para cambiar | Pasos |
| --- | --- |
| Las plantillas de **Reportar** | En **Actualizaciones**, selecciona `actualizaciones/plantillas-1.1.0.json` y pulsa **Aplicar actualización**. El formulario pasa de dos plantillas a cuatro. La misma pantalla permite volver al catálogo anterior. |
| El botón de impresión de **Inicio** | En Windows con Node.js 18 o posterior, abre `herramientas/ACTUALIZAR.cmd`, pulsa **1** y recarga Inicio con **Ctrl + F5**. Aparece **Imprimir resumen**. La opción **2** restaura la versión anterior del módulo. |

Las plantillas se guardan en el navegador. La herramienta de Windows actualiza el archivo `js/mejora.js` de la carpeta extraída y conserva una copia de la versión anterior. [Instrucciones del actualizador](herramientas/LEEME.md)

## Dónde está cada parte

| Archivo | Contenido |
| --- | --- |
| `index.html`, `reportar.html`, `incidentes.html`, `actualizaciones.html` | Las cuatro pantallas del portal. |
| `css/estilos.css` | Colores, formularios, tabla y posición del menú según el ancho de la pantalla. |
| `js/reportar.js` | Lee los campos y muestra qué hay que corregir antes de guardar. |
| `js/datos.js` | Valida, asigna códigos, guarda los casos y carga los doce ejemplos. |
| `js/incidentes.js` | Dibuja la tabla, aplica los filtros y permite consultar, editar, cerrar o eliminar un caso. |
| `js/app.js` | Navegación, contadores de Inicio, avisos y descarga de archivos JSON. |
| `js/actualizador.js` | Revisa, aplica y revierte los paquetes de plantillas. |
| `js/mejora.js`, `herramientas/` | Módulo de Inicio y herramienta que instala sus nuevas versiones. |

El portal usa HTML, CSS y JavaScript puro. Al abrirlo con doble clic, `index.html` lleva a `modo-local.html`. Esta página reúne las cuatro vistas en una misma dirección de archivo para que compartan los datos. Al publicar el proyecto en un servidor web, se usan las cuatro páginas por separado. Si el navegador bloquea el almacenamiento de archivos locales, se puede abrir el proyecto desde un servidor estático.

Al editar el HTML de una página, hay que ejecutar `node herramientas/preparar-local.cjs` desde la carpeta del proyecto para regenerar la versión de doble clic. Los archivos JS y CSS son los mismos en ambas versiones.

## Material de la unidad

- [Informe](docs/Informe_LENVRAK_Incidentes_Aula.pdf) y [diapositivas](docs/Diapositivas_LENVRAK_Incidentes_Aula.pdf)
- [Guion de exposición](docs/GUIA_DE_SUSTENTACION.md) y [registro de pruebas](docs/PRUEBAS.md)
- [Fichas de investigación](docs/investigacion/) y [declaración de herramientas](docs/DECLARACION_DE_HERRAMIENTAS.md)

## Repositorio y entregas de la unidad

La guía del curso pide al menos tres commits convencionales por etapa, una solicitud de cambios (*pull request*) revisada por otro equipo, su fusión y una etiqueta. El docente debe figurar como colaborador. Quedan pendientes los enlaces del repositorio, del sitio en GitHub Pages y de las revisiones.

| Etapa | Rama prevista | Etiqueta prevista | Enlace a la revisión |
| --- | --- | --- | --- |
| E1 · Estructura y navegación | `etapa-1-estructura` | `v0.1` | Pendiente |
| E2 · Diseño adaptable | `etapa-2-css` | `v0.2` | Pendiente |
| E3 · Registro y presentación | `etapa-3-datos` | `v0.3` | Pendiente |
| E4 · Interfaz y validación | `etapa-4-interfaz` | `v0.4` | Pendiente |
| E5 · Integración y entrega | `etapa-5-entrega` | `v1.0` | Pendiente |
