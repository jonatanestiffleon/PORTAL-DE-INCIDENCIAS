# LENVRAK Incidentes · Edición Aula

**Programación II · Nikolai Coica y Jonatan Estiff León Santa María**  
Diez minutos de exposición y cinco de preguntas. Recorrido con doce reportes de ejemplo cargados y el catálogo en la versión 1.0.0.

## El caso que vamos a registrar

| Campo | Dato para la demostración |
| --- | --- |
| Título | Correo que pide la clave del aula |
| Tipo | Phishing |
| Severidad | Crítica |
| Alias | Aula-Norte |
| Fecha y hora | La hora actual de la laptop |
| Descripción | Un correo pidió confirmar la clave del aula. Un compañero la ingresó en el enlace antes de avisar al grupo. |

## Conversación y demostración

**Nikolai · 0 a 1 min · Inicio.** «Supongamos que llega este correo al buzón del laboratorio. Si solo aviso por el chat, ¿cómo sé después si alguien lo revisó? En LENVRAK Incidentes puedo volver al reporte por su código. Acá tenemos doce casos de ejemplo. De esos, dos son críticos».

**Jonatan · 1 a 3 min · Reportar.** «Voy a anotar qué pasó. Para el reporte me basta un alias. Fíjense qué pasa si dejo la descripción vacía y pulso Guardar incidente». Después de mostrar el aviso, escribir la descripción del caso. Reducir el ancho de la ventana, abrir y cerrar el menú con el teclado.

**Nikolai · 3 a 5 min · Reportar e Incidentes.** «Elegí Phishing porque el mensaje pide una clave con el pretexto de confirmarla. En este caso un compañero ya ingresó la clave. Por eso lo marcamos como crítico. Voy a guardarlo con la hora de ahora». Leer el código que devuelve el portal y abrir la tabla. El reporte recién creado encabeza el grupo de críticos con el orden inicial.

**Nikolai · 5 a 6 min · Inicio.** «Hace un momento teníamos dos críticos. Ahora son tres. Voy a recargar la página y buscar el mismo código». Pulsar **F5**, ir a **Incidentes** y abrir el detalle por su código. Si el navegador ya tiene otros reportes, comparar con los conteos que había al empezar.

**Jonatan · 6 a 7:30 min · Detalle.** «Al abrir el reporte aparece como Nuevo. Si ya lo estamos revisando, pulso Pasar a análisis. Cuando terminamos la revisión, lo cierro. El código es el mismo y sigue figurando como crítico. La severidad dice qué tan grave fue y el estado dice en qué quedó». Mostrar dónde se edita y cómo se puede cancelar una eliminación.

**Nikolai y Jonatan · 7:30 a 9 min · Datos y actualización.** Nikolai abre `js/datos.js`. «El navegador guarda texto. Por eso convertimos los registros a JSON antes de guardarlos y los leemos de nuevo cuando abrimos la página. Si abro el portal en otra laptop, tendrá sus propios reportes». Jonatan abre **Actualizaciones**. «El formulario tenía dos plantillas. Voy a cargar el archivo de la versión 1.1.0. Ahora puedo elegir entre cuatro». Volver a **Reportar** y abrir la lista.

**Ambos · 9 a 10 min · Cierre.** «Las cuatro pantallas tienen el mismo menú. Si mañana agregamos una sección, tendríamos que editar cuatro archivos. Por eso el menú sería lo primero que convertiríamos en un componente».

## Preguntas que pueden salir

| Pregunta | Respuesta breve |
| --- | --- |
| ¿Cómo recuperan los datos al recargar? | `getItem` lee el texto guardado. `JSON.parse` recupera el objeto que contiene los registros. |
| ¿Qué pasa con una descripción que contiene `<b>correo</b>`? | El detalle usa `textContent`. Muestra los signos y las letras tal como se escribieron. |
| ¿Por qué no se repite el código si se borra el último caso? | Se guarda el siguiente número disponible junto con los registros. Borrar un caso conserva ese contador. |
| ¿Qué modifica el paquete de plantillas? | Agrega opciones al formulario. El catálogo tiene su propia clave de almacenamiento y los reportes guardados conservan sus datos. |
| ¿Cómo verían el mismo caso dos computadoras? | Haría falta un servicio con una base de datos compartida. En esta versión cada navegador conserva sus registros. |

Para mostrar la actualización del programa en Windows, la opción **1** de `herramientas/ACTUALIZAR.cmd` instala **Imprimir resumen** en Inicio. Se necesita Node.js 18 o posterior para esa herramienta. **Ctrl + F5** recarga el módulo y la opción **2** restaura la versión anterior.
