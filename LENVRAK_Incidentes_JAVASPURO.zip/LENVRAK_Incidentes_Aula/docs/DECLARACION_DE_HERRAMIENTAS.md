# Declaración de uso de herramientas

**LENVRAK Incidentes · Edición Aula · Equipo 1 · Programación II · UNAS · 2026-II**

Para preparar este proyecto usamos ChatGPT (Codex, OpenAI). Con su ayuda se generó la versión inicial del código, se prepararon los casos ficticios y los borradores del informe, las diapositivas y las fichas. También se usó para ejecutar comprobaciones técnicas y revisar la redacción. Los resultados de esas comprobaciones están en el registro de pruebas.

## Aportes y revisión personal

Quedan pendientes los aportes, las pruebas personales y las firmas de cada integrante.

| Integrante | Aporte personal | Qué probé en mi equipo |
| --- | --- | --- |
| Nikolai Coica | | |
| Jonatan Estiff León Santa María | | |

Otras herramientas y su finalidad __________________________________________

Cambios posteriores a la revisión del grupo __________________________________

Nikolai Coica · Firma __________________________ · Fecha ______________

Jonatan Estiff León Santa María · Firma __________________________ · Fecha ______________
