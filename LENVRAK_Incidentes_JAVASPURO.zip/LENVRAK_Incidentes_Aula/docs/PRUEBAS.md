# Pruebas de LENVRAK Incidentes

## Registro de comprobaciones

| Entorno | Acción | Resultado observado |
| --- | --- | --- |
| Chrome, por HTTP | Abrir **Reportar** e intentar guardar sin completar los campos. | Los avisos aparecieron junto a los campos que faltaban. |
| Chrome, por HTTP | Cargar los doce ejemplos y guardar «Correo que pide la clave del aula» con el alias Aula-Norte. El caso simula que un compañero ingresó su clave en el enlace. | Se asignó `INC-013` en estado **Nuevo**. Fue el primer caso de la tabla. |
| Chrome, por HTTP | Recargar el portal, buscar el reporte por su código, pasarlo a análisis y cerrarlo. | El reporte se recuperó tras la recarga. El estado final fue **Cerrado**. Inicio mostró 13 incidentes y tres críticos. |
| Chrome, por HTTP | Aplicar el paquete de plantillas 1.1.0 y luego revertirlo. | La lista pasó de dos a cuatro plantillas y volvió a dos con la versión 1.0.0. |
| Chrome, a 390, 768 y 1280 px | Abrir la tabla, el formulario e Inicio respectivamente. | A 390 px el botón desplegó el menú e indicó que estaba abierto. A 768 px los enlaces quedaron arriba y a 1280 px aparecieron a un lado. En la versión de doble clic también se pudo pasar de Inicio al formulario. |
| Pruebas de JavaScript | Editar, cambiar el estado, cancelar y confirmar una eliminación, filtrar, ordenar y exportar. | La tabla reflejó los cambios. La búsqueda sin coincidencias mostró un aviso y volver a cargar los ejemplos conservó los registros existentes. |
| JavaScript con almacenamiento de prueba | Guardar una edición desactualizada, simular un fallo de escritura y seleccionar un catálogo de otro producto. | El portal rechazó cada operación y mantuvo los registros. Una clave de otro proyecto conservó su valor. |
| Node.js en una copia temporal | Instalar y revertir el módulo 1.1.0. Volver a instalar un paquete incompatible o alterado. | Se guardó una copia del módulo anterior. La reversión lo restauró y los paquetes incompatibles fueron rechazados. |

## Ensayo pendiente en la laptop de la exposición

El caso de ejemplo se llama **Correo que pide la clave del aula**. Usaremos el mismo navegador y la misma carpeta desde el inicio hasta el cierre. Estos son los resultados esperados para ese ensayo.

| Paso | Qué revisar |
| --- | --- |
| Abrir `index.html` en Windows, cargar los doce ejemplos en una base vacía y registrar el correo con la hora actual. | Aparece `INC-013`. El contador de críticos sube de dos a tres. Si la base ya tenía otros casos, el código y los conteos pueden variar. |
| Pulsar **F5**, cerrar el navegador y volver a abrir el mismo archivo con el mismo perfil. | La búsqueda recupera el reporte por su código. |
| Editar el título, pasar a **En análisis** y cerrar. | Cambian el título y el estado. El código se conserva. |
| Filtrar por **Crítica** y **Cerrado**, buscar algo que no exista y luego limpiar los filtros. Exportar el registro. | Primero se ve el caso que acabamos de cerrar. La búsqueda sin coincidencias da un aviso. El JSON descargado contiene todos los incidentes. |
| Abrir otro caso de prueba e intentar eliminarlo dos veces. Cancelar la primera vez y confirmar la segunda. | Al cancelar, el caso se conserva. Al confirmar, desaparece del registro. |
| Instalar y revertir el paquete de plantillas. | El reporte del correo sigue disponible y conserva su estado. |
| Si se usa el actualizador de programa, abrir `herramientas/ACTUALIZAR.cmd` con Node.js 18 o posterior instalado. | La opción **1** incorpora **Imprimir resumen** tras recargar Inicio. La opción **2** restaura el módulo anterior. |
