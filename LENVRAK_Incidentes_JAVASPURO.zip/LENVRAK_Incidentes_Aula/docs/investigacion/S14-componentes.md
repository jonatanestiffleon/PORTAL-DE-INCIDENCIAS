# S14 · Una tarjeta para las cuatro severidades

**Etapa 5 · Componentes, React y Vue**

En Inicio hay cuatro tarjetas. Cada una tiene el nombre de una severidad, la cantidad de incidentes y su porcentaje del total. En `js/app.js`, `mostrarInicio()` recorre las severidades y arma cada tarjeta con la misma estructura. Cuando registramos un caso crítico, basta con volver a calcular la cantidad para que cambie el resumen.

Esa tarjeta sirve para entender qué es un componente. Podría recibir la severidad, la cantidad y el total como datos de entrada. Así, un cambio en la manera de mostrar el porcentaje se definiría en un solo lugar. Otro ejemplo sería un campo del formulario con su etiqueta y su aviso. El aspecto puede ser el mismo aunque las reglas de un título y de una fecha sean distintas.

React es una biblioteca que permite escribir componentes como funciones de JavaScript, normalmente con JSX. Vue es un framework que permite relacionar datos con una plantilla parecida a HTML. En la versión del curso usamos JavaScript puro. Las tarjetas ya nos permiten discutir qué parte reutilizaríamos si más adelante trabajáramos con alguna de estas herramientas.

**Pregunta abierta.** ¿Qué tendría sentido compartir entre el campo de fecha y el de descripción, y qué validaciones convendría dejar por separado?

## Fuentes

- React. (s. f.). *Your first component*. [Consultar](https://react.dev/learn/your-first-component)
- Vue.js. (s. f.). *Introduction*. [Consultar](https://vuejs.org/guide/introduction.html)
