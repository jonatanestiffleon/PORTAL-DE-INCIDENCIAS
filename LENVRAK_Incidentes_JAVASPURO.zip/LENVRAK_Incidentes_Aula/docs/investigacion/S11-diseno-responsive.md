# S11 · Cómo cambia el menú al achicar la ventana

**Etapa 2 · CSS y diseño adaptable**

En el celular, los cuatro enlaces del portal quedan dentro del botón de menú. A partir de 601 px ya hay espacio para ponerlos arriba. En una laptop de 961 px de ancho o más, el menú pasa al costado. En `css/estilos.css`, las *media queries* indican desde qué ancho entra cada distribución.

Para colocar el ícono al lado del nombre de una sección usamos Flexbox. Para los contadores de Inicio usamos Grid, que permite acomodar las tarjetas en columnas. Otra decisión que influye en el formulario es `box-sizing: border-box`. Un campo de 300 px, con 10 px de relleno y 1 px de borde por lado, ocupa esos mismos 300 px. Con `content-box` ocuparía 322 px y podría salirse de su columna.

Cuando dos reglas del mismo origen y capa compiten con igual importancia, la más específica tiene prioridad. Si también empatan en especificidad y alcance, se aplica la última. Esto explica por qué un enlace del menú puede tener un color y cambiar cuando está seleccionada su página.

**Pregunta abierta.** Al aumentar la letra desde el navegador, ¿siguen cabiendo los cuatro enlaces cuando el menú está arriba?

## Fuentes

- MDN contributors. (2025, 16 de diciembre). *Introduction to the CSS cascade*. MDN Web Docs. [Consultar](https://developer.mozilla.org/en-US/docs/Web/CSS/Guides/Cascade/Introduction)
- MDN contributors. (2026, 24 de agosto). *box-sizing*. MDN Web Docs. [Consultar](https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/Properties/box-sizing)
- MDN contributors. (2026, 4 de septiembre). *Responsive web design*. MDN Web Docs. [Consultar](https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/CSS_layout/Responsive_Design)
