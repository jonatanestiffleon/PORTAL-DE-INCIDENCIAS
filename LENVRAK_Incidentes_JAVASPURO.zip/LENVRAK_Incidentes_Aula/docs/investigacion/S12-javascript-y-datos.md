# S12 · Qué pasa con un reporte después de pulsar Guardar

**Etapa 3 · JavaScript, DOM y almacenamiento local**

Al registrar «Correo que pide la clave del aula», el formulario recoge seis campos. La función `Datos.guardar()` en `js/datos.js` valida los valores y asigna el siguiente código. En la base se conservan tanto los registros como el próximo número disponible. Por eso, aunque borremos el último caso, su código queda fuera de uso.

El navegador guarda cadenas de texto en `localStorage`. Con `JSON.stringify` convertimos la base en texto y con `setItem` la guardamos. Al volver a abrir el portal, `getItem` lee esa cadena y `JSON.parse` reconstruye el objeto. Si probamos el mismo código en otro perfil del navegador, estaremos consultando otro almacenamiento.

El DOM representa los elementos de la página. En `js/incidentes.js`, JavaScript crea las filas de la tabla con `createElement`. El detalle usa `textContent` para mostrar lo escrito por quien reportó el caso. Si el título contiene `<b>correo</b>`, veremos también los signos y las letras de la etiqueta.

**Pregunta abierta.** Si falla la lectura de los datos, ¿qué información ayudaría a recuperar el registro? En esta versión se avisa del problema y se conserva el contenido que ya estaba guardado.

## Fuentes

- MDN contributors. (2025, 28 de octubre). *Node: textContent property*. MDN Web Docs. [Consultar](https://developer.mozilla.org/en-US/docs/Web/API/Node/textContent)
- MDN contributors. (2026, 26 de mayo). *Using the Web Storage API*. MDN Web Docs. [Consultar](https://developer.mozilla.org/en-US/docs/Web/API/Web_Storage_API/Using_the_Web_Storage_API)
