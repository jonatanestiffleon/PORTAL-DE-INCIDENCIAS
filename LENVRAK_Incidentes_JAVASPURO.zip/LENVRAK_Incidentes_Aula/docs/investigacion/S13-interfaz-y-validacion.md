# S13 · Cómo saber qué falta en un reporte

**Etapa 4 · Interfaz y validación**

Si intentamos registrar mañana como fecha de un correo que ya llegó, el formulario muestra un aviso junto a la fecha. En `reportar.html`, el campo apunta a su mensaje mediante `aria-describedby`. Así un lector de pantalla puede asociar el problema con la casilla que hay que corregir. Al guardar, el foco pasa al primer campo con error.

Cinco heurísticas de Nielsen se reconocen en acciones del portal.

| Principio | Ejemplo en LENVRAK Incidentes |
| --- | --- |
| Visibilidad del estado | Al pasar un caso a **En análisis**, el detalle muestra el estado nuevo. |
| Correspondencia con el mundo real | Los nombres **Nuevo** y **Cerrado** se entienden al hablar del seguimiento de un reporte. |
| Control del usuario | Si abrimos la confirmación de eliminación por error, podemos cancelarla. |
| Prevención de errores | Antes de borrar un caso, el portal pide confirmación. |
| Reconocimiento antes que recuerdo | La lista de severidades muestra las cuatro opciones disponibles. |

En esta versión, JavaScript comprueba los datos en la laptop. Si en el futuro se compartieran entre usuarios mediante un servidor, el servidor también tendría que validar los datos y decidir quién puede modificarlos.

**Pregunta abierta.** ¿Una persona que solo usa el teclado puede identificar el primer campo con error, corregirlo y guardar?

## Fuentes

- Nielsen, J. (1994, 24 de abril). *10 usability heuristics for user interface design*. Nielsen Norman Group. [Consultar](https://www.nngroup.com/articles/ten-usability-heuristics/)
- World Wide Web Consortium. (2022, 3 de junio). *User notification*. Web Accessibility Initiative. [Consultar](https://www.w3.org/WAI/tutorials/forms/notifications/)
- MDN contributors. (2026, 9 de octubre). *Client-side form validation*. MDN Web Docs. [Consultar](https://developer.mozilla.org/en-US/docs/Learn_web_development/Extensions/Forms/Form_validation)
