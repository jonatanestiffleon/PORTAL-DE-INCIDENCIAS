# S15 · Publicar la página y comprobar un caso

**Etapa 5 · GitHub Pages y pruebas manuales**

GitHub Pages puede servir el HTML, el CSS y el JavaScript de LENVRAK Incidentes desde un repositorio. En la carpeta publicada deben estar `index.html` y las rutas que utiliza, entre ellas `css/estilos.css` y los archivos de `js/`. Las plantillas de actualización también tienen que estar disponibles si se van a distribuir con el portal.

Abrir el enlace publicado en dos computadoras permite ver la misma interfaz. Cada navegador guarda sus propios registros en `localStorage`. También cambia el almacenamiento al pasar del archivo local al dominio publicado. Los datos del sitio pueden borrarse y un script del mismo origen puede leerlos. Para las prácticas usamos alias y casos ficticios.

| Prueba del reporte crítico | Qué se espera |
| --- | --- |
| Condición inicial | Base vacía, doce ejemplos recién cargados y dos casos críticos. |
| Acción | Registrar el correo del laboratorio con la hora actual y severidad crítica. Pulsar **F5**. |
| Resultado esperado | Hay tres críticos. El correo conserva su código y aparece primero en la tabla con el orden inicial. |

El resultado observado y el entorno de prueba se anotan aparte. Eso permite distinguir un fallo del guardado de una búsqueda hecha en otro perfil. [Registro de pruebas](../PRUEBAS.md)

**Pregunta abierta.** Si el caso aparece en la laptop donde se registró pero falta en otra, ¿qué habría que cambiar para que ambas consulten los mismos datos?

## Fuentes

- GitHub. (s. f.). *What is GitHub Pages?* GitHub Docs. [Consultar](https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages)
- MDN contributors. (2026, 12 de octubre). *Window: localStorage property*. MDN Web Docs. [Consultar](https://developer.mozilla.org/en-US/docs/Web/API/Window/localStorage)
