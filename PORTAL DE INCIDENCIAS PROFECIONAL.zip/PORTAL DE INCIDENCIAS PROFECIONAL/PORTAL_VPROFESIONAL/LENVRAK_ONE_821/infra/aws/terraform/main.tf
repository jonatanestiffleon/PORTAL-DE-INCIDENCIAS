resource "aws_s3_bucket" "evidence" {
  bucket_prefix = "${var.project_name}-${var.environment}-evidence-"
}
resource "aws_s3_bucket_versioning" "evidence" {
  bucket = aws_s3_bucket.evidence.id
  versioning_configuration { status = "Enabled" }
}
resource "aws_s3_bucket_server_side_encryption_configuration" "evidence" {
  bucket = aws_s3_bucket.evidence.id
  rule { apply_server_side_encryption_by_default { sse_algorithm = "AES256" } }
}
resource "aws_cognito_user_pool" "users" {
  name = "${var.project_name}-${var.environment}-users"
  username_attributes = ["email"]
  auto_verified_attributes = ["email"]
}
resource "aws_cloudwatch_log_group" "api" {
  name = "/${var.project_name}/${var.environment}/api"
  retention_in_days = 30
}
