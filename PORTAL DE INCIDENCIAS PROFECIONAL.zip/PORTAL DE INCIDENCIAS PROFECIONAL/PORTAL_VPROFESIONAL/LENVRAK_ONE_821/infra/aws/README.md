# AWS
Arquitectura objetivo:
- Cognito: identidad.
- API Gateway: API pública.
- Lambda o contenedores: lógica.
- RDS PostgreSQL/Aurora: datos multiempresa.
- S3: evidencias y reportes.
- Systems Manager: runbooks remotos sobre nodos autorizados.
- Secrets Manager: secretos.
- CloudWatch: logs/métricas.
- CloudTrail: auditoría AWS.
- EventBridge/SQS: eventos y desacoplamiento.

La carpeta Terraform es una base segura; antes de producción se deben definir red, cifrado, backups, presupuesto y región.
