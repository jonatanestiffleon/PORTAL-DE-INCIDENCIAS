# Namecheap
Namecheap puede usarse como registrador del dominio. Si se elige Cloudflare como DNS autoritativo:
1. Comprar/usar el dominio en Namecheap.
2. Crear el sitio en Cloudflare.
3. Copiar los nameservers asignados por Cloudflare.
4. En Namecheap > Domain List > Manage > Nameservers > Custom DNS, colocar esos nameservers.
5. Gestionar A/CNAME/MX/TXT desde Cloudflare.

Namecheap no participa en la resolución de incidentes: su función principal aquí es dominio/DNS de registro.
