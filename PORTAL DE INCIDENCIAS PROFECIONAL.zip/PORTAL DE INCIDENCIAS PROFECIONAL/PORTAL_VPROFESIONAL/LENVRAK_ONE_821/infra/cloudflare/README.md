# Cloudflare
Uso previsto:
- DNS y TLS.
- WAF / DDoS.
- Cloudflare Access para paneles administrativos.
- Cloudflare Tunnel para n8n, agentes o servicios internos sin exponer puertos entrantes.

Subdominios sugeridos:
- `app.tudominio.com` → LENVRAK Web.
- `api.tudominio.com` → API AWS/LENVRAK.
- `automation.tudominio.com` → Cloudflare Access + Tunnel → n8n.

Nunca guardes tokens reales en Git.
