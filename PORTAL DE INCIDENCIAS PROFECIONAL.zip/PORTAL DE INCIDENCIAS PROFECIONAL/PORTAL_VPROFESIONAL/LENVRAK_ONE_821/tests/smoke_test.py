from pathlib import Path
import json,csv,subprocess,sys,shutil,py_compile
R=Path(__file__).resolve().parents[1]
errors=[]
required=[
'apps/web/index.html','apps/web/assets/app.css','apps/web/assets/app.js','apps/web/assets/update-manager.js',
'apps/api/app/main.py','apps/edge-agent/agent.py','apps/operator-agent/operator.py',
'apps/network-lab/gns3_connector.py','docker-compose.yml','docs/TRACEABILITY_821.csv','version.json',
'tools/update_manager/server.py','tools/update_manager/build_update.py'
]
for x in required:
    if not (R/x).exists(): errors.append('missing '+x)
for p in (R/'workflows/n8n').glob('*.json'):
    try: json.loads(p.read_text(encoding='utf-8'))
    except Exception as e: errors.append(f'json {p.name}: {e}')
try:
    with (R/'docs/TRACEABILITY_821.csv').open(encoding='utf-8-sig') as f:
        rows=list(csv.DictReader(f))
    if len(rows)!=821: errors.append(f'traceability rows={len(rows)}')
except Exception as e: errors.append('traceability: '+str(e))
node=shutil.which('node')
if node:
    for js in ['apps/web/assets/app.js','apps/web/assets/update-manager.js']:
        try:
            r=subprocess.run([node,'--check',str(R/js)],capture_output=True,text=True,timeout=5)
            if r.returncode: errors.append(f'js {js}: '+r.stderr)
        except Exception as e: errors.append(f'js {js}: {e}')
for base in [R/'apps/api/app',R/'tools/update_manager']:
    for p in base.rglob('*.py'):
        try: py_compile.compile(str(p),doraise=True)
        except Exception as e: errors.append(f'py {p.relative_to(R)}: {e}')
print('SMOKE TEST:', 'OK' if not errors else 'FAIL')
for e in errors: print('-',e)
raise SystemExit(1 if errors else 0)
