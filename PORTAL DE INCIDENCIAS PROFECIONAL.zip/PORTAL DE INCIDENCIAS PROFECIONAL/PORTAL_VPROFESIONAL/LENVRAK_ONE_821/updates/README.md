# Actualización de prueba

Incluye:
`LENVRAK_Update_0.9.1_SAMPLE.zip`

## Probar
1. Inicia LENVRAK y Update Manager:
   `scripts\windows\00_INICIAR_LENVRAK_DEMO_Y_UPDATER.bat`
2. Entra a **Actualizaciones**.
3. Copia el TOKEN de la consola del Update Manager.
4. Selecciona este ZIP.
5. Pulsa **Validar paquete**.
6. Pulsa **Probar**.
7. Pulsa **Instalar módulos elegidos**.
8. Verifica que la versión pase a `0.9.1`.
9. En Backups pulsa **Rollback** para volver a `0.9.0`.

El paquete agrega `docs/UPDATE_DEMO_0.9.1.md`.
La clave de firma incluida es SOLO PARA DEMO. Antes de producción ejecuta:
`py tools\update_manager\rotate_key.py`
