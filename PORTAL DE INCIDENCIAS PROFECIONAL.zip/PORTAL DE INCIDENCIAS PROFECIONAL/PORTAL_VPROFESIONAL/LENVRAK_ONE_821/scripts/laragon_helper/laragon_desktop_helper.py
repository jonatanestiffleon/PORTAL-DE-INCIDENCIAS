from __future__ import annotations
import json
import os
import subprocess
import socket
import time
import ctypes
from ctypes import wintypes
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from datetime import datetime

ROOT = Path(__file__).resolve().parents[2]
ENV = ROOT / ".env"
BIND = "127.0.0.1"
PORT = 8790

def env_value(key: str, default: str = "") -> str:
    if ENV.exists():
        for line in ENV.read_text(encoding="utf-8", errors="ignore").splitlines():
            if line.strip().startswith(key + "="):
                return line.split("=", 1)[1].strip()
    return os.environ.get(key, default)

TOKEN = env_value("EDGE_AGENT_TOKEN", "")

STATE_DIR = ROOT / ".lenvrak" / "launcher"
RUNTIME_LOG = STATE_DIR / "laragon-helper.runtime.log"
_MUTEX_HANDLE = None

def runtime_log(message: str) -> None:
    try:
        STATE_DIR.mkdir(parents=True, exist_ok=True)
        with RUNTIME_LOG.open("a", encoding="utf-8") as f:
            f.write(f"{datetime.now().isoformat(timespec='seconds')} {message}\n")
    except Exception:
        pass

def acquire_single_instance() -> bool:
    global _MUTEX_HANDLE
    if os.name != "nt":
        return True
    kernel32 = ctypes.windll.kernel32
    kernel32.CreateMutexW.restype = ctypes.c_void_p
    handle = kernel32.CreateMutexW(None, False, "Local\\LENVRAK_LARAGON_HELPER_8790")
    if not handle:
        runtime_log("MUTEX create failed")
        return False
    err = kernel32.GetLastError()
    _MUTEX_HANDLE = handle
    if err == 183:  # ERROR_ALREADY_EXISTS
        runtime_log("Duplicate helper rejected by mutex")
        return False
    runtime_log(f"Mutex acquired pid={os.getpid()}")
    return True

class ReusableThreadingHTTPServer(ThreadingHTTPServer):
    allow_reuse_address = True
    daemon_threads = True


def run_ps(script: str, timeout: int = 25) -> tuple[bool, str]:
    p = subprocess.run(
        ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script],
        capture_output=True,
        text=True,
        timeout=timeout,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    out = ((p.stdout or "") + "\n" + (p.stderr or "")).strip()
    return p.returncode == 0, out[-5000:]

def laragon_start_all() -> dict:
    """
    Native Windows adapter for Laragon 2026.
    Reuses the already-running Laragon instance and NEVER launches a second
    laragon.exe while one already exists. If Laragon is hidden/minimized,
    restores its existing window. Dismisses the license Warning dialog before
    clicking the MySQL switch. Verifies TCP 3306 after the click.
    """
    if os.name != "nt":
        return {"ok":False,"action":"laragon_mysql_native","output":"WINDOWS_REQUIRED"}

    user32=ctypes.windll.user32
    try:
        user32.SetProcessDPIAware()
    except Exception:
        pass

    EnumWindowsProc=ctypes.WINFUNCTYPE(ctypes.c_bool,wintypes.HWND,wintypes.LPARAM)
    user32.EnumWindows.argtypes=[EnumWindowsProc,wintypes.LPARAM]
    user32.IsWindowVisible.argtypes=[wintypes.HWND]
    user32.GetWindowTextLengthW.argtypes=[wintypes.HWND]
    user32.GetWindowTextW.argtypes=[wintypes.HWND,wintypes.LPWSTR,ctypes.c_int]
    user32.GetClientRect.argtypes=[wintypes.HWND,ctypes.POINTER(wintypes.RECT)]
    user32.ClientToScreen.argtypes=[wintypes.HWND,ctypes.POINTER(wintypes.POINT)]
    user32.ShowWindow.argtypes=[wintypes.HWND,ctypes.c_int]
    user32.SetForegroundWindow.argtypes=[wintypes.HWND]
    user32.SetCursorPos.argtypes=[ctypes.c_int,ctypes.c_int]
    user32.mouse_event.argtypes=[wintypes.DWORD,wintypes.DWORD,wintypes.DWORD,wintypes.DWORD,ctypes.c_void_p]
    user32.GetWindowThreadProcessId.argtypes=[wintypes.HWND,ctypes.POINTER(wintypes.DWORD)]
    user32.PostMessageW.argtypes=[wintypes.HWND,wintypes.UINT,wintypes.WPARAM,wintypes.LPARAM]

    CREATE_NO_WINDOW=getattr(subprocess,"CREATE_NO_WINDOW",0)

    def laragon_process_pids():
        pids=set()
        try:
            cp=subprocess.run(
                ["tasklist","/FI","IMAGENAME eq laragon.exe","/FO","CSV","/NH"],
                capture_output=True,text=True,errors="ignore",
                creationflags=CREATE_NO_WINDOW,timeout=4
            )
            for line in (cp.stdout or "").splitlines():
                line=line.strip()
                if not line.lower().startswith('"laragon.exe"'):
                    continue
                parts=line.split('","')
                if len(parts)>=2:
                    raw=parts[1].strip('" ')
                    if raw.isdigit():
                        pids.add(int(raw))
        except Exception:
            pass
        return pids

    def get_title(hwnd):
        n=user32.GetWindowTextLengthW(hwnd)
        if n<=0:
            return ""
        buf=ctypes.create_unicode_buffer(n+1)
        user32.GetWindowTextW(hwnd,buf,n+1)
        return buf.value.strip()

    def get_pid(hwnd):
        pid=wintypes.DWORD(0)
        user32.GetWindowThreadProcessId(hwnd,ctypes.byref(pid))
        return int(pid.value)

    def collect_laragon_windows(include_hidden=False):
        found=[]
        @EnumWindowsProc
        def cb(hwnd,lparam):
            try:
                if not include_hidden and not user32.IsWindowVisible(hwnd):
                    return True
                title=get_title(hwnd)
                if "laragon" not in title.lower():
                    return True
                rect=wintypes.RECT()
                if not user32.GetClientRect(hwnd,ctypes.byref(rect)):
                    return True
                w=max(0,rect.right-rect.left)
                h=max(0,rect.bottom-rect.top)
                if w>300 and h>250:
                    found.append((w*h,hwnd,title,w,h,get_pid(hwnd)))
            except Exception:
                pass
            return True
        user32.EnumWindows(cb,0)
        return found

    def close_warning_dialogs(target_pid):
        closed=[]
        @EnumWindowsProc
        def cb(hwnd,lparam):
            try:
                if not user32.IsWindowVisible(hwnd):
                    return True
                if get_pid(hwnd)!=target_pid:
                    return True
                title=get_title(hwnd).strip().lower()
                if title in ("warning","advertencia"):
                    user32.PostMessageW(hwnd,0x0010,0,0)  # WM_CLOSE
                    closed.append(title)
            except Exception:
                pass
            return True
        user32.EnumWindows(cb,0)
        if closed:
            time.sleep(0.4)
        return len(closed)

    def port_open()->bool:
        try:
            with socket.create_connection(("127.0.0.1",3306),timeout=0.8):
                return True
        except Exception:
            return False

    existing_pids=laragon_process_pids()
    windows=collect_laragon_windows(False)

    # If Laragon is already running but its main window is hidden/minimized,
    # restore the existing window instead of launching laragon.exe again.
    if not windows and existing_pids:
        hidden=collect_laragon_windows(True)
        if hidden:
            hidden.sort(key=lambda x:x[0],reverse=True)
            for _,hwnd,_,_,_,pid in hidden:
                if pid in existing_pids:
                    user32.ShowWindow(hwnd,9)  # SW_RESTORE
            time.sleep(0.6)
            windows=collect_laragon_windows(False)

        if not windows:
            runtime_log(
                "Laragon process already exists but no usable main window was found; "
                "second instance intentionally NOT launched."
            )
            return {
                "ok":False,
                "action":"laragon_mysql_native",
                "output":"LARAGON_ALREADY_RUNNING_WINDOW_NOT_FOUND|NO_SECOND_INSTANCE",
            }

    # Start Laragon only when there is genuinely no running laragon.exe process.
    if not windows:
        exe=Path(r"C:\laragon\laragon.exe")
        if not exe.exists():
            return {"ok":False,"action":"laragon_mysql_native","output":"LARAGON_WINDOW_NOT_FOUND_AND_EXE_MISSING"}

        # Re-check immediately before launch to close the race window.
        existing_pids=laragon_process_pids()
        if existing_pids:
            return {
                "ok":False,
                "action":"laragon_mysql_native",
                "output":"LARAGON_ALREADY_RUNNING_RACE_GUARD|NO_SECOND_INSTANCE",
            }

        try:
            subprocess.Popen([str(exe)],creationflags=CREATE_NO_WINDOW)
            runtime_log("Laragon was not running; one instance launched.")
        except Exception as exc:
            return {
                "ok":False,
                "action":"laragon_mysql_native",
                "output":f"LARAGON_START_FAILED:{type(exc).__name__}:{exc}",
            }

        # Allow Laragon to create its main window; do not spawn again.
        for _ in range(12):
            time.sleep(0.5)
            windows=collect_laragon_windows(False)
            if windows:
                break

    if not windows:
        return {"ok":False,"action":"laragon_mysql_native","output":"LARAGON_VISIBLE_WINDOW_NOT_FOUND"}

    windows.sort(key=lambda x:x[0],reverse=True)
    _,hwnd,title,width,height,main_pid=windows[0]

    # Dismiss Laragon's modal unlicensed Warning if present. It blocks clicks
    # on the main window but closing the dialog does NOT close Laragon.
    dismissed=close_warning_dialogs(main_pid)

    SW_RESTORE=9
    user32.ShowWindow(hwnd,SW_RESTORE)
    user32.SetForegroundWindow(hwnd)
    time.sleep(0.45)

    if port_open():
        return {
            "ok":True,
            "action":"laragon_mysql_native",
            "output":f"MYSQL_ALREADY_ON|title={title}|client={width}x{height}|warning_closed={dismissed}",
        }

    # Calibrated for Laragon 2026 v8.7.0.
    candidates=[
        (0.130,0.287),
        (0.125,0.287),
        (0.135,0.287),
    ]

    LEFTDOWN=0x0002
    LEFTUP=0x0004
    attempts=[]

    for idx,(rx,ry) in enumerate(candidates,1):
        client_pt=wintypes.POINT(int(width*rx),int(height*ry))
        if not user32.ClientToScreen(hwnd,ctypes.byref(client_pt)):
            attempts.append(f"{idx}:CLIENT_TO_SCREEN_FAILED")
            continue

        x,y=int(client_pt.x),int(client_pt.y)
        user32.ShowWindow(hwnd,SW_RESTORE)
        user32.SetForegroundWindow(hwnd)
        user32.SetCursorPos(x,y)
        time.sleep(0.15)
        user32.mouse_event(LEFTDOWN,0,0,0,None)
        user32.mouse_event(LEFTUP,0,0,0,None)
        attempts.append(f"{idx}:CLICK={x},{y};ratio={rx:.3f},{ry:.3f}")

        # Wait before trying another coordinate to avoid toggling MySQL twice.
        for _ in range(10):
            if port_open():
                return {
                    "ok":True,
                    "action":"laragon_mysql_native",
                    "output":"MYSQL_NATIVE_CLICK_OK|"
                             +f"title={title}|client={width}x{height}|warning_closed={dismissed}|"
                             +";".join(attempts),
                }
            time.sleep(0.5)

    return {
        "ok":False,
        "action":"laragon_mysql_native",
        "output":"MYSQL_NATIVE_CLICK_FAILED|"
                 +f"title={title}|client={width}x{height}|warning_closed={dismissed}|"
                 +";".join(attempts),
    }

class Handler(BaseHTTPRequestHandler):
    server_version = "LENVRAKLaragonHelper/0.16.4"

    def log_message(self, fmt, *args):
        pass

    def _json(self, status: int, data: dict):
        raw = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def _auth(self) -> bool:
        return bool(TOKEN) and self.headers.get("X-LENVRAK-EDGE-TOKEN", "") == TOKEN

    def do_GET(self):
        if self.path != "/health":
            return self._json(404, {"ok": False, "error": "not_found"})
        if not self._auth():
            return self._json(401, {"ok": False, "error": "unauthorized"})
        return self._json(200, {
            "ok": True,
            "service": "lenvrak-laragon-desktop-helper",
            "version": "0.16.4",
            "interactive_session": True,
        })

    def do_POST(self):
        if not self._auth():
            return self._json(401, {"ok": False, "error": "unauthorized"})
        if self.path == "/v1/laragon/start-all":
            result = laragon_start_all()
            return self._json(200 if result["ok"] else 409, result)
        return self._json(404, {"ok": False, "error": "not_found"})

if __name__ == "__main__":
    if os.name != "nt":
        raise SystemExit("Laragon Desktop Helper solo funciona en Windows.")
    if not TOKEN:
        runtime_log("EDGE_AGENT_TOKEN no configurado")
        raise SystemExit("EDGE_AGENT_TOKEN no configurado.")

    if not acquire_single_instance():
        raise SystemExit(0)

    runtime_log(f"START version=0.16.4 bind={BIND}:{PORT} pid={os.getpid()}")

    # Self-healing listener loop. If the socket/server stops unexpectedly,
    # recreate it instead of leaving a Python process alive without port 8790.
    while True:
        server = None
        try:
            server = ReusableThreadingHTTPServer((BIND, PORT), Handler)
            runtime_log(f"LISTENING {BIND}:{PORT}")
            server.serve_forever(poll_interval=0.5)
            runtime_log("serve_forever returned; restarting listener")
        except OSError as exc:
            runtime_log(f"BIND/SOCKET ERROR {type(exc).__name__}: {exc}")
            time.sleep(2.0)
        except Exception as exc:
            runtime_log(f"SERVER ERROR {type(exc).__name__}: {exc}")
            time.sleep(2.0)
        finally:
            try:
                if server is not None:
                    server.server_close()
            except Exception:
                pass
