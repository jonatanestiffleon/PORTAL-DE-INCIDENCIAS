@echo off
setlocal
cd /d "%~dp0\..\.."
set "PYTHON="
where python >nul 2>&1 && set "PYTHON=python"
if not defined PYTHON where py >nul 2>&1 && set "PYTHON=py"
if not defined PYTHON (
  echo ERROR: Python no esta disponible en PATH.
  pause
  exit /b 1
)

powershell -NoProfile -Command "try { (Invoke-WebRequest 'http://127.0.0.1:8765/health' -UseBasicParsing -TimeoutSec 1).StatusCode | Out-Null; exit 0 } catch { exit 1 }"
if errorlevel 1 (
  title LENVRAK Update Manager
  %PYTHON% tools\update_manager\server.py
) else (
  echo Update Manager ya esta activo en http://127.0.0.1:8765
  pause
)
endlocal
