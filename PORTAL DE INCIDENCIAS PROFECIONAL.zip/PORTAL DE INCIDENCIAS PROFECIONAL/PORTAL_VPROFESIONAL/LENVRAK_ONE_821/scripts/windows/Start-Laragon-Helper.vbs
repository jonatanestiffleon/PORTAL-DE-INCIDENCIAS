Option Explicit

If WScript.Arguments.Count < 3 Then
    WScript.Quit 2
End If

Dim sh, pythonExe, rootDir, helperScript, cmd
Set sh = CreateObject("WScript.Shell")

pythonExe = WScript.Arguments(0)
rootDir = WScript.Arguments(1)
helperScript = WScript.Arguments(2)

sh.CurrentDirectory = rootDir

cmd = Chr(34) & pythonExe & Chr(34) & " -u " & Chr(34) & helperScript & Chr(34)

' 0 = hidden, False = asynchronous.
sh.Run cmd, 0, False
