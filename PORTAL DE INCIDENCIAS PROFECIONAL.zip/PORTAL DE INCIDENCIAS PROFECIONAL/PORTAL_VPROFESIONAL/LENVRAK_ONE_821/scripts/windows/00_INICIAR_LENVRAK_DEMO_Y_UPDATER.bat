@echo off
setlocal
cd /d "%~dp0\..\.."

set "PYTHON="
where python >nul 2>&1 && set "PYTHON=python"
if not defined PYTHON where py >nul 2>&1 && set "PYTHON=py"
if not defined PYTHON (
  echo ERROR: Python no esta disponible en PATH.
  echo Instala Python o agrega python.exe al PATH.
  pause
  exit /b 1
)

echo ================================================
echo LENVRAK ONE
echo Web:            http://127.0.0.1:8090
echo API:            http://127.0.0.1:8000
echo n8n:            http://127.0.0.1:5678
echo Update Manager: http://127.0.0.1:8765
echo Asistencia:     reservado en http://127.0.0.1:8080
echo ================================================

powershell -NoProfile -Command "try { (Invoke-WebRequest 'http://127.0.0.1:8765/health' -UseBasicParsing -TimeoutSec 1).StatusCode | Out-Null; exit 0 } catch { exit 1 }"
if errorlevel 1 (
  echo Iniciando Update Manager...
  start "LENVRAK Update Manager" cmd /k %PYTHON% tools\update_manager\server.py
) else (
  echo Update Manager ya esta activo.
)

powershell -NoProfile -Command "try { (Invoke-WebRequest 'http://127.0.0.1:8090' -UseBasicParsing -TimeoutSec 1).StatusCode | Out-Null; exit 0 } catch { exit 1 }"
if errorlevel 1 (
  echo Iniciando LENVRAK Web en 8090...
  start "LENVRAK Web 8090" cmd /k %PYTHON% -m http.server 8090 -d apps\web
) else (
  echo LENVRAK Web ya esta activo en 8090.
)

timeout /t 2 >nul
start "" http://127.0.0.1:8090
endlocal
