[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$StateDir = Join-Path $Root '.lenvrak\launcher'
$LogFile = Join-Path $StateDir 'edge-background.log'
New-Item -ItemType Directory -Force -Path $StateDir | Out-Null
Set-Location $Root

function Log([string]$m) { Add-Content -Path $LogFile -Value "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $m" -Encoding UTF8 }

try {
    $python = (Get-Command python.exe -ErrorAction SilentlyContinue).Source
    $usePy = $false
    if (-not $python) {
        $python = (Get-Command py.exe -ErrorAction SilentlyContinue).Source
        $usePy = [bool]$python
    }
    if (-not $python) { throw 'Python no está disponible en PATH.' }

    Log 'Iniciando Edge Agent oculto/elevado.'
    if ($usePy) {
        & $python -3 'scripts\edge_agent\configure_edge_agent.py' *>> $LogFile
        & $python -3 'scripts\edge_agent\windows_edge_agent.py' *>> $LogFile
    } else {
        & $python 'scripts\edge_agent\configure_edge_agent.py' *>> $LogFile
        & $python 'scripts\edge_agent\windows_edge_agent.py' *>> $LogFile
    }
} catch {
    Log ("ERROR: " + $_.Exception.Message)
    throw
}
