@echo off
setlocal
cd /d "%~dp0\..\.."
set "PYTHON="
where python >nul 2>&1 && set "PYTHON=python"
if not defined PYTHON where py >nul 2>&1 && set "PYTHON=py"
if not defined PYTHON (
  echo ERROR: Python no esta disponible en PATH.
  pause
  exit /b 1
)

powershell -NoProfile -Command "try { (Invoke-WebRequest 'http://127.0.0.1:8090' -UseBasicParsing -TimeoutSec 1).StatusCode | Out-Null; exit 0 } catch { exit 1 }"
if errorlevel 1 (
  start "LENVRAK Web 8090" cmd /k %PYTHON% -m http.server 8090 -d apps\web
  timeout /t 2 >nul
)
start "" http://127.0.0.1:8090
endlocal
