@echo off
cd /d "%~dp0\..\.."
title LENVRAK - Configurar n8n Assistant completo
echo ============================================================
echo LENVRAK - n8n Assistant: Sandbox + Busqueda Web
echo ============================================================
python scripts\configure_n8n_assistant.py
echo.
pause
