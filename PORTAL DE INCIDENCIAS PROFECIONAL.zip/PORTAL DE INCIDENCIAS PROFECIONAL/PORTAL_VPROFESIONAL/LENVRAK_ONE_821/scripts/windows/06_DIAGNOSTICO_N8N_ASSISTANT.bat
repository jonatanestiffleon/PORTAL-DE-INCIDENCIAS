@echo off
cd /d "%~dp0\..\.."
echo === CONTENEDORES ===
docker compose ps -a
echo.
echo === SANDBOX CERTS ===
docker compose logs --tail=80 sandbox-certs
echo.
echo === SANDBOX API ===
docker compose logs --tail=120 sandbox-api
echo.
echo === SANDBOX RUNNER ===
docker compose logs --tail=120 sandbox-runner-1
echo.
echo === SEARXNG ===
docker compose logs --tail=60 searxng
echo.
echo === PRUEBA HEALTH DESDE N8N ===
docker compose exec -T n8n wget -qO- http://sandbox-api:8080/healthz
echo.
pause
