from fastapi import APIRouter,Depends
from sqlalchemy.orm import Session
from ..db import get_db
from ..models import Incident
from ..schemas import AttendanceEvent
router=APIRouter(prefix="/api/v1/access",tags=["access"])
@router.post("/events",status_code=201)
def receive_event(e:AttendanceEvent,db:Session=Depends(get_db)):
    n=db.query(Incident).count()+1001
    obj=Incident(code=f"INC-{n:04d}",title=f"Access: {e.eventType}",type="asistencia",severity=e.severity,status="detectado",origin="LENVRAK Access",asset=e.terminalId,site=e.site,owner="Mesa técnica",description=e.summary,evidence={"source":"attendance-api"})
    db.add(obj);db.commit();db.refresh(obj);return obj
