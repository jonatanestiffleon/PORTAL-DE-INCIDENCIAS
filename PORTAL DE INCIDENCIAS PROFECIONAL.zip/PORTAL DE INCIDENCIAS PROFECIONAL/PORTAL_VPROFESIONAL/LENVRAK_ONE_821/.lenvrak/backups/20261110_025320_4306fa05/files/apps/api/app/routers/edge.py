from __future__ import annotations

from datetime import datetime
from typing import Any

import httpx
from fastapi import APIRouter, Depends, Header, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..db import get_db
from ..models import AuditEvent, Incident
from ..settings import settings

router = APIRouter(prefix="/api/v1/edge", tags=["edge"])

_EDGE_STATUS: dict[str, Any] = {
    "online": False,
    "monitoring": False,
    "last_seen": None,
    "agent": {},
    "checks": [],
}


class EdgeCheck(BaseModel):
    key: str = Field(min_length=3, max_length=160)
    name: str = Field(min_length=2, max_length=160)
    status: str = Field(min_length=1, max_length=80)
    ok: bool
    asset: str = Field(default="N/A", max_length=120)
    detail: str = Field(default="", max_length=1000)
    checked_at: str | None = None


class EdgeTelemetry(BaseModel):
    agent: dict[str, Any] = {}
    monitoring: dict[str, Any] = {}
    checks: list[EdgeCheck] = []


class EdgeDetection(BaseModel):
    monitor_key: str = Field(min_length=3, max_length=160)
    title: str = Field(min_length=3, max_length=160)
    type: str = Field(default="servicio", max_length=60)
    severity: str = Field(default="media", max_length=20)
    asset: str = Field(default="N/A", max_length=120)
    site: str = Field(default="Sede principal", max_length=120)
    description: str = Field(min_length=20, max_length=2000)
    evidence: dict[str, Any] = {}


def _authorized(token: str | None) -> bool:
    expected = settings.edge_agent_token
    return bool(expected) and bool(token) and token == expected


def _next_code(db: Session) -> str:
    n = db.scalar(select(func.count()).select_from(Incident)) or 0
    return f"INC-{1001+n:04d}"


@router.get("/status")
def status():
    return _EDGE_STATUS


@router.post("/telemetry")
def telemetry(data: EdgeTelemetry, x_lenvrak_edge_token: str | None = Header(default=None)):
    if not _authorized(x_lenvrak_edge_token):
        raise HTTPException(401, "Edge Agent unauthorized")
    _EDGE_STATUS.update({
        "online": True,
        "monitoring": bool(data.monitoring.get("active", True)),
        "last_seen": datetime.utcnow().isoformat() + "Z",
        "agent": data.agent,
        "monitor": data.monitoring,
        "checks": [x.model_dump() for x in data.checks],
    })
    return {"ok": True}


@router.post("/detections")
async def detection(data: EdgeDetection, x_lenvrak_edge_token: str | None = Header(default=None), db: Session = Depends(get_db)):
    if not _authorized(x_lenvrak_edge_token):
        raise HTTPException(401, "Edge Agent unauthorized")

    # Prevent duplicate incidents while the same fault remains active.
    existing_rows = db.scalars(
        select(Incident).where(Incident.origin == "LENVRAK Edge", Incident.status != "resuelto")
        .order_by(Incident.created_at.desc())
        .limit(100)
    ).all()
    for item in existing_rows:
        evidence = item.evidence or {}
        if evidence.get("monitor_key") == data.monitor_key:
            return {"ok": True, "state": "already_open", "incident_code": item.code, "status": item.status}

    evidence = dict(data.evidence or {})
    evidence.update({
        "monitor_key": data.monitor_key,
        "detected_by": "LENVRAK Edge Monitor",
        "detected_at": datetime.utcnow().isoformat() + "Z",
    })
    obj = Incident(
        code=_next_code(db),
        title=data.title,
        type=data.type,
        severity=data.severity if data.severity in {"baja", "media", "alta", "critica"} else "media",
        status="detectado",
        origin="LENVRAK Edge",
        asset=data.asset,
        site=data.site,
        owner="Mesa técnica",
        description=data.description,
        evidence=evidence,
    )
    db.add(obj)
    db.add(AuditEvent(actor="edge-monitor", action="incident.detected_automatically", detail=f"{obj.code} {data.monitor_key}"))
    db.commit()
    db.refresh(obj)

    # Start the same production workflow used by Sentinel, without human intervention.
    url = settings.n8n_base_url.rstrip("/") + "/webhook/lenvrak-incident"
    try:
        obj.status = "orquestando"
        db.commit()
        async with httpx.AsyncClient(timeout=8.0) as client:
            response = await client.post(url, json={"code": obj.code, "source": "edge-monitor", "monitor_key": data.monitor_key})
            response.raise_for_status()
        db.add(AuditEvent(actor="n8n", action="edge.workflow_started", detail=obj.code))
        db.commit()
        return {"ok": True, "state": "workflow_started", "incident_code": obj.code, "status": obj.status}
    except Exception as exc:
        obj.status = "detectado"
        db.add(AuditEvent(actor="edge-monitor", action="edge.workflow_failed", detail=f"{obj.code} {type(exc).__name__}"))
        db.commit()
        return {
            "ok": True,
            "state": "incident_created_workflow_unavailable",
            "incident_code": obj.code,
            "status": obj.status,
            "warning": type(exc).__name__,
        }
