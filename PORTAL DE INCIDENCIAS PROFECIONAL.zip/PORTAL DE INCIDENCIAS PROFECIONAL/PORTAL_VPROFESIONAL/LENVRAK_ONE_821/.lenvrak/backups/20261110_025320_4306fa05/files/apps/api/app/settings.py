from pydantic_settings import BaseSettings, SettingsConfigDict
class Settings(BaseSettings):
    app_name:str="LENVRAK One API"
    environment:str="development"
    database_url:str="sqlite:///./lenvrak.db"
    cors_origins:str="http://127.0.0.1:8090,http://localhost:8090"
    openai_api_key:str=""
    openai_model:str="gpt-5.6"
    n8n_base_url:str="http://n8n:5678"
    n8n_webhook_secret:str=""
    aws_region:str="us-east-1"
    aws_s3_bucket:str=""
    aws_ssm_enabled:bool=False
    attendance_api_url:str=""
    attendance_api_token:str=""
    gns3_url:str="http://host.docker.internal:3080"
    edge_agent_url:str="http://host.docker.internal:8780"
    edge_agent_token:str=""
    edge_agent_timeout_seconds:float=20.0
    model_config=SettingsConfigDict(env_file=".env",extra="ignore")
settings=Settings()
