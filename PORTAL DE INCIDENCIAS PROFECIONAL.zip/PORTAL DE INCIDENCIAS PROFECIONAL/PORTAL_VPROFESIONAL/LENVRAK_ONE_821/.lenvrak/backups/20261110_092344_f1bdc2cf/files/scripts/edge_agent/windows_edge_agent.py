from __future__ import annotations

import ctypes
import json
import os
import subprocess
import socket
import threading
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
STATE = ROOT / ".lenvrak"
LOG = STATE / "edge_agent.log"


def load_dotenv() -> dict[str, str]:
    values: dict[str, str] = {}
    path = ROOT / ".env"
    if not path.exists():
        return values
    for raw in path.read_text(encoding="utf-8", errors="ignore").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = value.strip().strip('"').strip("'")
    return values


ENV = load_dotenv()
TOKEN = os.getenv("LENVRAK_EDGE_TOKEN") or ENV.get("EDGE_AGENT_TOKEN", "")
BIND = os.getenv("LENVRAK_EDGE_BIND") or ENV.get("EDGE_AGENT_BIND", "0.0.0.0")
PORT = int(os.getenv("LENVRAK_EDGE_PORT") or ENV.get("EDGE_AGENT_PORT", "8780"))
API_URL = (os.getenv("LENVRAK_API_URL") or ENV.get("EDGE_API_URL", "http://127.0.0.1:8000")).rstrip("/")
MONITOR_INTERVAL = max(3, int(os.getenv("LENVRAK_EDGE_MONITOR_INTERVAL") or ENV.get("EDGE_MONITOR_INTERVAL_SECONDS", "5")))
MONITOR_STOP = threading.Event()
LATEST_CHECKS: list[dict[str, Any]] = []


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def log(message: str) -> None:
    STATE.mkdir(parents=True, exist_ok=True)
    line = f"{datetime.now().isoformat(timespec='seconds')} {message}\n"
    with LOG.open("a", encoding="utf-8") as fh:
        fh.write(line)


def is_admin() -> bool:
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def run_powershell(script: str, timeout: int = 30) -> tuple[bool, str]:
    try:
        proc = subprocess.run(
            ["powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", script],
            capture_output=True,
            text=True,
            timeout=timeout,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        text = (proc.stdout or proc.stderr or "").strip()
        return proc.returncode == 0, text[-4000:]
    except Exception as exc:
        return False, f"{type(exc).__name__}: {exc}"


PROFILE_FILE = STATE / "recovery_profiles.json"

def _load_profiles() -> dict[str, Any]:
    try:
        if PROFILE_FILE.exists():
            data=json.loads(PROFILE_FILE.read_text(encoding="utf-8"))
            return data if isinstance(data,dict) else {}
    except Exception:
        pass
    return {}

def _save_profiles(data: dict[str, Any]) -> None:
    try:
        STATE.mkdir(parents=True,exist_ok=True)
        PROFILE_FILE.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8")
    except Exception as exc:
        log(f"PROFILE SAVE ERROR {type(exc).__name__}: {exc}")

def _capture_process_profile(profile_key:str,names:list[str]) -> None:
    profiles=_load_profiles()
    if profile_key in profiles and profiles[profile_key].get("commandline"):
        return
    escaped=",".join("'"+n.replace("'","''")+"'" for n in names)
    script=(
        "$p=Get-CimInstance Win32_Process | Where-Object { @("+escaped+") -contains $_.Name } | "
        "Select-Object -First 1 Name,ExecutablePath,CommandLine; "
        "if($p){$p | ConvertTo-Json -Compress}"
    )
    ok,out=run_powershell(script,timeout=8)
    if not ok or not out.strip():
        return
    try:
        obj=json.loads(out)
        cmd=str(obj.get("CommandLine") or "")
        exe=str(obj.get("ExecutablePath") or "")
        if exe and cmd:
            profiles[profile_key]={"name":obj.get("Name"),"exe":exe,"commandline":cmd,"captured_at":now_iso()}
            _save_profiles(profiles)
            log(f"PROFILE CAPTURED {profile_key} exe={exe}")
    except Exception as exc:
        log(f"PROFILE PARSE ERROR {profile_key} {type(exc).__name__}")

def _port_open(host:str,port:int,timeout:float=1.5)->bool:
    try:
        with socket.create_connection((host,port),timeout=timeout):
            return True
    except Exception:
        return False

def _http_ok(url:str,timeout:float=2.5)->bool:
    try:
        req=urllib.request.Request(url,headers={"User-Agent":"LENVRAK-Edge/0.14.0"})
        with urllib.request.urlopen(req,timeout=timeout) as resp:
            return 200 <= int(resp.status) < 500
    except Exception:
        return False

def _start_saved_profile(profile_key:str)->tuple[bool,str]:
    p=_load_profiles().get(profile_key) or {}
    cmd=str(p.get("commandline") or "").strip()
    exe=str(p.get("exe") or "").strip()
    if not cmd or not exe or not Path(exe).exists():
        return False,f"No existe perfil de recuperación válido para {profile_key}."
    try:
        # Windows parses the exact command line; this preserves Laragon/GNS3 arguments previously observed.
        creation=getattr(subprocess,"CREATE_NO_WINDOW",0) | getattr(subprocess,"DETACHED_PROCESS",0)
        subprocess.Popen(cmd,creationflags=creation,close_fds=True)
        return True,f"Proceso iniciado desde perfil capturado: {exe}"
    except Exception as exc:
        return False,f"{type(exc).__name__}: {exc}"


def post_api(path: str, payload: dict[str, Any], timeout: int = 8) -> tuple[bool, dict[str, Any]]:
    raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        API_URL + path,
        data=raw,
        method="POST",
        headers={
            "Content-Type": "application/json",
            "X-LENVRAK-EDGE-TOKEN": TOKEN,
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            body = json.loads(response.read() or b"{}")
            return 200 <= response.status < 300, body
    except urllib.error.HTTPError as exc:
        try:
            detail = json.loads(exc.read() or b"{}")
        except Exception:
            detail = {"error": str(exc)}
        return False, detail
    except Exception as exc:
        return False, {"error": f"{type(exc).__name__}: {exc}"}



def get_api(path: str, timeout: int = 8) -> tuple[bool, Any]:
    req=urllib.request.Request(API_URL+path,method="GET",headers={"X-LENVRAK-EDGE-TOKEN":TOKEN})
    try:
        with urllib.request.urlopen(req,timeout=timeout) as response:
            return 200<=response.status<300,json.loads(response.read() or b"[]")
    except Exception as exc:
        return False,{"error":f"{type(exc).__name__}: {exc}"}

def check_target(target: dict[str, Any]) -> dict[str, Any]:
    code=str(target.get("code") or "MONITOR")
    name=str(target.get("name") or code)
    typ=str(target.get("check_type") or "ping")
    host=str(target.get("host") or "").strip()
    port=int(target.get("port") or 0)
    path=str(target.get("path") or "").strip()
    svc=str(target.get("service_name") or "").strip()
    ok=False;status="Unknown";detail=""
    try:
        if typ=="windows_service":
            success,output=run_powershell("(Get-Service -Name '"+svc.replace("'","''")+"' -ErrorAction Stop).Status.ToString()",timeout=8)
            status=output.strip() if success else "Unavailable"
            ok=success and status.lower()=="running"
            detail=f"Servicio Windows {svc}"
        elif typ=="ping":
            proc=subprocess.run(["ping","-n","1","-w","1200",host],capture_output=True,text=True,timeout=5,creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
            ok=proc.returncode==0;status="Online" if ok else "Offline";detail=f"Ping {host}"
        elif typ=="tcp":
            with socket.create_connection((host,port),timeout=2.5):
                pass
            ok=True;status="Open";detail=f"TCP {host}:{port}"
        elif typ=="http":
            base=host.rstrip("/") if host.startswith(("http://","https://")) else f"http://{host}"+(f":{port}" if port else "")
            url=base+(path if path.startswith("/") else ("/"+path if path else "/"))
            req=urllib.request.Request(url,headers={"User-Agent":"LENVRAK-Edge/0.12.0"})
            with urllib.request.urlopen(req,timeout=3.0) as resp:
                sc=int(resp.status)
            ok=200<=sc<500;status=f"HTTP {sc}";detail=url
        else:
            status="Unsupported";detail=f"Tipo no soportado: {typ}"
    except Exception as exc:
        status="Offline";detail=f"{type(exc).__name__}: {exc}"
    if ok:
        low=(code+" "+name).lower()
        if port==3306 or "mysql" in low or "mariadb" in low:
            _capture_process_profile("mysql_local",["mysqld.exe","mariadbd.exe"])
        if port==3080 or "gns3" in low:
            _capture_process_profile("gns3_controller",["gns3server.exe","gns3.exe"])
    return {"key":f"target:{code}","name":name,"status":status,"ok":ok,"asset":code,"detail":detail,"checked_at":now_iso(),"target":target}

def send_target_detection(check: dict[str, Any]) -> tuple[bool, dict[str, Any]]:
    t=check.get("target") or {}
    source=str(t.get("source") or "edge")
    name=str(t.get("name") or t.get("code") or "Activo")
    origin="LENVRAK Access" if source=="access" else "LENVRAK Edge"
    title=f"Access: Terminal {name} fuera de línea" if source=="access" else f"{name} no disponible"
    desc=(f"LENVRAK Edge detectó automáticamente que la terminal {name} no responde. No se generó desde una simulación."
          if source=="access" else f"LENVRAK Edge detectó automáticamente una falla real en {name}. Comprobación: {t.get('check_type')} · {check.get('detail')}.")
    ev={"monitor_code":t.get("code"),"check_type":t.get("check_type"),"host":t.get("host"),"port":t.get("port"),
        "path":t.get("path"),"service_name":t.get("service_name"),"observed_status":check.get("status"),
        "checked_at":check.get("checked_at"),"source_module":source,
        "ip":t.get("host") if t.get("check_type")=="ping" else "",
        "location":t.get("location"),"area":t.get("area"),
        "organization_id":t.get("organization_id")}
    return post_api("/api/v1/edge/detections",{
        "monitor_key":check["key"],"title":title,
        "type":"asistencia" if source=="access" else str(t.get("category") or "general"),
        "severity":t.get("severity") or "media","asset":t.get("code") or name,
        "site":t.get("site") or "Sede principal","description":desc,"evidence":ev,
        "origin":origin,"auto_orchestrate":bool(t.get("auto_orchestrate",True))
    })

def valid_ip(value: str) -> bool:
    parts = value.split(".")
    if len(parts) != 4:
        return False
    try:
        return all(0 <= int(x) <= 255 and str(int(x)) == x for x in parts)
    except Exception:
        return False


def execute_runbook(payload: dict[str, Any]) -> dict[str, Any]:
    runbook = str(payload.get("runbook", ""))
    asset = str(payload.get("asset", ""))
    evidence = payload.get("evidence") or {}

    if runbook == "PRN-SVC-001":
        if not is_admin():
            return {"ok": False, "message": "Edge Agent necesita ejecutarse como Administrador para reiniciar Print Spooler.", "runbook": runbook}
        ok, output = run_powershell("Restart-Service -Name Spooler -Force -ErrorAction Stop; (Get-Service -Name Spooler).Status.ToString()")
        return {"ok": ok, "message": "Print Spooler reiniciado." if ok else "No se pudo reiniciar Print Spooler.", "output": output, "runbook": runbook, "asset": asset}

    if runbook == "ATT-CONN-001":
        ip = str(evidence.get("ip", ""))
        if not valid_ip(ip):
            return {"ok": False, "message": "ATT-CONN-001 requiere evidence.ip válido; no se ejecutó ninguna acción.", "runbook": runbook, "asset": asset}
        proc = subprocess.run(["ping", "-n", "2", "-w", "1200", ip], capture_output=True, text=True, timeout=10, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        return {"ok": proc.returncode == 0, "message": "Terminal responde a ping." if proc.returncode == 0 else "Terminal no responde a ping.", "output": (proc.stdout or "")[-4000:], "runbook": runbook, "asset": asset}

    if runbook == "MYSQL-LARAGON-001":
        host=str(evidence.get("host") or "127.0.0.1").lower()
        port=int(evidence.get("port") or 3306)
        if host not in {"127.0.0.1","localhost","::1"} or port!=3306:
            return {"ok":False,"message":"MYSQL-LARAGON-001 solo está autorizado para MySQL local 127.0.0.1:3306.","runbook":runbook,"asset":asset}
        if _port_open("127.0.0.1",3306):
            return {"ok":True,"message":"MySQL ya se encontraba disponible en TCP 3306.","runbook":runbook,"asset":asset,"already_recovered":True}
        ok,msg=_start_saved_profile("mysql_local")
        if not ok:
            return {"ok":False,"message":msg+" Inicie MySQL manualmente una vez para que LENVRAK capture su perfil seguro.","runbook":runbook,"asset":asset}
        for _ in range(20):
            if _port_open("127.0.0.1",3306):
                return {"ok":True,"message":"MySQL fue iniciado mediante el perfil seguro previamente observado.","runbook":runbook,"asset":asset}
            time.sleep(0.5)
        return {"ok":False,"message":"Se intentó iniciar MySQL, pero TCP 3306 no quedó disponible.","runbook":runbook,"asset":asset}

    if runbook == "GNS3-CTRL-001":
        host=str(evidence.get("host") or "127.0.0.1").lower()
        port=int(evidence.get("port") or 3080)
        if host not in {"127.0.0.1","localhost","::1"} or port!=3080:
            return {"ok":False,"message":"GNS3-CTRL-001 solo está autorizado para el Controller local en 127.0.0.1:3080.","runbook":runbook,"asset":asset}
        url="http://127.0.0.1:3080/v2/version"
        if _http_ok(url):
            return {"ok":True,"message":"GNS3 Controller ya se encontraba disponible.","runbook":runbook,"asset":asset,"already_recovered":True}
        ok,msg=_start_saved_profile("gns3_controller")
        if not ok:
            # Conservative documented default-location fallback.
            candidates=[
                Path(os.environ.get("ProgramFiles",r"C:\Program Files"))/"GNS3"/"gns3server.exe",
                Path(os.environ.get("ProgramFiles(x86)",r"C:\Program Files (x86)"))/"GNS3"/"gns3server.exe",
            ]
            exe=next((p for p in candidates if p.exists()),None)
            if exe:
                try:
                    subprocess.Popen([str(exe)],creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0)|getattr(subprocess,"DETACHED_PROCESS",0),close_fds=True)
                    ok=True;msg=f"GNS3 Server iniciado desde {exe}."
                except Exception as exc:
                    ok=False;msg=f"{type(exc).__name__}: {exc}"
        if not ok:
            return {"ok":False,"message":msg+" Abra GNS3 una vez para capturar el perfil seguro.","runbook":runbook,"asset":asset}
        for _ in range(24):
            if _http_ok(url):
                return {"ok":True,"message":"GNS3 Controller fue iniciado y su API respondió.","runbook":runbook,"asset":asset}
            time.sleep(0.5)
        return {"ok":False,"message":"Se inició el proceso GNS3, pero /v2/version no respondió.","runbook":runbook,"asset":asset}

    if runbook == "WIN-SVC-RESTART-001":
        svc=str(evidence.get("service_name") or "").strip()
        if not svc or any(ch not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_.-" for ch in svc):
            return {"ok":False,"message":"Nombre de servicio inválido o ausente.","runbook":runbook,"asset":asset}
        if not is_admin():
            return {"ok":False,"message":"Edge Agent necesita privilegios de Administrador.","runbook":runbook,"asset":asset}
        ok,out=run_powershell(f"Restart-Service -Name '{svc}' -Force -ErrorAction Stop; (Get-Service -Name '{svc}').Status.ToString()")
        return {"ok":ok,"message":f"Servicio {svc} reiniciado." if ok else f"No se pudo reiniciar {svc}.","output":out,"runbook":runbook,"asset":asset}

    if runbook == "MYSQL-LARAGON-001":
        passed=_port_open("127.0.0.1",3306,2.0)
        return {"passed":passed,
                "message":"MySQL responde en TCP 3306; recuperación verificada." if passed else "MySQL continúa sin responder en TCP 3306.",
                "runbook":runbook,"asset":asset}

    if runbook == "GNS3-CTRL-001":
        passed=_http_ok("http://127.0.0.1:3080/v2/version",3.0)
        return {"passed":passed,
                "message":"GNS3 Controller responde en /v2/version; recuperación verificada." if passed else "GNS3 Controller no responde en /v2/version.",
                "runbook":runbook,"asset":asset}

    if runbook == "WIN-SVC-RESTART-001":
        svc=str(evidence.get("service_name") or "").strip()
        if not svc:
            return {"passed":False,"message":"No hay service_name para verificar.","runbook":runbook,"asset":asset}
        ok,out=run_powershell(f"(Get-Service -Name '{svc}' -ErrorAction Stop).Status.ToString()",timeout=8)
        passed=ok and "Running" in out
        return {"passed":passed,"message":f"Servicio {svc} Running." if passed else f"Servicio {svc} no quedó Running.","output":out,"runbook":runbook,"asset":asset}

    if runbook == "DIAG-GENERAL-001":
        ok, output = run_powershell("$os=Get-CimInstance Win32_OperatingSystem; Write-Output ($env:COMPUTERNAME + ' | ' + $os.Caption + ' | FreeMB=' + [math]::Round($os.FreePhysicalMemory/1024,0))")
        return {"ok": ok, "message": "Diagnóstico general recopilado; requiere decisión técnica antes del cierre.", "output": output, "runbook": runbook, "asset": asset, "diagnostic_only": True}

    return {"ok": False, "message": f"Runbook no permitido por Edge Agent: {runbook}", "runbook": runbook}


def verify_runbook(payload: dict[str, Any]) -> dict[str, Any]:
    runbook = str(payload.get("runbook", ""))
    asset = str(payload.get("asset", ""))
    evidence = payload.get("evidence") or {}

    if runbook == "PRN-SVC-001":
        ok, output = run_powershell("(Get-Service -Name Spooler -ErrorAction Stop).Status.ToString()")
        passed = ok and "Running" in output
        return {"passed": passed, "message": "Print Spooler está en ejecución; runbook verificado." if passed else "Print Spooler no quedó en estado Running.", "output": output, "runbook": runbook, "asset": asset}

    if runbook == "ATT-CONN-001":
        ip = str(evidence.get("ip", ""))
        if not valid_ip(ip):
            return {"passed": False, "message": "No hay IP válida para verificar la terminal.", "runbook": runbook, "asset": asset}
        proc = subprocess.run(["ping", "-n", "2", "-w", "1200", ip], capture_output=True, text=True, timeout=10, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        passed = proc.returncode == 0
        return {"passed": passed, "message": "Conectividad de terminal verificada." if passed else "La terminal continúa sin responder.", "output": (proc.stdout or "")[-4000:], "runbook": runbook, "asset": asset}

    if runbook == "DIAG-GENERAL-001":
        return {"passed": False, "message": "DIAG-GENERAL-001 es diagnóstico, no remediación. Escalar para decisión técnica.", "runbook": runbook, "asset": asset}

    return {"passed": False, "message": f"Runbook no permitido: {runbook}", "runbook": runbook, "asset": asset}


def check_spooler() -> dict[str, Any]:
    ok, output = run_powershell("(Get-Service -Name Spooler -ErrorAction Stop).Status.ToString()", timeout=8)
    status = output.strip() if ok else "Unknown"
    good = status.lower() == "running"
    return {
        "key": "windows-service:Spooler",
        "name": "Print Spooler",
        "status": status,
        "ok": good,
        "asset": "IMP-ADM-01",
        "detail": "Servicio de cola de impresión de Windows",
        "checked_at": now_iso(),
    }


def send_telemetry(checks: list[dict[str, Any]]) -> None:
    post_api("/api/v1/edge/telemetry", {
        "agent": {
            "service": "lenvrak-edge-agent",
            "version": "0.14.0",
            "hostname": os.environ.get("COMPUTERNAME", "windows"),
            "administrator": is_admin(),
        },
        "monitoring": {"active": True, "interval_seconds": MONITOR_INTERVAL},
        "checks": checks,
    })


def send_detection(check: dict[str, Any]) -> tuple[bool, dict[str, Any]]:
    return post_api("/api/v1/edge/detections", {
        "monitor_key": check["key"],
        "title": "Servicio Print Spooler detenido",
        "type": "impresora",
        "severity": "media",
        "asset": "IMP-ADM-01",
        "site": "Sede principal",
        "description": "LENVRAK Edge detectó automáticamente que el servicio Print Spooler de Windows se encuentra detenido. La falla fue observada por monitoreo continuo, sin registro manual del usuario.",
        "evidence": {
            "service": "Spooler",
            "observed_status": check["status"],
            "hostname": os.environ.get("COMPUTERNAME", "windows"),
            "checked_at": check["checked_at"],
            "source": "WMI/PowerShell",
        },
    })


def monitor_loop() -> None:
    global LATEST_CHECKS
    previous={}
    targets=[]
    last_refresh=0.0
    log(f"MONITOR START interval={MONITOR_INTERVAL}s api={API_URL}")
    print(f"[MONITOR] Continuo ACTIVO cada {MONITOR_INTERVAL}s | API={API_URL}")
    while not MONITOR_STOP.is_set():
        now=time.time()
        if now-last_refresh>=10:
            ok,body=get_api("/api/v1/monitors/agent-targets")
            if ok and isinstance(body,list):
                targets=body
            last_refresh=now
        checks=[check_spooler()]+[check_target(t) for t in targets]
        LATEST_CHECKS=checks
        send_telemetry(checks)
        for check in checks:
            key=str(check.get("key") or "")
            cur=str(check.get("status") or "")
            prev=previous.get(key)
            if not check.get("ok") and prev!=cur:
                ok,res=send_detection(check) if key=="windows-service:Spooler" else send_target_detection(check)
                code=res.get("incident_code","sin código")
                print(f"[MONITOR] FALLA: {check.get('name')}={cur} -> Sentinel {code} | {res.get('state','error')}")
                log(f"DETECTION {key}={cur} ok={ok} result={res}")
            elif check.get("ok") and prev and prev!=cur:
                print(f"[MONITOR] RECUPERADO: {check.get('name')}={cur}")
                log(f"RECOVERY {key}={cur}")
            previous[key]=cur
        MONITOR_STOP.wait(MONITOR_INTERVAL)
    log("MONITOR STOP")


class Handler(BaseHTTPRequestHandler):
    server_version = "LENVRAKEdge/0.14.0"

    def log_message(self, fmt: str, *args: Any) -> None:
        log(f"HTTP {self.address_string()} {fmt % args}")

    def _authorized(self) -> bool:
        return bool(TOKEN) and self.headers.get("X-LENVRAK-EDGE-TOKEN", "") == TOKEN

    def _json(self, status: int, payload: dict[str, Any]) -> None:
        raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self) -> None:
        if self.path != "/health":
            return self._json(404, {"ok": False, "error": "not_found"})
        if not self._authorized():
            return self._json(401, {"ok": False, "error": "unauthorized"})
        return self._json(200, {
            "ok": True,
            "service": "lenvrak-edge-agent",
            "version": "0.14.0",
            "administrator": is_admin(),
            "hostname": os.environ.get("COMPUTERNAME", "windows"),
            "monitoring": True,
            "interval_seconds": MONITOR_INTERVAL,
            "checks": LATEST_CHECKS,
        })

    def do_POST(self) -> None:
        if not self._authorized():
            return self._json(401, {"ok": False, "error": "unauthorized"})
        try:
            length = min(int(self.headers.get("Content-Length", "0") or "0"), 1024 * 1024)
            body = json.loads(self.rfile.read(length) or b"{}")
            if not isinstance(body, dict):
                raise ValueError("body must be object")
        except Exception as exc:
            return self._json(400, {"ok": False, "error": "invalid_json", "detail": str(exc)})

        if self.path == "/v1/runbooks/execute":
            result = execute_runbook(body)
            log(f"EXECUTE {body.get('incident_code')} {body.get('runbook')} ok={result.get('ok')}")
            return self._json(200, result)
        if self.path == "/v1/runbooks/verify":
            result = verify_runbook(body)
            log(f"VERIFY {body.get('incident_code')} {body.get('runbook')} passed={result.get('passed')}")
            return self._json(200, result)
        if self.path == "/v1/monitor/scan":
            check = check_spooler()
            send_telemetry([check])
            result = {"ok": True, "check": check}
            if not check["ok"]:
                _, detection = send_detection(check)
                result["detection"] = detection
            return self._json(200, result)
        return self._json(404, {"ok": False, "error": "not_found"})


def main() -> None:
    if os.name != "nt":
        print("Este agente está diseñado para Windows.")
        raise SystemExit(2)
    if not TOKEN:
        print("EDGE_AGENT_TOKEN no configurado. Ejecute scripts\\windows\\07_CONFIGURAR_EDGE_AGENT.bat")
        raise SystemExit(2)
    STATE.mkdir(parents=True, exist_ok=True)
    log(f"START bind={BIND}:{PORT} admin={is_admin()}")
    print(f"LENVRAK Edge Agent 0.14.0 | http://{BIND}:{PORT} | Administrador={is_admin()}")
    thread = threading.Thread(target=monitor_loop, name="lenvrak-edge-monitor", daemon=True)
    thread.start()
    server = ThreadingHTTPServer((BIND, PORT), Handler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        MONITOR_STOP.set()
        server.server_close()
        log("STOP")


if __name__ == "__main__":
    main()
