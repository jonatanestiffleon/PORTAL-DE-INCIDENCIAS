@echo off
setlocal
cd /d "%~dp0\..\.."

net session >nul 2>&1
if not "%errorlevel%"=="0" (
  echo Solicitando permisos de Administrador para LENVRAK Edge Agent...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)

echo.
echo ===============================================
echo   LENVRAK Edge Agent 0.9.8 - Configuracion
echo ===============================================
echo.

where python >nul 2>&1
if not "%errorlevel%"=="0" (
  echo ERROR: Python no esta disponible en PATH.
  pause
  exit /b 1
)

python scripts\edge_agent\configure_edge_agent.py
if not "%errorlevel%"=="0" (
  echo ERROR configurando Edge Agent.
  pause
  exit /b 1
)

echo.
echo Reconstruyendo API con la configuracion del agente...
docker compose up -d --build api
if not "%errorlevel%"=="0" (
  echo ERROR reconstruyendo la API.
  pause
  exit /b 1
)

echo.
echo Iniciando Edge Agent como Administrador...
echo IMPORTANTE: deje esta ventana abierta durante la prueba.
echo.
python scripts\edge_agent\windows_edge_agent.py

endlocal
