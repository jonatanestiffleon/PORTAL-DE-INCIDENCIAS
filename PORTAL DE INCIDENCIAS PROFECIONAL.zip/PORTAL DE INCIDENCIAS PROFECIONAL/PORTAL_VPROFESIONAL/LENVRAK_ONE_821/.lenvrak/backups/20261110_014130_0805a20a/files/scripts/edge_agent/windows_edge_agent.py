from __future__ import annotations

import ctypes
import json
import os
import subprocess
import sys
import threading
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
STATE = ROOT / ".lenvrak"
LOG = STATE / "edge_agent.log"


def load_dotenv() -> dict[str, str]:
    values: dict[str, str] = {}
    path = ROOT / ".env"
    if not path.exists():
        return values
    for raw in path.read_text(encoding="utf-8", errors="ignore").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = value.strip().strip('"').strip("'")
    return values


ENV = load_dotenv()
TOKEN = os.getenv("LENVRAK_EDGE_TOKEN") or ENV.get("EDGE_AGENT_TOKEN", "")
BIND = os.getenv("LENVRAK_EDGE_BIND") or ENV.get("EDGE_AGENT_BIND", "0.0.0.0")
PORT = int(os.getenv("LENVRAK_EDGE_PORT") or ENV.get("EDGE_AGENT_PORT", "8780"))


def log(message: str) -> None:
    STATE.mkdir(parents=True, exist_ok=True)
    line = f"{datetime.now().isoformat(timespec='seconds')} {message}\n"
    with LOG.open("a", encoding="utf-8") as fh:
        fh.write(line)


def is_admin() -> bool:
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def run_powershell(script: str, timeout: int = 30) -> tuple[bool, str]:
    try:
        proc = subprocess.run(
            ["powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", script],
            capture_output=True,
            text=True,
            timeout=timeout,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        text = (proc.stdout or proc.stderr or "").strip()
        return proc.returncode == 0, text[-4000:]
    except Exception as exc:
        return False, f"{type(exc).__name__}: {exc}"


def valid_ip(value: str) -> bool:
    parts = value.split(".")
    if len(parts) != 4:
        return False
    try:
        return all(0 <= int(x) <= 255 and str(int(x)) == x for x in parts)
    except Exception:
        return False


def execute_runbook(payload: dict[str, Any]) -> dict[str, Any]:
    runbook = str(payload.get("runbook", ""))
    asset = str(payload.get("asset", ""))
    evidence = payload.get("evidence") or {}

    if runbook == "PRN-SVC-001":
        if not is_admin():
            return {"ok": False, "message": "Edge Agent necesita ejecutarse como Administrador para reiniciar Print Spooler.", "runbook": runbook}
        ok, output = run_powershell("Restart-Service -Name Spooler -Force -ErrorAction Stop; (Get-Service -Name Spooler).Status.ToString()")
        return {"ok": ok, "message": "Print Spooler reiniciado." if ok else "No se pudo reiniciar Print Spooler.", "output": output, "runbook": runbook, "asset": asset}

    if runbook == "ATT-CONN-001":
        ip = str(evidence.get("ip", ""))
        if not valid_ip(ip):
            return {"ok": False, "message": "ATT-CONN-001 requiere evidence.ip válido; no se ejecutó ninguna acción.", "runbook": runbook, "asset": asset}
        proc = subprocess.run(["ping", "-n", "2", "-w", "1200", ip], capture_output=True, text=True, timeout=10, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        return {"ok": proc.returncode == 0, "message": "Terminal responde a ping." if proc.returncode == 0 else "Terminal no responde a ping.", "output": (proc.stdout or "")[-4000:], "runbook": runbook, "asset": asset}

    if runbook == "DIAG-GENERAL-001":
        ok, output = run_powershell("$os=Get-CimInstance Win32_OperatingSystem; Write-Output ($env:COMPUTERNAME + ' | ' + $os.Caption + ' | FreeMB=' + [math]::Round($os.FreePhysicalMemory/1024,0))")
        return {"ok": ok, "message": "Diagnóstico general recopilado; requiere decisión técnica antes del cierre.", "output": output, "runbook": runbook, "asset": asset, "diagnostic_only": True}

    return {"ok": False, "message": f"Runbook no permitido por Edge Agent: {runbook}", "runbook": runbook}


def verify_runbook(payload: dict[str, Any]) -> dict[str, Any]:
    runbook = str(payload.get("runbook", ""))
    asset = str(payload.get("asset", ""))
    evidence = payload.get("evidence") or {}

    if runbook == "PRN-SVC-001":
        ok, output = run_powershell("(Get-Service -Name Spooler -ErrorAction Stop).Status.ToString()")
        passed = ok and "Running" in output
        return {"passed": passed, "message": "Print Spooler está en ejecución; runbook verificado." if passed else "Print Spooler no quedó en estado Running.", "output": output, "runbook": runbook, "asset": asset}

    if runbook == "ATT-CONN-001":
        ip = str(evidence.get("ip", ""))
        if not valid_ip(ip):
            return {"passed": False, "message": "No hay IP válida para verificar la terminal.", "runbook": runbook, "asset": asset}
        proc = subprocess.run(["ping", "-n", "2", "-w", "1200", ip], capture_output=True, text=True, timeout=10, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        passed = proc.returncode == 0
        return {"passed": passed, "message": "Conectividad de terminal verificada." if passed else "La terminal continúa sin responder.", "output": (proc.stdout or "")[-4000:], "runbook": runbook, "asset": asset}

    if runbook == "DIAG-GENERAL-001":
        return {"passed": False, "message": "DIAG-GENERAL-001 es diagnóstico, no remediación. Escalar para decisión técnica.", "runbook": runbook, "asset": asset}

    return {"passed": False, "message": f"Runbook no permitido: {runbook}", "runbook": runbook, "asset": asset}


class Handler(BaseHTTPRequestHandler):
    server_version = "LENVRAKEdge/0.9.8"

    def log_message(self, fmt: str, *args: Any) -> None:
        log(f"HTTP {self.address_string()} {fmt % args}")

    def _authorized(self) -> bool:
        return bool(TOKEN) and self.headers.get("X-LENVRAK-EDGE-TOKEN", "") == TOKEN

    def _json(self, status: int, payload: dict[str, Any]) -> None:
        raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self) -> None:
        if self.path != "/health":
            return self._json(404, {"ok": False, "error": "not_found"})
        if not self._authorized():
            return self._json(401, {"ok": False, "error": "unauthorized"})
        return self._json(200, {"ok": True, "service": "lenvrak-edge-agent", "version": "0.9.8", "administrator": is_admin(), "hostname": os.environ.get("COMPUTERNAME", "windows")})

    def do_POST(self) -> None:
        if not self._authorized():
            return self._json(401, {"ok": False, "error": "unauthorized"})
        try:
            length = min(int(self.headers.get("Content-Length", "0") or "0"), 1024 * 1024)
            body = json.loads(self.rfile.read(length) or b"{}")
            if not isinstance(body, dict):
                raise ValueError("body must be object")
        except Exception as exc:
            return self._json(400, {"ok": False, "error": "invalid_json", "detail": str(exc)})

        if self.path == "/v1/runbooks/execute":
            result = execute_runbook(body)
            log(f"EXECUTE {body.get('incident_code')} {body.get('runbook')} ok={result.get('ok')}")
            return self._json(200, result)
        if self.path == "/v1/runbooks/verify":
            result = verify_runbook(body)
            log(f"VERIFY {body.get('incident_code')} {body.get('runbook')} passed={result.get('passed')}")
            return self._json(200, result)
        return self._json(404, {"ok": False, "error": "not_found"})


def main() -> None:
    if os.name != "nt":
        print("Este agente está diseñado para Windows.")
        raise SystemExit(2)
    if not TOKEN:
        print("EDGE_AGENT_TOKEN no configurado. Ejecute scripts\\windows\\07_CONFIGURAR_EDGE_AGENT.bat")
        raise SystemExit(2)
    STATE.mkdir(parents=True, exist_ok=True)
    log(f"START bind={BIND}:{PORT} admin={is_admin()}")
    print(f"LENVRAK Edge Agent 0.9.8 | http://{BIND}:{PORT} | Administrador={is_admin()}")
    server = ThreadingHTTPServer((BIND, PORT), Handler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
        log("STOP")


if __name__ == "__main__":
    main()
