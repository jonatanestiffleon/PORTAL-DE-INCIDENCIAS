from pathlib import Path
import secrets

ROOT = Path(__file__).resolve().parents[2]
ENV = ROOT / ".env"


def read_lines():
    if not ENV.exists():
        return []
    return ENV.read_text(encoding="utf-8").splitlines()


def upsert(lines, key, value):
    prefix = key + "="
    out = []
    found = False
    for line in lines:
        if line.strip().startswith(prefix):
            out.append(prefix + value)
            found = True
        else:
            out.append(line)
    if not found:
        out.append(prefix + value)
    return out


def main():
    lines = read_lines()
    current = ""
    for line in lines:
        if line.strip().startswith("EDGE_AGENT_TOKEN="):
            current = line.split("=", 1)[1].strip()
            break
    token = current or secrets.token_urlsafe(36)
    for key, value in [
        ("EDGE_AGENT_URL", "http://host.docker.internal:8780"),
        ("EDGE_AGENT_TOKEN", token),
        ("EDGE_AGENT_TIMEOUT_SECONDS", "20"),
        ("EDGE_AGENT_PORT", "8780"),
        ("EDGE_AGENT_BIND", "0.0.0.0"),
    ]:
        lines = upsert(lines, key, value)
    ENV.write_text("\n".join(lines).rstrip() + "\n", encoding="utf-8")
    print("Configuración Edge Agent guardada en .env")
    print("Puerto: 8780")
    print("Token: configurado (no se muestra por seguridad)")


if __name__ == "__main__":
    main()
