@echo off
cd /d "%~dp0\..\.."
docker compose up -d --build
echo.
echo WEB:  http://127.0.0.1:8080
echo API:  http://127.0.0.1:8000/docs
echo N8N:  http://127.0.0.1:5678
pause
