@echo off
cd /d "%~dp0\..\.."
title LENVRAK Update Manager
py tools\update_manager\server.py
pause
