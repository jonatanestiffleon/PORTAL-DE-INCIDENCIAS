# Despliegue

## Ver solo la interfaz
Desde la raíz:
```powershell
py -m http.server 8080 -d apps/web
```
Abrir `http://127.0.0.1:8080`.

## Stack completo con Docker
```powershell
docker compose up -d --build
```
- Web: http://127.0.0.1:8080
- API / Swagger: http://127.0.0.1:8000/docs
- n8n: http://127.0.0.1:5678

## Antes de producción
- cambiar contraseñas demo;
- HTTPS;
- Cognito/OIDC;
- backups;
- Secrets Manager;
- WAF/Access;
- registros y alertas;
- pruebas;
- políticas de retención;
- revisión legal de datos personales/biométricos.
