@echo off
cd /d "%~dp0\..\.."
echo LENVRAK One - Demo
echo http://127.0.0.1:8080
start "" http://127.0.0.1:8080
py -m http.server 8080 -d apps\web
pause
