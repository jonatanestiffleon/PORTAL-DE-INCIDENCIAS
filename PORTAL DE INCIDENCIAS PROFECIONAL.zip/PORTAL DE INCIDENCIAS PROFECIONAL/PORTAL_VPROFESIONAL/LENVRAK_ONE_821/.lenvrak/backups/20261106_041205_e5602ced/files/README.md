# LENVRAK One · 821 Requirements Edition

Plataforma profesional construida alrededor de **LENVRAK Sentinel: Portal de Reporte de Incidentes**.

## Abrir ya, sin instalar nada extra
1. Descomprime.
2. Abre la carpeta en VS Code.
3. Abre PowerShell.
4. Ejecuta:
```powershell
py -m http.server 8080 -d apps/web
```
5. Abre:
`http://127.0.0.1:8080`

También puedes ejecutar `scripts/windows/01_ABRIR_DEMO.bat`.

## Stack profesional
Requiere Docker Desktop:
```powershell
docker compose up -d --build
```

Web: `http://127.0.0.1:8080`
API: `http://127.0.0.1:8000/docs`
n8n: `http://127.0.0.1:5678`

## Módulos
Sentinel · Resolve AI · Access · Edge · Network Lab · Operator · Automate/n8n · Autorizaciones · Economics · Procurement · Reports · Integrations · Updates · Audit · Leo.

## Seguridad
No hay contraseñas, tokens ni claves reales en el ZIP. Las integraciones se activan después con credenciales seguras.

## Importante
Los 821 requisitos incluyen funciones que dependen de cuentas, hardware y APIs externas. Esta entrega contiene una **demo funcional, backend modular, agentes base, runbooks, workflows, infraestructura y conectores preparados**. Ver `docs/STATUS.md` para distinguir lo ejecutable ahora de lo que necesita conexión real.


## Update Manager
Para iniciar LENVRAK y el actualizador:
```powershell
scripts\windows\00_INICIAR_LENVRAK_DEMO_Y_UPDATER.bat
```
O en dos terminales:
```powershell
py tools\update_manager\server.py
py -m http.server 8080 -d apps\web
```
Copia el token del Update Manager en **Actualizaciones**.
