@echo off
cd /d "%~dp0\..\.."
start "LENVRAK Update Manager" cmd /k py tools\update_manager\server.py
timeout /t 2 >nul
start "" http://127.0.0.1:8080
py -m http.server 8080 -d apps\web
pause
