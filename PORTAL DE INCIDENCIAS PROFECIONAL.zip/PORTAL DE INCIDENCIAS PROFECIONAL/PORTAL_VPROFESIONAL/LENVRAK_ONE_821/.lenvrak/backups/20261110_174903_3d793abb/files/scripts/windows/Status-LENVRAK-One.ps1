$Root=(Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path

function TestUrl([string]$Url){
    try{
        $null=Invoke-WebRequest -Uri $Url -UseBasicParsing -TimeoutSec 2
        return $true
    }catch{
        return $false
    }
}

$rows=@()

$rows += [pscustomobject]@{
    Componente='LENVRAK Web'; Puerto=8090
    Estado=if(TestUrl 'http://127.0.0.1:8090/'){'ONLINE'}else{'OFFLINE'}
}
$rows += [pscustomobject]@{
    Componente='API'; Puerto=8000
    Estado=if(TestUrl 'http://127.0.0.1:8000/health'){'ONLINE'}else{'OFFLINE'}
}
$rows += [pscustomobject]@{
    Componente='n8n'; Puerto=5678
    Estado=if(TestUrl 'http://127.0.0.1:5678/'){'ONLINE'}else{'OFFLINE'}
}
$rows += [pscustomobject]@{
    Componente='Update Manager'; Puerto=8765
    Estado=if(TestUrl 'http://127.0.0.1:8765/health'){'ONLINE'}else{'OFFLINE'}
}

try{
    $h=Invoke-RestMethod -Uri 'http://127.0.0.1:8000/api/v1/runbooks/agent-health' -TimeoutSec 3
    $edge=if($h.ok -and $h.state -eq 'online'){'ONLINE'}else{'OFFLINE'}
}catch{
    $edge='OFFLINE'
}
$rows += [pscustomobject]@{Componente='Edge Agent';Puerto=8780;Estado=$edge}

try{
    $lh=Get-NetTCPConnection -LocalPort 8790 -State Listen -ErrorAction SilentlyContinue
    $helper=if($lh){'ONLINE'}else{'OFFLINE'}
}catch{
    $helper='OFFLINE'
}
$rows += [pscustomobject]@{Componente='Laragon Helper';Puerto=8790;Estado=$helper}

Write-Host ''
$rows | Format-Table -AutoSize
Write-Host ''

$online=@($rows|Where-Object {$_.Estado -eq 'ONLINE'}).Count
if($online -eq 6){
    Write-Host 'LENVRAK LISTO: 6/6 componentes ONLINE.' -ForegroundColor Green
}else{
    Write-Host "LENVRAK PARCIAL: $online/6 componentes ONLINE." -ForegroundColor Yellow
}

Write-Host ''
Write-Host "Logs: $Root\.lenvrak\launcher" -ForegroundColor Cyan
Write-Host ''
Read-Host 'Presione ENTER para cerrar'
