from __future__ import annotations
import json
import os
import subprocess
import socket
import time
import ctypes
from ctypes import wintypes
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ENV = ROOT / ".env"
BIND = "127.0.0.1"
PORT = 8790

def env_value(key: str, default: str = "") -> str:
    if ENV.exists():
        for line in ENV.read_text(encoding="utf-8", errors="ignore").splitlines():
            if line.strip().startswith(key + "="):
                return line.split("=", 1)[1].strip()
    return os.environ.get(key, default)

TOKEN = env_value("EDGE_AGENT_TOKEN", "")

def run_ps(script: str, timeout: int = 25) -> tuple[bool, str]:
    p = subprocess.run(
        ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script],
        capture_output=True,
        text=True,
        timeout=timeout,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    out = ((p.stdout or "") + "\n" + (p.stderr or "")).strip()
    return p.returncode == 0, out[-5000:]

def laragon_start_all() -> dict:
    """
    Native Windows adapter for Laragon 2026.
    Finds the visible top-level Laragon window and clicks the MySQL switch
    using coordinates relative to the Laragon CLIENT area, never absolute
    desktop coordinates. Then verifies TCP 3306 itself.
    """
    if os.name != "nt":
        return {"ok":False,"action":"laragon_mysql_native","output":"WINDOWS_REQUIRED"}

    user32=ctypes.windll.user32
    try:
        user32.SetProcessDPIAware()
    except Exception:
        pass

    # ctypes definitions.
    EnumWindowsProc=ctypes.WINFUNCTYPE(ctypes.c_bool,wintypes.HWND,wintypes.LPARAM)
    user32.EnumWindows.argtypes=[EnumWindowsProc,wintypes.LPARAM]
    user32.IsWindowVisible.argtypes=[wintypes.HWND]
    user32.GetWindowTextLengthW.argtypes=[wintypes.HWND]
    user32.GetWindowTextW.argtypes=[wintypes.HWND,wintypes.LPWSTR,ctypes.c_int]
    user32.GetClientRect.argtypes=[wintypes.HWND,ctypes.POINTER(wintypes.RECT)]
    user32.ClientToScreen.argtypes=[wintypes.HWND,ctypes.POINTER(wintypes.POINT)]
    user32.ShowWindow.argtypes=[wintypes.HWND,ctypes.c_int]
    user32.SetForegroundWindow.argtypes=[wintypes.HWND]
    user32.SetCursorPos.argtypes=[ctypes.c_int,ctypes.c_int]
    user32.mouse_event.argtypes=[wintypes.DWORD,wintypes.DWORD,wintypes.DWORD,wintypes.DWORD,ctypes.c_void_p]

    windows=[]

    @EnumWindowsProc
    def enum_cb(hwnd,lparam):
        try:
            if not user32.IsWindowVisible(hwnd):
                return True
            n=user32.GetWindowTextLengthW(hwnd)
            if n<=0:
                return True
            buf=ctypes.create_unicode_buffer(n+1)
            user32.GetWindowTextW(hwnd,buf,n+1)
            title=buf.value.strip()
            if "laragon" not in title.lower():
                return True
            rect=wintypes.RECT()
            if not user32.GetClientRect(hwnd,ctypes.byref(rect)):
                return True
            w=max(0,rect.right-rect.left)
            h=max(0,rect.bottom-rect.top)
            if w>300 and h>250:
                windows.append((w*h,hwnd,title,w,h))
        except Exception:
            pass
        return True

    user32.EnumWindows(enum_cb,0)

    if not windows:
        exe=Path(r"C:\laragon\laragon.exe")
        if not exe.exists():
            return {"ok":False,"action":"laragon_mysql_native","output":"LARAGON_WINDOW_NOT_FOUND_AND_EXE_MISSING"}
        try:
            subprocess.Popen([str(exe)],creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
        except Exception as exc:
            return {"ok":False,"action":"laragon_mysql_native","output":f"LARAGON_START_FAILED:{type(exc).__name__}:{exc}"}
        time.sleep(2.0)
        user32.EnumWindows(enum_cb,0)

    if not windows:
        return {"ok":False,"action":"laragon_mysql_native","output":"LARAGON_VISIBLE_WINDOW_NOT_FOUND"}

    # If more than one Laragon window exists, use the largest visible client area.
    windows.sort(key=lambda x:x[0],reverse=True)
    _,hwnd,title,width,height=windows[0]

    # Restore and focus the exact Laragon main window.
    SW_RESTORE=9
    user32.ShowWindow(hwnd,SW_RESTORE)
    user32.SetForegroundWindow(hwnd)
    time.sleep(0.45)

    # If MySQL already recovered while we were preparing, don't click.
    def port_open()->bool:
        try:
            with socket.create_connection(("127.0.0.1",3306),timeout=0.8):
                return True
        except Exception:
            return False

    if port_open():
        return {
            "ok":True,
            "action":"laragon_mysql_native",
            "output":f"MYSQL_ALREADY_ON|title={title}|client={width}x{height}",
        }

    # Laragon 2026 v8.7 main UI:
    # MySQL switch center is ~16.5% from client-left and ~29.5% from client-top.
    # Coordinates are relative to Laragon's own window and scale with it.
    # Calibrated from Laragon 2026 v8.7.0 main window:
    # MySQL switch center is about 13% from client-left and 28.7% from client-top.
    candidates=[
        (0.130,0.287),
        (0.125,0.287),
        (0.135,0.287),
    ]

    LEFTDOWN=0x0002
    LEFTUP=0x0004
    attempts=[]

    for idx,(rx,ry) in enumerate(candidates,1):
        client_pt=wintypes.POINT(int(width*rx),int(height*ry))
        if not user32.ClientToScreen(hwnd,ctypes.byref(client_pt)):
            attempts.append(f"{idx}:CLIENT_TO_SCREEN_FAILED")
            continue

        x,y=int(client_pt.x),int(client_pt.y)
        user32.SetForegroundWindow(hwnd)
        user32.SetCursorPos(x,y)
        time.sleep(0.15)
        user32.mouse_event(LEFTDOWN,0,0,0,None)
        user32.mouse_event(LEFTUP,0,0,0,None)
        attempts.append(f"{idx}:CLICK={x},{y};ratio={rx:.3f},{ry:.3f}")

        # MySQL normally starts quickly; wait long enough to avoid double-toggling.
        for _ in range(10):
            if port_open():
                return {
                    "ok":True,
                    "action":"laragon_mysql_native",
                    "output":"MYSQL_NATIVE_CLICK_OK|"
                             +f"title={title}|client={width}x{height}|"
                             +";".join(attempts),
                }
            time.sleep(0.5)

    return {
        "ok":False,
        "action":"laragon_mysql_native",
        "output":"MYSQL_NATIVE_CLICK_FAILED|"
                 +f"title={title}|client={width}x{height}|"
                 +";".join(attempts),
    }

class Handler(BaseHTTPRequestHandler):
    server_version = "LENVRAKLaragonHelper/0.15.5"

    def log_message(self, fmt, *args):
        pass

    def _json(self, status: int, data: dict):
        raw = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def _auth(self) -> bool:
        return bool(TOKEN) and self.headers.get("X-LENVRAK-EDGE-TOKEN", "") == TOKEN

    def do_GET(self):
        if self.path != "/health":
            return self._json(404, {"ok": False, "error": "not_found"})
        if not self._auth():
            return self._json(401, {"ok": False, "error": "unauthorized"})
        return self._json(200, {
            "ok": True,
            "service": "lenvrak-laragon-desktop-helper",
            "version": "0.15.5",
            "interactive_session": True,
        })

    def do_POST(self):
        if not self._auth():
            return self._json(401, {"ok": False, "error": "unauthorized"})
        if self.path == "/v1/laragon/start-all":
            result = laragon_start_all()
            return self._json(200 if result["ok"] else 409, result)
        return self._json(404, {"ok": False, "error": "not_found"})

if __name__ == "__main__":
    if os.name != "nt":
        raise SystemExit("Laragon Desktop Helper solo funciona en Windows.")
    if not TOKEN:
        raise SystemExit("EDGE_AGENT_TOKEN no configurado.")
    ThreadingHTTPServer((BIND, PORT), Handler).serve_forever()
