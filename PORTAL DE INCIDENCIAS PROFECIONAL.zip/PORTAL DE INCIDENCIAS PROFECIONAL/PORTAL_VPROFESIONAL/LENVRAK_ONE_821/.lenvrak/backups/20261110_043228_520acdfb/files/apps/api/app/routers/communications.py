from __future__ import annotations

from html import escape
from typing import Literal

import httpx
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import get_db
from ..models import AuditEvent, Incident, NotificationRecipient, VendorContact
from ..settings import settings

router = APIRouter(prefix="/api/v1/communications", tags=["communications"])

ROLES = ("tecnico", "gerente", "dueno")
SPECIALTIES = ("general", "impresoras", "biometria", "redes", "servidores", "software", "hardware")


class RecipientInput(BaseModel):
    role: Literal["tecnico", "gerente", "dueno"]
    name: str = Field(default="", max_length=160)
    email: str = Field(default="", max_length=240)
    enabled: bool = True


class InternalRecipientsInput(BaseModel):
    recipients: list[RecipientInput]


class VendorInput(BaseModel):
    name: str = Field(min_length=2, max_length=160)
    email: str = Field(min_length=5, max_length=240)
    city: str = Field(default="", max_length=120)
    specialty: str = Field(default="general", max_length=80)
    phone: str = Field(default="", max_length=80)
    enabled: bool = True


class ProcurementDispatchInput(BaseModel):
    incident_code: str
    specialty: str | None = None


def _clean_email(value: str) -> str:
    return (value or "").strip().lower()


def _validish_email(value: str) -> bool:
    value = _clean_email(value)
    return bool(value and "@" in value and "." in value.split("@")[-1])


def _infer_specialty(incident: Incident) -> str:
    text = f"{incident.type} {incident.asset} {incident.title}".lower()
    if any(x in text for x in ("imp", "printer", "impres")):
        return "impresoras"
    if any(x in text for x in ("huella", "biometr", "asistencia", "qr-")):
        return "biometria"
    if any(x in text for x in ("vlan", "switch", "router", "red", "wifi", "ap-")):
        return "redes"
    if any(x in text for x in ("srv", "server", "servidor")):
        return "servidores"
    if any(x in text for x in ("windows", "app", "software", "servicio")):
        return "software"
    return "general"


@router.get("/internal")
def get_internal(db: Session = Depends(get_db)):
    rows = {x.role: x for x in db.scalars(select(NotificationRecipient)).all()}
    return [
        {
            "role": role,
            "name": rows[role].name if role in rows else "",
            "email": rows[role].email if role in rows else "",
            "enabled": rows[role].enabled if role in rows else True,
        }
        for role in ROLES
    ]


@router.put("/internal")
def save_internal(data: InternalRecipientsInput, db: Session = Depends(get_db)):
    incoming = {x.role: x for x in data.recipients}
    for role in ROLES:
        item = incoming.get(role)
        if not item:
            continue
        row = db.scalar(select(NotificationRecipient).where(NotificationRecipient.role == role))
        if not row:
            row = NotificationRecipient(role=role)
            db.add(row)
        row.name = item.name.strip()
        row.email = _clean_email(item.email)
        row.enabled = item.enabled
    db.add(AuditEvent(actor="communications", action="internal_recipients.updated", detail="tecnico,gerente,dueno"))
    db.commit()
    return get_internal(db)


@router.get("/vendors")
def list_vendors(db: Session = Depends(get_db)):
    rows = db.scalars(select(VendorContact).order_by(VendorContact.name)).all()
    return [
        {
            "id": x.id,
            "name": x.name,
            "email": x.email,
            "city": x.city,
            "specialty": x.specialty,
            "phone": x.phone,
            "enabled": x.enabled,
        }
        for x in rows
    ]


@router.post("/vendors", status_code=201)
def add_vendor(data: VendorInput, db: Session = Depends(get_db)):
    if not _validish_email(data.email):
        raise HTTPException(422, "Correo de proveedor inválido")
    specialty = (data.specialty or "general").strip().lower()
    if specialty not in SPECIALTIES:
        specialty = "general"
    obj = VendorContact(
        name=data.name.strip(),
        email=_clean_email(data.email),
        city=data.city.strip(),
        specialty=specialty,
        phone=data.phone.strip(),
        enabled=data.enabled,
    )
    db.add(obj)
    db.add(AuditEvent(actor="procurement", action="vendor.created", detail=f"{obj.name} {obj.specialty}"))
    db.commit(); db.refresh(obj)
    return {
        "id": obj.id, "name": obj.name, "email": obj.email, "city": obj.city,
        "specialty": obj.specialty, "phone": obj.phone, "enabled": obj.enabled
    }


@router.delete("/vendors/{vendor_id}")
def delete_vendor(vendor_id: int, db: Session = Depends(get_db)):
    obj = db.get(VendorContact, vendor_id)
    if not obj:
        raise HTTPException(404, "Proveedor no encontrado")
    db.delete(obj)
    db.add(AuditEvent(actor="procurement", action="vendor.deleted", detail=f"{obj.name}"))
    db.commit()
    return {"ok": True}


def _quote_email(incident: Incident, vendor: VendorContact, specialty: str):
    subject = f"LENVRAK Procurement · Solicitud de cotización · {incident.code}"
    html = f"""<!doctype html><html><body style="font-family:Arial,sans-serif;background:#f3f7f9;padding:22px;color:#17313c">
<div style="max-width:680px;margin:auto;background:white;border:1px solid #dce7ec;border-radius:14px;overflow:hidden">
<div style="background:#071925;color:white;padding:22px"><b style="color:#43d9c8;letter-spacing:1px">LENVRAK PROCUREMENT</b><h2>Solicitud de cotización</h2></div>
<div style="padding:24px">
<p>Estimado proveedor <b>{escape(vendor.name)}</b>:</p>
<p>Solicitamos una cotización para atender el siguiente incidente:</p>
<table style="width:100%;border-collapse:collapse">
<tr><td style="padding:7px;color:#607783">Incidente</td><td><b>{escape(incident.code)} · {escape(incident.title)}</b></td></tr>
<tr><td style="padding:7px;color:#607783">Activo</td><td>{escape(incident.asset or "N/A")}</td></tr>
<tr><td style="padding:7px;color:#607783">Severidad</td><td>{escape((incident.severity or "").upper())}</td></tr>
<tr><td style="padding:7px;color:#607783">Especialidad</td><td>{escape(specialty)}</td></tr>
</table>
<p>Por favor indicar: <b>diagnóstico/propuesta, precio, transporte, plazo de atención, garantía y disponibilidad</b>.</p>
<p style="font-size:12px;color:#718892">Esta solicitud fue generada automáticamente por LENVRAK One.</p>
</div></div></body></html>"""
    return subject, html


@router.post("/procurement/dispatch")
async def dispatch_procurement(data: ProcurementDispatchInput, db: Session = Depends(get_db)):
    incident = db.scalar(select(Incident).where(Incident.code == data.incident_code))
    if not incident:
        raise HTTPException(404, "Incidente no encontrado")

    specialty = (data.specialty or _infer_specialty(incident)).strip().lower()
    rows = list(db.scalars(select(VendorContact).where(VendorContact.enabled == True)).all())
    vendors = [x for x in rows if x.specialty in {specialty, "general"} and _validish_email(x.email)]
    if not vendors:
        return {
            "ok": False,
            "state": "no_vendors",
            "incident_code": incident.code,
            "specialty": specialty,
            "sent": 0,
        }

    webhook = settings.n8n_base_url.rstrip("/") + "/webhook/lenvrak-procurement-provider"
    sent = []
    errors = []
    async with httpx.AsyncClient(timeout=7.0) as client:
        for vendor in vendors:
            subject, html = _quote_email(incident, vendor, specialty)
            payload = {
                "incident_code": incident.code,
                "vendor_id": vendor.id,
                "vendor_name": vendor.name,
                "vendor_email": vendor.email,
                "specialty": specialty,
                "subject": subject,
                "html": html,
            }
            try:
                r = await client.post(webhook, json=payload)
                r.raise_for_status()
                sent.append(vendor.email)
            except Exception as exc:
                errors.append({"email": vendor.email, "error": type(exc).__name__})

    db.add(AuditEvent(
        actor="procurement",
        action="quote_requests.dispatched",
        detail=f"{incident.code} specialty={specialty} sent={len(sent)} errors={len(errors)}"
    ))
    db.commit()
    return {
        "ok": len(sent) > 0,
        "state": "sent" if sent else "workflow_unavailable",
        "incident_code": incident.code,
        "specialty": specialty,
        "sent": len(sent),
        "recipients": sent,
        "errors": errors,
    }
