from __future__ import annotations

from html import escape
from typing import Any

import httpx
from sqlalchemy import select

from ..db import SessionLocal
from ..models import Incident, NotificationRecipient
from ..settings import settings

RANK = {"baja": 1, "media": 2, "alta": 3, "critica": 4}


def _event_label(event: str) -> str:
    return {
        "created": "INCIDENTE DETECTADO",
        "approval_required": "APROBACIÓN REQUERIDA",
        "escalated": "INCIDENTE ESCALADO",
        "resolved": "INCIDENTE RESUELTO",
    }.get(event, "ACTUALIZACIÓN DE INCIDENTE")


def _recipient_roles(event: str, severity: str) -> set[str]:
    rank = RANK.get(severity, 2)
    if event in {"approval_required", "escalated"}:
        return {"tecnico", "gerente", "dueno"}
    if event == "created":
        roles = {"tecnico"}
        if rank >= 3: roles.add("gerente")
        if rank >= 4: roles.add("dueno")
        return roles
    if event == "resolved":
        roles = {"tecnico"}
        if rank >= 3: roles.add("gerente")
        if rank >= 4: roles.add("dueno")
        return roles
    return {"tecnico"}


def _configured_recipients(event: str, severity: str) -> list[dict[str, str]]:
    wanted = _recipient_roles(event, severity)
    db = SessionLocal()
    try:
        rows = db.scalars(select(NotificationRecipient)).all()
        result = []
        seen = set()
        for row in rows:
            email = (row.email or "").strip().lower()
            if row.enabled and row.role in wanted and email and "@" in email and email not in seen:
                result.append({"role": row.role, "name": row.name or row.role, "email": email})
                seen.add(email)
        return result
    finally:
        db.close()


def build_alert_payload(incident: Incident, event: str = "created", detail: str = "") -> dict[str, Any]:
    label = _event_label(event)
    severity = (incident.severity or "media").upper()
    subject = f"LENVRAK · {label} · {severity} · {incident.code}"
    recipients = _configured_recipients(event, incident.severity or "media")

    state_help = {
        "created": "Revise Sentinel para iniciar o seguir la resolución.",
        "approval_required": "Se requiere decisión humana. Ingrese a LENVRAK → Autorizaciones.",
        "escalated": "La remediación automática no pudo verificarse. Requiere atención técnica o proveedor.",
        "resolved": "La remediación fue ejecutada y verificada por LENVRAK.",
    }.get(event, "Revise el incidente en LENVRAK.")

    html = f"""<!doctype html><html><body style="margin:0;background:#eef3f6;font-family:Arial,sans-serif;color:#13222d">
<div style="max-width:720px;margin:24px auto;background:#fff;border-radius:16px;overflow:hidden;border:1px solid #d8e3e8">
<div style="background:#07131d;color:#fff;padding:24px 28px"><div style="font-size:12px;letter-spacing:2px;color:#40d6da;font-weight:700">LENVRAK ONE · INCIDENT ALERT</div><h1 style="margin:8px 0 0;font-size:24px">{escape(label)}</h1></div>
<div style="padding:26px 28px">
<table style="width:100%;border-collapse:collapse;font-size:14px">
<tr><td style="padding:8px 0;color:#607786">Código</td><td style="padding:8px 0;font-weight:700">{escape(incident.code)}</td></tr>
<tr><td style="padding:8px 0;color:#607786">Incidente</td><td style="padding:8px 0;font-weight:700">{escape(incident.title)}</td></tr>
<tr><td style="padding:8px 0;color:#607786">Activo</td><td style="padding:8px 0">{escape(incident.asset or "N/A")}</td></tr>
<tr><td style="padding:8px 0;color:#607786">Severidad</td><td style="padding:8px 0;font-weight:700">{escape(severity)}</td></tr>
<tr><td style="padding:8px 0;color:#607786">Origen</td><td style="padding:8px 0">{escape(incident.origin or "")}</td></tr>
<tr><td style="padding:8px 0;color:#607786">Estado</td><td style="padding:8px 0;font-weight:700">{escape(incident.status or "")}</td></tr>
</table>
<div style="margin-top:20px;padding:16px;border-left:4px solid #29c8cb;background:#f4fbfb">{escape(detail or incident.diagnosis or incident.description or "")}</div>
<p style="margin-top:20px"><b>{escape(state_help)}</b></p>
</div></div></body></html>"""

    return {
        "code": incident.code,
        "event": event,
        "severity": incident.severity,
        "subject": subject,
        "html": html,
        "text": f"{label} · {incident.code} · {incident.title} · {incident.status}",
        "recipients": recipients,
        "recipients_csv": ",".join(x["email"] for x in recipients),
    }


async def dispatch_incident_alert(incident: Incident, event: str = "created", detail: str = "") -> dict[str, Any]:
    if not settings.incident_alerts_enabled:
        return {"ok": True, "state": "disabled"}

    payload = build_alert_payload(incident, event, detail)
    if not payload["recipients"]:
        return {"ok": True, "state": "no_recipients"}

    url = settings.n8n_base_url.rstrip("/") + settings.incident_alert_webhook_path
    try:
        async with httpx.AsyncClient(timeout=6.0) as client:
            response = await client.post(url, json=payload)
            response.raise_for_status()
        return {"ok": True, "state": "sent_to_n8n", "recipients": payload["recipients"]}
    except Exception as exc:
        return {"ok": False, "state": "workflow_unavailable", "error": type(exc).__name__}
