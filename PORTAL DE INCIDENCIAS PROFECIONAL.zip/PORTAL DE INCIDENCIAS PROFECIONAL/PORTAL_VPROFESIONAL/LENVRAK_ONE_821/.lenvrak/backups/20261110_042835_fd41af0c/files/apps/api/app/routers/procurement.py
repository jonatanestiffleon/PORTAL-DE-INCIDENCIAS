from fastapi import APIRouter,Depends
from sqlalchemy.orm import Session
from sqlalchemy import select
from ..db import get_db
from ..models import Quote
from ..schemas import QuoteInput
from ..services.procurement_service import rank_quotes
router=APIRouter(prefix="/api/v1/procurement",tags=["procurement"])
@router.post("/quotes",status_code=201)
def create_quote(q:QuoteInput,db:Session=Depends(get_db)):
    obj=Quote(**q.model_dump());db.add(obj);db.commit();db.refresh(obj);return obj
@router.get("/quotes/{incident_code}/rank")
def rank(incident_code:str,downtime_hour_cost:float=20,db:Session=Depends(get_db)):
    items=db.scalars(select(Quote).where(Quote.incident_code==incident_code)).all()
    data=[{"vendor":x.vendor,"city":x.city,"option":x.option,"price":x.price,"transport":x.transport,"delivery_hours":x.delivery_hours,"warranty_days":x.warranty_days} for x in items]
    return rank_quotes(data,downtime_hour_cost)
