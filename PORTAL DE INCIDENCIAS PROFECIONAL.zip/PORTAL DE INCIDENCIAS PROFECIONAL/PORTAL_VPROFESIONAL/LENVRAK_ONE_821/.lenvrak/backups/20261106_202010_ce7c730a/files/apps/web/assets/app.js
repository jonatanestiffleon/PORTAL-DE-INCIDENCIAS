(function(){
"use strict";
const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];
const KEY="lenvrak821",AUDIT="lenvrak821audit";
const API_BASE="http://127.0.0.1:8000";
let session={name:"",role:"owner",org:""},networkMode="guide",opMode="observe";
let remoteIncidents=[],remoteReady=false;

function incidents(){return remoteReady?remoteIncidents:state().incidents}
function normalizeIncident(i){
  return {
    id:i.code||i.id,
    title:i.title||"",
    asset:i.asset||"N/A",
    severity:i.severity||"media",
    status:i.status||"detectado",
    origin:i.origin||"Portal manual",
    owner:i.owner||"Sin asignar",
    description:i.description||"",
    diagnosis:i.diagnosis||"",
    resolution:i.resolution||"",
    created_at:i.created_at||null,
    resolved_at:i.resolved_at||null,
    cost:0
  }
}
async function api(path,options={}){
  const r=await fetch(API_BASE+path,{
    ...options,
    headers:{"Content-Type":"application/json",...(options.headers||{})}
  });
  const body=await r.json().catch(()=>({}));
  if(!r.ok)throw new Error(body.detail||body.error||`HTTP ${r.status}`);
  return body
}
async function syncIncidents(showToast=false){
  try{
    const rows=await api("/api/v1/incidents");
    remoteIncidents=Array.isArray(rows)?rows.map(normalizeIncident):[];
    remoteReady=true;
    renderDashboard();renderIncidents();renderResolve();
    if(showToast)toast(`Sentinel sincronizado: ${remoteIncidents.length} incidente(s)`);
    return true
  }catch(e){
    remoteReady=false;
    if(showToast)toast("API no disponible; usando modo local.");
    console.warn("LENVRAK API sync:",e);
    return false
  }
}

const seed={incidents:[
{id:"INC-0182",title:"Impresora de Administración no imprime",asset:"IMP-ADM-01",severity:"media",status:"diagnosticando",origin:"LENVRAK Edge",owner:"Mesa técnica",description:"Ping y SNMP correctos; cola con trabajos; servicio de impresión detenido.",cost:80},
{id:"INC-0181",title:"Terminal biométrica fuera de línea",asset:"HUELLA-02",severity:"alta",status:"esperando_aprobacion",origin:"LENVRAK Access",owner:"Mesa técnica",description:"Terminal sin comunicación durante 15 minutos.",cost:120},
{id:"INC-0180",title:"Correo de suplantación reportado",asset:"PC-ADM-03",severity:"critica",status:"escalado",origin:"Portal manual",owner:"SOC Nivel 1",description:"Mensaje simulado solicita credenciales.",cost:250},
{id:"INC-0179",title:"Servicio de aplicación detenido",asset:"SRV-APP-01",severity:"alta",status:"resuelto",origin:"LENVRAK Edge",owner:"Infraestructura",description:"Runbook reinició servicio y validó healthcheck.",cost:180},
{id:"INC-0178",title:"VLAN 20 sin conectividad",asset:"GNS3-LAB",severity:"baja",status:"resuelto",origin:"Network Lab",owner:"Network Lab",description:"Puerto trunk corregido y validado.",cost:0}],
quotes:[{vendor:"Tecno Tingo",city:"Tingo María",option:"Reparación",price:180,transport:0,hours:3,warranty:30},{vendor:"Soporte Huánuco",city:"Huánuco",option:"Reparación",price:150,transport:15,hours:7,warranty:90},{vendor:"Proveedor Lima",city:"Lima",option:"Reemplazo",price:550,transport:20,hours:30,warranty:365}],
auths:[{name:"Consultar telemetría",risk:"VERDE",scope:"Todos los activos",mode:"Automático"},{name:"Reiniciar Print Spooler",risk:"VERDE",scope:"Impresoras Windows",mode:"Automático"},{name:"Reiniciar servidor",risk:"ROJO",scope:"Servidores",mode:"Aprobación humana"}]};
function state(){let x;try{x=JSON.parse(localStorage.getItem(KEY))}catch{}if(!x){x=structuredClone(seed);localStorage.setItem(KEY,JSON.stringify(x))}return x}function save(x){localStorage.setItem(KEY,JSON.stringify(x))}
function audit(action,detail){let a=[];try{a=JSON.parse(localStorage.getItem(AUDIT))||[]}catch{}a.unshift({time:new Date().toISOString(),user:session.name||"Sistema",action,detail});localStorage.setItem(AUDIT,JSON.stringify(a.slice(0,120)));renderAudit()}
function toast(t){let e=$("#toast");e.textContent=t;e.classList.add("show");setTimeout(()=>e.classList.remove("show"),2200)}function esc(v){return String(v??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}function tag(v){return `<span class="tag ${v}">${v.replaceAll("_"," ")}</span>`}function money(v){return new Intl.NumberFormat("es-PE",{style:"currency",currency:"PEN"}).format(v)}function initials(n){return n.split(/\s+/).slice(0,2).map(x=>x[0]).join("").toUpperCase()}const rank={critica:4,alta:3,media:2,baja:1};
const meta={dashboard:["Centro de Operaciones","Resumen ejecutivo"],sentinel:["LENVRAK Sentinel","Portal de incidentes"],resolve:["Resolve AI","Diagnóstico y remediación"],access:["LENVRAK Access","Sistema de asistencia"],edge:["LENVRAK Edge","Monitoreo"],network:["Network Lab","Redes y laboratorios"],operator:["LENVRAK Operator","Asistente sobre software"],automate:["LENVRAK Automate","n8n como orquestador"],authorizations:["Autorizaciones","Políticas"],economics:["LENVRAK Economics","Impacto económico"],procurement:["LENVRAK Procurement","Cotizaciones"],reports:["Reportes","Audiencias"],integrations:["Integraciones","Servicios externos"],updates:["Actualizaciones","Release management"],audit:["Auditoría","Trazabilidad"]};
function go(v){if(v==="sentinel"||v==="resolve")syncIncidents(false);$$(".view").forEach(x=>x.classList.remove("active"));$(`#view-${v}`)?.classList.add("active");$$(".nav").forEach(x=>x.classList.toggle("active",x.dataset.view===v));$("#pageTitle").textContent=meta[v][0];$("#pageSub").textContent=meta[v][1];$(".sidebar").classList.remove("open");({dashboard:renderDashboard,sentinel:renderIncidents,resolve:renderResolve,edge:renderEdge,network:renderModes,operator:renderOperator,automate:renderAutomations,authorizations:renderAuths,economics:renderEconomics,procurement:renderQuotes,reports:renderReports,integrations:renderIntegrations,audit:renderAudit}[v]||(()=>{}))()}
function login(){session={name:$("#loginName").value.trim()||"Usuario Demo",role:$("#loginRole").value,org:$("#loginOrg").value};$("#userName").textContent=session.name;$("#avatar").textContent=initials(session.name);$("#loginScreen").classList.add("hidden");$("#app").classList.remove("hidden");audit("Inicio de sesión",session.role);renderAll();syncIncidents(true)}
function renderAll(){renderDashboard();renderIncidents();renderResolve();renderEdge();renderModes();renderOperator();renderAutomations();renderAuths();renderEconomics();renderQuotes();renderReports();renderIntegrations();renderAudit()}
function renderDashboard(){let d=incidents(),o=d.filter(i=>i.status!=="resuelto");$("#openBadge").textContent=o.length;$("#kpiCritical").textContent=o.filter(i=>i.severity==="critica").length;$("#kpiWorking").textContent=d.filter(i=>["diagnosticando","remediando","verificando","esperando_aprobacion"].includes(i.status)).length;$("#kpiResolved").textContent=d.filter(i=>i.status==="resuelto").length;$("#kpiSavings").textContent=money(d.filter(i=>i.status==="resuelto").reduce((s,i)=>s+i.cost,0)*.65);$("#priorityRows").innerHTML=[...d].sort((a,b)=>rank[b.severity]-rank[a.severity]).slice(0,5).map(i=>`<tr><td>${i.id}</td><td><b>${esc(i.title)}</b></td><td>${tag(i.severity)}</td><td>${tag(i.status)}</td><td>${esc(i.origin)}</td></tr>`).join("");$("#moduleHealth").innerHTML=["Sentinel","Resolve AI","Access","Edge","Network Lab","Operator","Automate","Economics","Procurement"].map(m=>`<div class="health-item"><i></i><span>${m}</span><small>Demo lista</small></div>`).join("");drawSeverity(d)}
function drawSeverity(d){let c=$("#severityCanvas"),ctx=c.getContext("2d"),vals=["critica","alta","media","baja"].map(s=>d.filter(i=>i.severity===s).length),names=["Crítica","Alta","Media","Baja"],colors=["#ff586d","#ffab45","#e3c24f","#38d47e"],mx=Math.max(...vals,1);ctx.clearRect(0,0,c.width,c.height);ctx.fillStyle="#091a27";ctx.fillRect(0,0,c.width,c.height);vals.forEach((v,i)=>{let x=65+i*165,w=95,h=(v/mx)*145,y=190-h;ctx.fillStyle="#153144";ctx.fillRect(x,40,w,150);ctx.fillStyle=colors[i];ctx.fillRect(x,y,w,h);ctx.font="13px Segoe UI";ctx.textAlign="center";ctx.fillStyle="#fff";ctx.fillText(v,x+w/2,y-8);ctx.fillStyle="#8ba4b4";ctx.fillText(names[i],x+w/2,218)})}
function renderIncidents(){let d=incidents(),q=($("#incidentSearch")?.value||"").toLowerCase(),sv=$("#incidentSeverity")?.value||"",st=$("#incidentStatus")?.value||"";let r=d.filter(i=>(!q||`${i.id} ${i.title} ${i.asset}`.toLowerCase().includes(q))&&(!sv||i.severity===sv)&&(!st||i.status===st)).sort((a,b)=>rank[b.severity]-rank[a.severity]);$("#incidentRows").innerHTML=r.map(i=>`<tr><td>${i.id}</td><td><b>${esc(i.title)}</b></td><td>${esc(i.asset)}</td><td>${tag(i.severity)}</td><td>${tag(i.status)}</td><td>${esc(i.origin)}</td><td><button class="link" data-diagnose="${i.id}">Diagnosticar</button></td></tr>`).join("");$$("[data-diagnose]").forEach(b=>b.onclick=()=>{go("resolve");$("#resolveIncident").value=b.dataset.diagnose;diagnose()})}
function renderResolve(){let s=$("#resolveIncident");if(!s)return;let old=s.value;s.innerHTML=incidents().map(i=>`<option value="${i.id}">${i.id} · ${esc(i.title)}</option>`).join("");if(old)s.value=old}
async function diagnose(){
  let i=incidents().find(x=>x.id===$("#resolveIncident").value);
  if(!i)return;
  $("#diagnosisBox").textContent=`${i.id}\nAnalizando evidencia y estado actual…`;
  if(remoteReady){
    try{
      const res=await api(`/api/v1/incidents/${encodeURIComponent(i.id)}/diagnose`,{method:"POST"});
      $("#diagnosisBox").textContent=
`${i.id}
${res.diagnosis||"Diagnóstico generado."}

Confianza: ${Math.round((res.confidence||0)*100)}%
Runbook: ${res.runbook||"Pendiente"}
Riesgo: ${res.risk||"Pendiente"}
Proveedor: ${res.provider||"LENVRAK Resolve"}`;
      audit("Diagnóstico API",i.id);
      await syncIncidents(false);
      return
    }catch(e){
      $("#diagnosisBox").textContent=`${i.id}\nError al consultar Resolve API: ${e.message}`;
      return
    }
  }
  let d=i.asset.startsWith("IMP")?"Posible cola, Print Spooler, driver o conectividad de impresión.":i.asset.startsWith("HUELLA")?"Posible pérdida de comunicación, energía o sincronización.":i.asset.includes("GNS3")?"Revisar IP, interfaces, VLAN/trunk, routing, OSPF y ACL.":"Requiere telemetría, logs y estado actual.";
  $("#diagnosisBox").textContent=`${i.id}\n${d}\n\nRunbook: ${i.asset.startsWith("IMP")?"PRN-SVC-001":"DIAG-GENERAL-001"}\nRiesgo: ${i.asset.startsWith("IMP")?"VERDE":"AMARILLO"}\nModo local de respaldo.`;
  audit("Diagnóstico local",i.id)
}
function renderEdge(){let ds=[["IMP-ADM-01","Impresora","ONLINE","SNMP OK · Tóner 64%"],["PC-ADM-03","Windows","ONLINE","CPU 23% · RAM 61%"],["HUELLA-02","Asistencia","OFFLINE","Última señal 15 min"],["SW-CORE-01","Switch","ONLINE","Ping/SNMP OK"],["SRV-APP-01","Servidor","ONLINE","Health 200"],["AP-01","WiFi","ONLINE","23 clientes"]];$("#edgeDevices").innerHTML=ds.map(d=>`<article class="device"><div class="device-head"><b>${d[0]}</b><span class="status ${d[2]==="ONLINE"?"ready":""}">${d[2]}</span></div><small>${d[1]}</small><p>${d[3]}</p></article>`).join("")}
const modes=[["automatic","Automático"],["assisted","Asistido"],["guide","Guía"],["tutor","Tutor"],["diagnostic","Diagnóstico"],["repair","Reparación"],["design","Solo diseño"],["exam","Examen"]];
function renderModes(){$("#modeGrid").innerHTML=modes.map(m=>`<button class="mode ${networkMode===m[0]?"selected":""}" data-mode="${m[0]}">${m[1]}</button>`).join("");$$("[data-mode]").forEach(b=>b.onclick=()=>{networkMode=b.dataset.mode;renderModes();toast(`Modo: ${b.textContent}`)})}
function blueprint(){let x=$("#varX").value||"X",y=$("#varY").value||"Y";$("#blueprint").value=`# LENVRAK NETWORK LAB\nMODE=${networkMode}\nX=${x} Y=${y}\nREQ=${$("#networkPrompt").value}\nNOTAS=${$("#networkNotes").value||"ninguna"}\n\n[DISPOSITIVOS]\nR1 R2 R3 R4 R5 R6\nSW1 SW2 SW3 SW4 SW5\nPC1..PC10 SRV1\n\n[ENLACES]\nR1:G0/0 <-> R2:G0/0 NET=10.${x}.12.0/30\nR2:G0/1 <-> R3:G0/0 NET=10.${x}.23.0/30\nR3:G0/1 <-> R4:G0/0 NET=10.${x}.34.0/30\n\n[SERVICIOS]\nOSPF AREA=0\nDHCP\nDNS\nNAT\nACL\n\n[PRUEBAS]\nshow ip interface brief\nshow ip route\nshow ip ospf neighbor\nping end-to-end`;$("#blueprintStatus").textContent="Editable";$("#blueprintMessages").textContent="Borrador creado. Edita cualquier línea antes de aprobar.";audit("Network Lab","Borrador creado")}
function validateBlueprint(){let t=$("#blueprint").value,e=[];if(!/R1/.test(t))e.push("Falta R1");if(!/OSPF/i.test(t))e.push("Falta OSPF");$("#blueprintMessages").textContent=e.length?"Advertencias: "+e.join(", "):"Validación básica correcta.";audit("Network Lab","Validado")}
function approveBlueprint(){$("#blueprintStatus").textContent="APROBADO";$("#blueprintMessages").textContent+="\nListo para generar plan/configuración según el modo.";audit("Network Lab","Aprobado")}
const apps=[["GNS3","API/Controller"],["Packet Tracer","Controller/API cuando aplique"],["n8n","API + navegador"],["AutoCAD","API/Automation + UI"],["ArcGIS","API + UI"],["VS Code","Extensión/API + UI"],["MySQL Workbench","UI Automation"],["MongoDB Compass","UI Automation"],["Navegador","DOM + browser automation"]];
function renderOperator(){$("#appPermissions").innerHTML=apps.map(a=>`<article class="app-card"><h3>${a[0]}</h3><p>${a[1]}</p><select><option>Solo observar</option><option>Guía</option><option>Asistido</option><option>Automático seguro</option><option>Bloqueado</option></select></article>`).join("");$$(".operator-modes .mode").forEach(b=>b.classList.toggle("selected",b.dataset.opmode===opMode))}
function renderAutomations(){let cs=[["01","Incidente crítico","Sentinel → n8n → Resolve"],["02","Asistencia","Access → Sentinel → n8n"],["03","Remediación","Runbook → aprobación → verificación"],["04","Procurement","Falla → cotizaciones"],["05","Reporte ejecutivo","Resumen → Gerencia"],["06","SLA","Sin atender → escalamiento"]];$("#automationCards").innerHTML=cs.map(c=>`<article class="auto-card"><i>${c[0]}</i><div><h3>${c[1]}</h3><p>${c[2]}</p><span class="status ready">Preparado</span></div></article>`).join("")}
function renderAuths(){$("#activeAuths").innerHTML=state().auths.map(a=>`<div class="auth-row"><div><b>${a.name}</b><small>${a.scope} · ${a.mode}</small></div><span class="status ${a.risk==="VERDE"?"ready":""}">${a.risk}</span></div>`).join("")}
function interpretAuth(){let t=$("#authText").value.toLowerCase(),ss=t.includes("impres")?[["Reiniciar Print Spooler","VERDE","Impresoras"],["Limpiar cola","AMARILLO","Impresoras"],["Reinstalar driver","ROJO","Impresoras"]]:[["Recopilar diagnóstico","VERDE","Activo"],["Reiniciar servicio","AMARILLO","Activo"],["Modificar configuración","ROJO","Activo"]];$("#authSuggestions").innerHTML=ss.map(s=>`<div class="suggestion"><div><b>${s[0]}</b><small>${s[1]} · ${s[2]}</small></div><button data-auth="${s[0]}" data-risk="${s[1]}" data-scope="${s[2]}">Autorizar</button></div>`).join("");$$("[data-auth]").forEach(b=>b.onclick=()=>{let d=state();d.auths.push({name:b.dataset.auth,risk:b.dataset.risk,scope:b.dataset.scope,mode:b.dataset.risk==="VERDE"?"Automático":"Aprobación"});save(d);renderAuths();audit("Autorización",b.dataset.auth)})}
function economicCalc(){let r=+$("#ecoReplacement").value||0,c=+$("#ecoRepairs").value||0,h=+$("#ecoHours").value||0,ch=+$("#ecoHourly").value||0,f=+$("#ecoFailures").value||0,p=+$("#ecoPlatform").value||0,total=c+h*ch,ratio=r?total/r*100:0,saved=Math.max(0,f*.6*80-p),rec=ratio>70||f>=15?"Evaluar reemplazo con prioridad":ratio>40||f>=8?"Cotizar reparación y reemplazo":"Continuar con mantenimiento";$("#ecoResult").innerHTML=`<div class="econ-card"><small>Costo de fallas</small><strong>${money(total)}</strong></div><div class="econ-card"><small>% del reemplazo</small><strong>${ratio.toFixed(1)}%</strong></div><div class="econ-card"><small>Ahorro demo</small><strong>${money(saved)}</strong></div><div class="econ-card"><b>${rec}</b></div>`}
function renderEconomics(){if(!$("#ecoResult").innerHTML)economicCalc()}
function renderQuotes(){let rows=state().quotes.map(q=>({...q,total:q.price+q.transport+q.hours*20})).sort((a,b)=>a.total-b.total);$("#quoteRows").innerHTML=rows.map(q=>`<tr><td>${q.vendor}</td><td>${q.city}</td><td>${q.option}</td><td>${money(q.price)}</td><td>${money(q.transport)}</td><td>${q.hours}</td><td>${q.warranty} días</td><td><b>${money(q.total)}</b></td></tr>`).join("");let b=rows[0];$("#procurementRecommendation").textContent=b?`Recomendación demo: ${b.vendor}. Costo económico total: ${money(b.total)}.`:"Sin cotizaciones"}
function addQuote(){let d=state(),n=d.quotes.length+1;d.quotes.push({vendor:`Proveedor ${n}`,city:n%2?"Tingo María":"Huánuco",option:n%2?"Reparación":"Reemplazo",price:120+n*35,transport:10+n*3,hours:2+n*4,warranty:30*n});save(d);renderQuotes();audit("Cotización",`Proveedor ${n}`)}
const audiences=["Técnico","Jefe TI","Administración","Gerente","Dueño","Proveedor externo"];let selectedAudience="Gerente";
function renderReports(){$("#reportAudience").innerHTML=audiences.map(a=>`<button class="audience ${a===selectedAudience?"selected":""}" data-a="${a}">${a}</button>`).join("");$$("[data-a]").forEach(b=>b.onclick=()=>{selectedAudience=b.dataset.a;renderReports()})}
function previewReport(){let i=state().incidents[0],t=selectedAudience==="Técnico"?`${i.id}\nActivo: ${i.asset}\nEvidencia: ${i.description}\nDiagnóstico/runbook/resultados.`:selectedAudience==="Administración"?`${i.id}\nCosto estimado: ${money(i.cost)}\nCotizaciones: ${state().quotes.length}\nDecisión: reparar/reemplazar.`:`RESUMEN ${selectedAudience.toUpperCase()}\n${i.id} · ${i.title}\nImpacto controlado.\nEstado: ${i.status}\nCosto: ${money(i.cost)}\nRecomendación: revisar resolución y costo total.`;$("#reportPreview").textContent=t;audit("Reporte",selectedAudience)}
function renderIntegrations(){let xs=[["AWS","API, Cognito, Lambda, RDS, S3, SSM"],["n8n","Workflows, IA, correo"],["Cloudflare","DNS, WAF, Access, Tunnel"],["Namecheap","Dominio y nameservers"],["OpenAI API","Resolve AI / Leo"],["Google / Gmail","Correo y reportes"],["Sistema escolar","Eventos de asistencia"],["GNS3","Controller/API local"],["Packet Tracer","Controller/API cuando aplique"],["SMTP/WhatsApp","Notificaciones"]];$("#integrationGrid").innerHTML=xs.map(x=>`<article class="integration"><i>${x[0].slice(0,3).toUpperCase()}</i><div><h3>${x[0]}</h3><p>${x[1]}</p></div><span class="status">Preparado</span></article>`).join("")}
function renderAudit(){let a=[];try{a=JSON.parse(localStorage.getItem(AUDIT))||[]}catch{}$("#auditLog").innerHTML=a.length?a.map(i=>`<div class="audit-item"><small>${new Date(i.time).toLocaleString("es-PE")}</small><b>${i.action} · ${i.detail}</b><span>${i.user}</span></div>`).join(""):'<p>Sin acciones.</p>'}
function leoReply(q){q=q.toLowerCase();if(q.includes("network"))return"Network Lab admite texto, variables, archivos y GNS3, con modos Automático, Asistido, Guía, Tutor, Diagnóstico, Reparación, Diseño o Examen.";if(q.includes("cost"))return"Economics compara reparación, inactividad y reemplazo. Procurement agrega cotizaciones y transporte.";if(q.includes("n8n"))return"n8n coordina IA, aprobaciones, correos, compras y escalamiento.";return"Sentinel gestiona el ciclo completo del incidente y los demás módulos se conectan alrededor."}function msg(t,type){let d=document.createElement("div");d.className=`msg ${type}`;d.textContent=t;$("#leoMessages").append(d)}
document.addEventListener("DOMContentLoaded",()=>{$("#loginBtn").onclick=login;$$(".nav").forEach(b=>b.onclick=()=>go(b.dataset.view));$$("[data-go]").forEach(b=>b.onclick=()=>go(b.dataset.go));$("#menuBtn").onclick=()=>$(".sidebar").classList.toggle("open");$("#newIncidentBtn").onclick=()=>$("#incidentDialog").showModal();$("#closeIncidentDialog").onclick=$("#cancelIncident").onclick=()=>$("#incidentDialog").close();["#incidentSearch","#incidentSeverity","#incidentStatus"].forEach(s=>$(s)?.addEventListener("input",renderIncidents));$("#incidentForm").addEventListener("submit",async e=>{
  e.preventDefault();
  let v=Object.fromEntries(new FormData(e.currentTarget));
  if(v.description.trim().length<20)return toast("Descripción mínima: 20 caracteres");
  try{
    const created=await api("/api/v1/incidents",{method:"POST",body:JSON.stringify({
      title:v.title.trim(),type:v.type,severity:v.severity,origin:v.origin,
      asset:v.asset,site:v.site,owner:v.owner,description:v.description.trim(),evidence:{source:"sentinel-web"}
    })});
    remoteReady=true;
    $("#incidentDialog").close();e.currentTarget.reset();
    audit("Incidente creado en API",created.code||created.id);
    await syncIncidents(false);
    toast(`${created.code||created.id} guardado en Sentinel`);
  }catch(err){
    toast("No se pudo guardar en API: "+err.message);
  }
});$("#diagnoseBtn").onclick=diagnose;$("#attSimulate").onclick=async()=>{
  const eventType=$("#attEvent").value,terminalId=$("#attTerminal").value,severity=$("#attSeverity").value;
  const label=$("#attEvent").selectedOptions[0].textContent;
  try{
    const created=await api("/api/v1/access/events",{method:"POST",body:JSON.stringify({
      eventType,terminalId,severity,
      summary:`Evento automático generado por LENVRAK Access: ${label} en ${terminalId}.`,
      site:"Sede principal"
    })});
    remoteReady=true;await syncIncidents(false);
    audit("Evento Access → Sentinel",created.code||created.id);
    toast(`${created.code||created.id} creado automáticamente`);
  }catch(err){toast("Access API: "+err.message)}
};$("#generateBlueprint").onclick=blueprint;$("#validateBlueprint").onclick=validateBlueprint;$("#approveBlueprint").onclick=approveBlueprint;$$(".operator-modes .mode").forEach(b=>b.onclick=()=>{opMode=b.dataset.opmode;renderOperator()});$("#stopAutomation").onclick=()=>{opMode="observe";renderOperator();toast("Automatización detenida")};$("#interpretAuth").onclick=interpretAuth;$("#ecoCalculate").onclick=economicCalc;$("#addQuote").onclick=addQuote;$("#previewReport").onclick=previewReport;$("#voiceConfig").onclick=()=>toast("Voz preparada para activarse en producción.");$("#leoLaunch").onclick=()=>$("#leoPanel").classList.remove("hidden");$("#leoClose").onclick=()=>$("#leoPanel").classList.add("hidden");$$("[data-q]").forEach(b=>b.onclick=()=>{msg(b.textContent,"user");msg(leoReply(b.dataset.q),"bot")});$("#leoForm").addEventListener("submit",e=>{e.preventDefault();let q=$("#leoInput").value.trim();if(!q)return;msg(q,"user");msg(leoReply(q),"bot");$("#leoInput").value=""})});
})();
