from datetime import datetime
from typing import Any

import httpx
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import get_db
from ..models import AuditEvent, Incident, RunbookExecution
from ..schemas import RunbookExecuteRequest
from ..settings import settings
from ..services.notifications import dispatch_incident_alert

router = APIRouter(prefix="/api/v1/runbooks", tags=["runbooks"])

RUNBOOKS: dict[str, dict[str, Any]] = {
    "PRN-SVC-001": {
        "name": "Reiniciar y verificar Print Spooler",
        "risk": "VERDE",
        "auto_allowed": True,
        "requires_agent": True,
    },
    "ATT-CONN-001": {
        "name": "Verificar conectividad de terminal de asistencia",
        "risk": "AMARILLO",
        "auto_allowed": False,
        "requires_agent": True,
    },
    "DIAG-GENERAL-001": {
        "name": "Diagnóstico general seguro",
        "risk": "VERDE",
        "auto_allowed": True,
        "requires_agent": True,
    },
}


def _incident(db: Session, code: str) -> Incident:
    obj = db.scalar(select(Incident).where(Incident.code == code))
    if not obj:
        raise HTTPException(404, "Incident not found")
    return obj


def _execution(db: Session, execution_id: int) -> RunbookExecution:
    obj = db.scalar(select(RunbookExecution).where(RunbookExecution.id == execution_id))
    if not obj:
        raise HTTPException(404, "Runbook execution not found")
    return obj


def _agent_headers() -> dict[str, str]:
    return {"X-LENVRAK-EDGE-TOKEN": settings.edge_agent_token}


async def _agent_post(path: str, payload: dict[str, Any]) -> dict[str, Any]:
    if not settings.edge_agent_url or not settings.edge_agent_token:
        raise RuntimeError("EDGE_AGENT_NOT_CONFIGURED")
    url = settings.edge_agent_url.rstrip("/") + path
    async with httpx.AsyncClient(timeout=settings.edge_agent_timeout_seconds) as client:
        response = await client.post(url, json=payload, headers=_agent_headers())
        response.raise_for_status()
        data = response.json()
        if not isinstance(data, dict):
            raise RuntimeError("EDGE_AGENT_INVALID_RESPONSE")
        return data


@router.get("/catalog")
def catalog():
    return RUNBOOKS


@router.get("/agent-health")
async def agent_health():
    if not settings.edge_agent_url or not settings.edge_agent_token:
        return {"ok": False, "state": "not_configured"}
    try:
        async with httpx.AsyncClient(timeout=4) as client:
            response = await client.get(
                settings.edge_agent_url.rstrip("/") + "/health",
                headers=_agent_headers(),
            )
            return {"ok": response.is_success, "state": "online" if response.is_success else "error", "agent": response.json()}
    except Exception as exc:
        return {"ok": False, "state": "offline", "error": type(exc).__name__}


@router.post("/execute")
async def execute_runbook(data: RunbookExecuteRequest, db: Session = Depends(get_db)):
    incident = _incident(db, data.incident_code)
    definition = RUNBOOKS.get(data.runbook)
    if not definition:
        raise HTTPException(400, f"Runbook no autorizado: {data.runbook}")

    risk = str(definition["risk"])
    execution = RunbookExecution(
        incident_code=incident.code,
        runbook=data.runbook,
        risk=risk,
        status="preparing",
        approved=bool(data.approved),
        requested_by=data.requested_by,
    )
    db.add(execution)

    if risk != "VERDE" and not data.approved:
        incident.status = "esperando_aprobacion"
        execution.status = "approval_required"
        db.add(AuditEvent(actor=data.requested_by, action="runbook.approval_required", detail=f"{incident.code} {data.runbook}"))
        db.commit()
        db.refresh(execution)
        alert = await dispatch_incident_alert(
            incident, "approval_required",
            f"Runbook {data.runbook} · Riesgo {risk}. Se requiere aprobación humana."
        )
        db.add(AuditEvent(actor="notify", action="approval.alert", detail=f"{incident.code} {alert.get('state')}"))
        db.commit()
        return {
            "ok": False,
            "state": "approval_required",
            "execution_id": execution.id,
            "incident_code": incident.code,
            "runbook": data.runbook,
            "risk": risk,
        }

    payload = {
        "execution_id": None,
        "incident_code": incident.code,
        "runbook": data.runbook,
        "asset": incident.asset,
        "site": incident.site,
        "description": incident.description,
        "evidence": incident.evidence or {},
    }

    try:
        agent = await _agent_post("/v1/runbooks/execute", payload)
    except RuntimeError as exc:
        if str(exc) == "EDGE_AGENT_NOT_CONFIGURED":
            incident.status = "esperando_agente"
            execution.status = "waiting_agent"
            execution.agent_output = {"error": "Edge Agent no configurado"}
            db.add(AuditEvent(actor="api", action="runbook.waiting_agent", detail=f"{incident.code} {data.runbook}"))
            db.commit()
            db.refresh(execution)
            return {
                "ok": False,
                "state": "waiting_agent",
                "execution_id": execution.id,
                "incident_code": incident.code,
                "runbook": data.runbook,
                "risk": risk,
            }
        raise
    except Exception as exc:
        incident.status = "escalado"
        execution.status = "agent_error"
        execution.agent_output = {"error": type(exc).__name__}
        db.add(AuditEvent(actor="api", action="runbook.agent_error", detail=f"{incident.code} {data.runbook} {type(exc).__name__}"))
        db.commit()
        db.refresh(execution)
        return {
            "ok": False,
            "state": "agent_error",
            "execution_id": execution.id,
            "incident_code": incident.code,
            "runbook": data.runbook,
            "risk": risk,
            "error": type(exc).__name__,
        }

    execution.agent_output = agent
    if not agent.get("ok"):
        incident.status = "escalado"
        execution.status = "execution_failed"
        db.add(AuditEvent(actor="edge-agent", action="runbook.failed", detail=f"{incident.code} {data.runbook}: {agent.get('message','')[:300]}"))
        db.commit()
        db.refresh(execution)
        return {
            "ok": False,
            "state": "execution_failed",
            "execution_id": execution.id,
            "incident_code": incident.code,
            "runbook": data.runbook,
            "risk": risk,
            "agent": agent,
        }

    incident.status = "verificando"
    execution.status = "executed"
    db.add(AuditEvent(actor="edge-agent", action="runbook.executed", detail=f"{incident.code} {data.runbook}"))
    db.commit()
    db.refresh(execution)
    return {
        "ok": True,
        "state": "executed",
        "execution_id": execution.id,
        "incident_code": incident.code,
        "runbook": data.runbook,
        "risk": risk,
        "agent": agent,
    }


@router.post("/{execution_id}/verify")
async def verify_runbook(execution_id: int, db: Session = Depends(get_db)):
    execution = _execution(db, execution_id)
    incident = _incident(db, execution.incident_code)
    if execution.status not in {"executed", "verification_failed"}:
        return {
            "ok": False,
            "state": execution.status,
            "execution_id": execution.id,
            "incident_code": incident.code,
        }

    payload = {
        "execution_id": execution.id,
        "incident_code": incident.code,
        "runbook": execution.runbook,
        "asset": incident.asset,
        "site": incident.site,
        "description": incident.description,
        "evidence": incident.evidence or {},
    }
    try:
        result = await _agent_post("/v1/runbooks/verify", payload)
    except Exception as exc:
        execution.status = "verification_error"
        execution.verification_output = {"error": type(exc).__name__}
        incident.status = "escalado"
        db.add(AuditEvent(actor="api", action="runbook.verification_error", detail=f"{incident.code} {type(exc).__name__}"))
        db.commit()
        return {
            "ok": False,
            "state": "verification_error",
            "execution_id": execution.id,
            "incident_code": incident.code,
            "error": type(exc).__name__,
        }

    execution.verification_output = result
    if result.get("passed"):
        execution.status = "resolved"
        execution.completed_at = datetime.utcnow()
        incident.status = "resuelto"
        incident.resolution = result.get("message") or f"Runbook {execution.runbook} ejecutado y verificado por LENVRAK Edge."
        incident.resolved_at = datetime.utcnow()
        db.add(AuditEvent(actor="edge-agent", action="incident.auto_resolved", detail=f"{incident.code} {execution.runbook}"))
        db.commit()
        return {
            "ok": True,
            "state": "resolved",
            "execution_id": execution.id,
            "incident_code": incident.code,
            "runbook": execution.runbook,
            "verification": result,
        }

    execution.status = "verification_failed"
    execution.completed_at = datetime.utcnow()
    incident.status = "escalado"
    db.add(AuditEvent(actor="edge-agent", action="runbook.verification_failed", detail=f"{incident.code} {execution.runbook}"))
    db.commit()
    return {
        "ok": False,
        "state": "escalated",
        "execution_id": execution.id,
        "incident_code": incident.code,
        "runbook": execution.runbook,
        "verification": result,
    }


@router.get("/executions/{incident_code}")
def executions_for_incident(incident_code: str, db: Session = Depends(get_db)):
    return db.scalars(
        select(RunbookExecution)
        .where(RunbookExecution.incident_code == incident_code)
        .order_by(RunbookExecution.created_at.desc())
    ).all()


@router.get("/approvals/pending")
def pending_approvals(db: Session = Depends(get_db)):
    executions = db.scalars(
        select(RunbookExecution)
        .where(RunbookExecution.status == "approval_required")
        .order_by(RunbookExecution.created_at.desc())
    ).all()
    rows = []
    for execution in executions:
        incident = db.scalar(select(Incident).where(Incident.code == execution.incident_code))
        rows.append({
            "execution_id": execution.id,
            "incident_code": execution.incident_code,
            "incident_title": incident.title if incident else "Incidente",
            "asset": incident.asset if incident else "N/A",
            "severity": incident.severity if incident else "media",
            "runbook": execution.runbook,
            "risk": execution.risk,
            "status": execution.status,
            "requested_by": execution.requested_by,
            "created_at": execution.created_at,
        })
    return rows


async def _execute_approved(execution: RunbookExecution, incident: Incident, db: Session, actor: str):
    definition = RUNBOOKS.get(execution.runbook)
    if not definition:
        execution.status = "invalid_runbook"
        incident.status = "escalado"
        db.add(AuditEvent(actor=actor, action="approval.invalid_runbook", detail=f"{incident.code} {execution.runbook}"))
        db.commit()
        return {"ok": False, "state": "escalated", "incident_code": incident.code, "execution_id": execution.id}

    execution.approved = True
    execution.status = "approved"
    db.add(AuditEvent(actor=actor, action="runbook.approved", detail=f"{incident.code} {execution.runbook}"))
    db.commit()

    payload = {
        "execution_id": execution.id,
        "incident_code": incident.code,
        "runbook": execution.runbook,
        "asset": incident.asset,
        "site": incident.site,
        "description": incident.description,
        "evidence": incident.evidence or {},
    }

    try:
        agent = await _agent_post("/v1/runbooks/execute", payload)
    except Exception as exc:
        execution.status = "agent_error"
        execution.agent_output = {"error": type(exc).__name__}
        incident.status = "escalado"
        db.add(AuditEvent(actor="api", action="approved_runbook.agent_error", detail=f"{incident.code} {type(exc).__name__}"))
        db.commit()
        await dispatch_incident_alert(incident, "escalated", "Aprobado, pero Edge Agent no pudo ejecutar la acción.")
        return {
            "ok": False,
            "state": "escalated",
            "incident_code": incident.code,
            "execution_id": execution.id,
            "message": "Aprobado, pero Edge Agent no pudo ejecutar la acción.",
        }

    execution.agent_output = agent
    if not agent.get("ok"):
        execution.status = "execution_failed"
        execution.completed_at = datetime.utcnow()
        incident.status = "escalado"
        db.add(AuditEvent(actor="edge-agent", action="approved_runbook.execution_failed", detail=f"{incident.code} {execution.runbook}"))
        db.commit()
        await dispatch_incident_alert(incident, "escalated", agent.get("message") or "La acción aprobada no pudo ejecutarse.")
        return {
            "ok": False,
            "state": "escalated",
            "incident_code": incident.code,
            "execution_id": execution.id,
            "message": agent.get("message") or "La acción aprobada no pudo ejecutarse.",
            "agent": agent,
        }

    incident.status = "verificando"
    execution.status = "executed"
    db.add(AuditEvent(actor="edge-agent", action="approved_runbook.executed", detail=f"{incident.code} {execution.runbook}"))
    db.commit()

    try:
        verification = await _agent_post("/v1/runbooks/verify", payload)
    except Exception as exc:
        execution.status = "verification_error"
        execution.verification_output = {"error": type(exc).__name__}
        execution.completed_at = datetime.utcnow()
        incident.status = "escalado"
        db.add(AuditEvent(actor="api", action="approved_runbook.verification_error", detail=f"{incident.code} {type(exc).__name__}"))
        db.commit()
        await dispatch_incident_alert(incident, "escalated", "La acción se ejecutó, pero no pudo verificarse.")
        return {
            "ok": False,
            "state": "escalated",
            "incident_code": incident.code,
            "execution_id": execution.id,
            "message": "La acción se ejecutó, pero no pudo verificarse.",
        }

    execution.verification_output = verification
    execution.completed_at = datetime.utcnow()
    if verification.get("passed"):
        execution.status = "resolved"
        incident.status = "resuelto"
        incident.resolution = verification.get("message") or f"Runbook {execution.runbook} aprobado, ejecutado y verificado."
        incident.resolved_at = datetime.utcnow()
        db.add(AuditEvent(actor=actor, action="incident.resolved_after_approval", detail=f"{incident.code} {execution.runbook}"))
        db.commit()
        await dispatch_incident_alert(incident, "resolved", incident.resolution)
        return {
            "ok": True,
            "state": "resolved",
            "incident_code": incident.code,
            "execution_id": execution.id,
            "message": incident.resolution,
            "verification": verification,
        }

    execution.status = "verification_failed"
    incident.status = "escalado"
    db.add(AuditEvent(actor="edge-agent", action="approved_runbook.verification_failed", detail=f"{incident.code} {execution.runbook}"))
    db.commit()
    await dispatch_incident_alert(incident, "escalated", verification.get("message") or "La verificación falló; incidente escalado.")
    return {
        "ok": False,
        "state": "escalated",
        "incident_code": incident.code,
        "execution_id": execution.id,
        "message": verification.get("message") or "La verificación falló; incidente escalado.",
        "verification": verification,
    }


@router.post("/approvals/{execution_id}/approve")
async def approve_pending(execution_id: int, actor: str = "operador-web", db: Session = Depends(get_db)):
    execution = _execution(db, execution_id)
    incident = _incident(db, execution.incident_code)
    if execution.status != "approval_required":
        return {
            "ok": execution.status == "resolved",
            "state": execution.status,
            "incident_code": incident.code,
            "execution_id": execution.id,
            "message": "La solicitud ya fue procesada.",
        }
    return await _execute_approved(execution, incident, db, actor)


@router.post("/approvals/{execution_id}/reject")
def reject_pending(execution_id: int, actor: str = "operador-web", db: Session = Depends(get_db)):
    execution = _execution(db, execution_id)
    incident = _incident(db, execution.incident_code)
    if execution.status != "approval_required":
        return {
            "ok": False,
            "state": execution.status,
            "incident_code": incident.code,
            "execution_id": execution.id,
            "message": "La solicitud ya fue procesada.",
        }
    execution.status = "rejected"
    execution.approved = False
    execution.completed_at = datetime.utcnow()
    incident.status = "escalado"
    incident.resolution = "Acción automática rechazada por un operador; requiere atención técnica o decisión manual."
    db.add(AuditEvent(actor=actor, action="runbook.rejected", detail=f"{incident.code} {execution.runbook}"))
    db.commit()
    return {
        "ok": True,
        "state": "escalated",
        "incident_code": incident.code,
        "execution_id": execution.id,
        "message": incident.resolution,
    }
