from fastapi import APIRouter,Depends,HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import select,func
from datetime import datetime
import httpx
from ..db import get_db
from ..models import Incident,AuditEvent
from ..schemas import IncidentCreate
from ..services.ai_service import diagnose as ai_diagnose
from ..settings import settings
from ..services.notifications import dispatch_incident_alert
router=APIRouter(prefix="/api/v1/incidents",tags=["incidents"])
def next_code(db):
    n=db.scalar(select(func.count()).select_from(Incident)) or 0
    return f"INC-{1001+n:04d}"
@router.get("")
def list_incidents(db:Session=Depends(get_db)):
    return db.scalars(select(Incident).order_by(Incident.created_at.desc())).all()
@router.post("",status_code=201)
async def create_incident(data:IncidentCreate,db:Session=Depends(get_db)):
    obj=Incident(code=next_code(db),**data.model_dump());db.add(obj);db.add(AuditEvent(actor="api",action="incident.created",detail=obj.code));db.commit();db.refresh(obj)
    alert=await dispatch_incident_alert(obj,"created")
    db.add(AuditEvent(actor="notify",action="incident.alert",detail=f"{obj.code} {alert.get('state')}"));db.commit()
    return obj
@router.post("/{incident_code}/diagnose")
async def diagnose(incident_code:str,db:Session=Depends(get_db)):
    obj=db.scalar(select(Incident).where(Incident.code==incident_code))
    if not obj: raise HTTPException(404,"Incident not found")
    if obj.status == "resuelto":
        raise HTTPException(409,"Incident already resolved")
    obj.status="diagnosticando"
    res=await ai_diagnose({"code":obj.code,"title":obj.title,"asset":obj.asset,"description":obj.description,"evidence":obj.evidence})
    obj.diagnosis=res.get("diagnosis","")
    db.add(AuditEvent(actor="resolve-ai",action="incident.diagnosed",detail=obj.code))
    db.commit()
    return res

@router.post("/{incident_code}/orchestrate")
async def orchestrate(incident_code:str,db:Session=Depends(get_db)):
    obj=db.scalar(select(Incident).where(Incident.code==incident_code))
    if not obj:
        raise HTTPException(404,"Incident not found")
    if obj.status == "resuelto":
        return {
            "ok": True,
            "state": "already_resolved",
            "incident_code": obj.code,
            "resolution": obj.resolution,
            "resolved_at": obj.resolved_at,
        }
    if obj.status == "esperando_aprobacion":
        return {"ok": True, "state": "approval_required", "incident_code": obj.code}
    if obj.status == "escalado":
        return {"ok": True, "state": "escalated", "incident_code": obj.code, "resolution": obj.resolution}
    if obj.status == "esperando_agente":
        return {"ok": True, "state": "waiting_agent", "incident_code": obj.code}
    if obj.status == "orquestando":
        return {"ok": True,"state":"already_queued","incident_code":obj.code}

    previous_status=obj.status
    obj.status="orquestando"
    db.add(AuditEvent(actor="sentinel",action="incident.orchestration_requested",detail=obj.code))
    db.commit()

    url=settings.n8n_base_url.rstrip("/")+"/webhook/lenvrak-incident"
    try:
        async with httpx.AsyncClient(timeout=8.0) as client:
            response=await client.post(url,json={"code":obj.code,"source":"sentinel"})
            response.raise_for_status()
    except Exception as exc:
        obj.status=previous_status
        db.add(AuditEvent(actor="api",action="incident.orchestration_failed",detail=f"{obj.code} {type(exc).__name__}"))
        db.commit()
        raise HTTPException(503,f"n8n orchestration unavailable: {type(exc).__name__}")

    db.add(AuditEvent(actor="n8n",action="incident.workflow_started",detail=obj.code))
    db.commit()
    return {"ok":True,"state":"started","incident_code":obj.code}
@router.post("/{incident_code}/resolve")
def resolve(incident_code:str,resolution:str,db:Session=Depends(get_db)):
    obj=db.scalar(select(Incident).where(Incident.code==incident_code))
    if not obj: raise HTTPException(404,"Incident not found")
    obj.status="resuelto";obj.resolution=resolution;obj.resolved_at=datetime.utcnow();db.commit();return {"ok":True}
