from fastapi import APIRouter,Depends,HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import select,func
from datetime import datetime
from ..db import get_db
from ..models import Incident,AuditEvent
from ..schemas import IncidentCreate
from ..services.ai_service import diagnose as ai_diagnose
router=APIRouter(prefix="/api/v1/incidents",tags=["incidents"])
def next_code(db):
    n=db.scalar(select(func.count()).select_from(Incident)) or 0
    return f"INC-{1001+n:04d}"
@router.get("")
def list_incidents(db:Session=Depends(get_db)):
    return db.scalars(select(Incident).order_by(Incident.created_at.desc())).all()
@router.post("",status_code=201)
def create_incident(data:IncidentCreate,db:Session=Depends(get_db)):
    obj=Incident(code=next_code(db),**data.model_dump());db.add(obj);db.add(AuditEvent(actor="api",action="incident.created",detail=obj.code));db.commit();db.refresh(obj);return obj
@router.post("/{incident_code}/diagnose")
async def diagnose(incident_code:str,db:Session=Depends(get_db)):
    obj=db.scalar(select(Incident).where(Incident.code==incident_code))
    if not obj: raise HTTPException(404,"Incident not found")
    obj.status="diagnosticando";res=await ai_diagnose({"code":obj.code,"title":obj.title,"asset":obj.asset,"description":obj.description,"evidence":obj.evidence});obj.diagnosis=res.get("diagnosis","");db.commit();return res
@router.post("/{incident_code}/resolve")
def resolve(incident_code:str,resolution:str,db:Session=Depends(get_db)):
    obj=db.scalar(select(Incident).where(Incident.code==incident_code))
    if not obj: raise HTTPException(404,"Incident not found")
    obj.status="resuelto";obj.resolution=resolution;obj.resolved_at=datetime.utcnow();db.commit();return {"ok":True}
