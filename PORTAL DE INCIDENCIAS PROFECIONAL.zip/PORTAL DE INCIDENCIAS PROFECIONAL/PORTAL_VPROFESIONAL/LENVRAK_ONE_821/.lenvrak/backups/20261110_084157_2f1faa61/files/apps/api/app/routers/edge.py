from __future__ import annotations

from datetime import datetime
from typing import Any

import httpx
from fastapi import APIRouter, Depends, Header, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..db import get_db
from ..models import AuditEvent, Incident
from ..settings import settings
from ..services.notifications import dispatch_incident_alert
from ..services.ai_service import diagnose as ai_diagnose
from ..db import SessionLocal

router = APIRouter(prefix="/api/v1/edge", tags=["edge"])

_EDGE_STATUS: dict[str, Any] = {
    "online": False,
    "monitoring": False,
    "last_seen": None,
    "agent": {},
    "checks": [],
}


class EdgeCheck(BaseModel):
    key: str = Field(min_length=3, max_length=160)
    name: str = Field(min_length=2, max_length=160)
    status: str = Field(min_length=1, max_length=80)
    ok: bool
    asset: str = Field(default="N/A", max_length=120)
    detail: str = Field(default="", max_length=1000)
    checked_at: str | None = None


class EdgeTelemetry(BaseModel):
    agent: dict[str, Any] = {}
    monitoring: dict[str, Any] = {}
    checks: list[EdgeCheck] = []


class EdgeDetection(BaseModel):
    monitor_key: str = Field(min_length=3, max_length=160)
    title: str = Field(min_length=3, max_length=160)
    type: str = Field(default="servicio", max_length=60)
    severity: str = Field(default="media", max_length=20)
    asset: str = Field(default="N/A", max_length=120)
    site: str = Field(default="Sede principal", max_length=120)
    description: str = Field(min_length=20, max_length=2000)
    evidence: dict[str, Any] = {}
    origin: str = Field(default="LENVRAK Edge", max_length=80)
    auto_orchestrate: bool = True


def _authorized(token: str | None) -> bool:
    expected = settings.edge_agent_token
    return bool(expected) and bool(token) and token == expected


def _next_code(db: Session) -> str:
    n = db.scalar(select(func.count()).select_from(Incident)) or 0
    return f"INC-{1001+n:04d}"


@router.get("/status")
def status():
    return _EDGE_STATUS


@router.post("/telemetry")
def telemetry(data: EdgeTelemetry, x_lenvrak_edge_token: str | None = Header(default=None)):
    if not _authorized(x_lenvrak_edge_token):
        raise HTTPException(401, "Edge Agent unauthorized")
    _EDGE_STATUS.update({
        "online": True,
        "monitoring": bool(data.monitoring.get("active", True)),
        "last_seen": datetime.utcnow().isoformat() + "Z",
        "agent": data.agent,
        "monitor": data.monitoring,
        "checks": [x.model_dump() for x in data.checks],
    })
    return {"ok": True}


@router.post("/detections")
async def detection(data: EdgeDetection, x_lenvrak_edge_token: str | None = Header(default=None), db: Session = Depends(get_db)):
    if not _authorized(x_lenvrak_edge_token):
        raise HTTPException(401, "Edge Agent unauthorized")

    # Prevent duplicate incidents while the same fault remains active.
    existing_rows = db.scalars(
        select(Incident).where(Incident.origin.in_(["LENVRAK Edge","LENVRAK Access"]), Incident.status.notin_(["resuelto","escalado"]))
        .order_by(Incident.created_at.desc())
        .limit(100)
    ).all()
    for item in existing_rows:
        evidence = item.evidence or {}
        if evidence.get("monitor_key") == data.monitor_key:
            return {"ok": True, "state": "already_open", "incident_code": item.code, "status": item.status}

    evidence = dict(data.evidence or {})
    evidence.update({
        "monitor_key": data.monitor_key,
        "detected_by": "LENVRAK Edge Monitor",
        "detected_at": datetime.utcnow().isoformat() + "Z",
    })
    obj = Incident(
        code=_next_code(db),
        title=data.title,
        type=data.type,
        severity=data.severity if data.severity in {"baja", "media", "alta", "critica"} else "media",
        status="detectado",
        origin=data.origin,
        asset=data.asset,
        site=data.site,
        owner="Mesa técnica",
        description=data.description,
        evidence=evidence,
    )
    db.add(obj)
    db.add(AuditEvent(actor="edge-monitor", action="incident.detected_automatically", detail=f"{obj.code} {data.monitor_key}"))
    db.commit()
    db.refresh(obj)
    alert = await dispatch_incident_alert(obj, "created")
    db.add(AuditEvent(actor="notify", action="incident.alert", detail=f"{obj.code} {alert.get('state')}"))
    db.commit()

    return await _auto_process_detected_incident(obj, db, source="edge-detection")


async def _auto_process_detected_incident(obj: Incident, db: Session, source: str = "edge") -> dict[str, Any]:
    """
    Automatic pipeline for incidents discovered by Edge:
    detect -> notify -> diagnose -> safe orchestration OR escalation.
    It never leaves an automatically detected incident stuck in "detectado"
    solely because n8n is unavailable.
    """
    if obj.status in {"resuelto", "escalado", "esperando_aprobacion", "esperando_agente"}:
        return {"ok": True, "state": obj.status, "incident_code": obj.code}

    # 1) Diagnose immediately in the API.
    obj.status = "diagnosticando"
    db.commit()
    result = await ai_diagnose({
        "code": obj.code,
        "title": obj.title,
        "asset": obj.asset,
        "description": obj.description,
        "evidence": obj.evidence or {},
    })
    obj.diagnosis = result.get("diagnosis", "")
    evidence = dict(obj.evidence or {})
    evidence["resolve_ai"] = {
        "confidence": result.get("confidence"),
        "runbook": result.get("runbook"),
        "risk": result.get("risk"),
        "provider": result.get("provider"),
        "recommendation": result.get("recommendation", ""),
    }
    obj.evidence = evidence
    db.add(AuditEvent(actor="resolve-ai", action="incident.auto_diagnosed", detail=f"{obj.code} {result.get('runbook')}"))
    db.commit()

    runbook = str(result.get("runbook") or "")
    safe_orchestrated = runbook in {"PRN-SVC-001", "ATT-CONN-001"}

    # 2) If a known runbook exists, hand off to n8n automatically.
    if safe_orchestrated:
        url = settings.n8n_base_url.rstrip("/") + "/webhook/lenvrak-incident"
        try:
            obj.status = "orquestando"
            db.commit()
            async with httpx.AsyncClient(timeout=8.0) as client:
                response = await client.post(url, json={
                    "code": obj.code,
                    "source": source,
                    "monitor_key": (obj.evidence or {}).get("monitor_key", ""),
                })
                response.raise_for_status()
            db.add(AuditEvent(actor="n8n", action="edge.workflow_started", detail=f"{obj.code} {runbook}"))
            db.commit()
            return {
                "ok": True,
                "state": "workflow_started",
                "incident_code": obj.code,
                "status": obj.status,
                "diagnosis": obj.diagnosis,
                "runbook": runbook,
            }
        except Exception as exc:
            # Do not return to 'detectado': preserve diagnosis and escalate.
            obj.status = "escalado"
            obj.resolution = (
                "Escalado automáticamente: Resolve AI generó diagnóstico, pero n8n no pudo iniciar "
                f"el runbook {runbook}. Requiere revisión técnica."
            )
            db.add(AuditEvent(actor="n8n", action="edge.workflow_failed_escalated", detail=f"{obj.code} {type(exc).__name__}"))
            db.commit()
            alert = await dispatch_incident_alert(obj, "escalated", obj.resolution)
            db.add(AuditEvent(actor="notify", action="incident.escalated_alert", detail=f"{obj.code} {alert.get('state')}"))
            db.commit()
            return {
                "ok": False,
                "state": "escalated",
                "incident_code": obj.code,
                "diagnosis": obj.diagnosis,
                "warning": type(exc).__name__,
            }

    # 3) No safe/specific automatic runbook: escalate honestly.
    recommendation = str(result.get("recommendation") or "").strip()
    obj.status = "escalado"
    obj.resolution = (
        "Escalado automáticamente: la falla fue detectada y diagnosticada, pero no existe un "
        "runbook automático específico, seguro y verificable para este activo."
        + (f" {recommendation}" if recommendation else "")
    )
    db.add(AuditEvent(actor="resolve-ai", action="incident.auto_escalated_no_runbook", detail=f"{obj.code} {runbook or 'NONE'}"))
    db.commit()
    alert = await dispatch_incident_alert(obj, "escalated", obj.resolution)
    db.add(AuditEvent(actor="notify", action="incident.escalated_alert", detail=f"{obj.code} {alert.get('state')}"))
    db.commit()
    return {
        "ok": True,
        "state": "escalated",
        "incident_code": obj.code,
        "status": obj.status,
        "diagnosis": obj.diagnosis,
        "runbook": runbook,
        "reason": "no_safe_specific_runbook",
    }


async def recover_open_detected_incidents() -> None:
    """Recover incidents that were detected before this update and were left pending."""
    db = SessionLocal()
    try:
        rows = list(db.scalars(
            select(Incident)
            .where(
                Incident.origin.in_(["LENVRAK Edge","LENVRAK Access"]),
                Incident.status == "detectado",
            )
            .order_by(Incident.created_at.asc())
            .limit(50)
        ).all())
        for obj in rows:
            try:
                await _auto_process_detected_incident(obj, db, source="startup-recovery")
            except Exception as exc:
                db.add(AuditEvent(actor="startup", action="incident.recovery_error", detail=f"{obj.code} {type(exc).__name__}"))
                db.commit()
    finally:
        db.close()


@router.post("/reprocess/{incident_code}")
async def reprocess_incident(incident_code: str, db: Session = Depends(get_db)):
    obj = db.scalar(select(Incident).where(Incident.code == incident_code))
    if not obj:
        raise HTTPException(404, "Incident not found")
    if obj.origin not in {"LENVRAK Edge","LENVRAK Access"}:
        raise HTTPException(409, "Only automatically monitored incidents can be reprocessed here")
    if obj.status in {"resuelto","esperando_aprobacion","esperando_agente"}:
        return {"ok": True, "state": obj.status, "incident_code": obj.code}
    if obj.status == "escalado":
        # Allow a controlled retry only if explicitly requested.
        obj.status = "detectado"
        obj.resolution = ""
        db.commit()
    return await _auto_process_detected_incident(obj, db, source="manual-reprocess")
