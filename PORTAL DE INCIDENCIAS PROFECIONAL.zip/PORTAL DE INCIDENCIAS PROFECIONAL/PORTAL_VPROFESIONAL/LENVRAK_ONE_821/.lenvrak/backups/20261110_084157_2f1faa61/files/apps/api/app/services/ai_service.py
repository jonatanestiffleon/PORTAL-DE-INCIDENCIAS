from ..settings import settings

async def diagnose(incident:dict)->dict:
    asset=str(incident.get("asset",""))
    title=str(incident.get("title",""))
    description=str(incident.get("description",""))
    text=f"{asset} {title} {description}".lower()

    if asset.startswith("IMP") or "impres" in text or "spooler" in text:
        base={
            "diagnosis":"Posible falla de cola, Print Spooler, driver o conectividad de impresión.",
            "confidence":0.78,
            "runbook":"PRN-SVC-001",
            "risk":"VERDE",
        }
    elif asset.startswith("HUELLA") or "terminal" in text or "biometr" in text:
        base={
            "diagnosis":"Posible pérdida de comunicación, alimentación, red o sincronización de la terminal.",
            "confidence":0.72,
            "runbook":"ATT-CONN-001",
            "risk":"AMARILLO",
        }
    elif "mysql" in text or "3306" in text:
        base={
            "diagnosis":"MySQL no responde en el puerto configurado. Puede tratarse de servicio detenido, Laragon/XAMPP apagado, conflicto de puerto o falla del servidor.",
            "confidence":0.90,
            "runbook":"NO-AUTO-RUNBOOK",
            "risk":"AMARILLO",
            "recommendation":"Escalar a técnico de base de datos/servidor. No iniciar MySQL automáticamente sin conocer cómo está desplegado y sin runbook específico aprobado.",
        }
    elif "gns3" in text or "3080" in text:
        base={
            "diagnosis":"El Controller/API de GNS3 no responde en el endpoint configurado. Puede estar cerrado, detenido o con el puerto no disponible.",
            "confidence":0.90,
            "runbook":"NO-AUTO-RUNBOOK",
            "risk":"AMARILLO",
            "recommendation":"Escalar a soporte de redes/GNS3. No alterar topologías ni configuraciones automáticamente sin runbook específico y verificación.",
        }
    else:
        base={
            "diagnosis":"Falla real detectada por monitoreo. Requiere análisis de telemetría, logs y estado actual antes de ejecutar cambios.",
            "confidence":0.60,
            "runbook":"NO-AUTO-RUNBOOK",
            "risk":"AMARILLO",
            "recommendation":"Escalar si no existe un runbook específico, seguro y verificable.",
        }

    if not settings.openai_api_key:
        return {**base,"provider":"heuristic-fallback","note":"OPENAI_API_KEY no configurada en la API."}

    try:
        from openai import AsyncOpenAI
        client=AsyncOpenAI(api_key=settings.openai_api_key)
        prompt=f"""Eres Resolve AI de LENVRAK. Analiza defensivamente este incidente real detectado por monitoreo.
No propongas acciones destructivas. No marques como resuelto sin verificación.
Si no existe un runbook específico y seguro, recomienda escalar.
Incidente: {incident}"""
        r=await client.responses.create(model=settings.openai_model,input=prompt)
        return {**base,"provider":"openai","ai_text":r.output_text}
    except Exception as exc:
        return {**base,"provider":"heuristic-fallback","note":type(exc).__name__}
