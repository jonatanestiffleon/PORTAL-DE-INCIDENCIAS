from ..settings import settings
async def diagnose(incident:dict)->dict:
    asset=str(incident.get("asset",""));title=str(incident.get("title",""))
    if asset.startswith("IMP") or "impres" in title.lower():
        base={"diagnosis":"Posible falla de cola, Print Spooler, driver o conectividad de impresión.","confidence":0.78,"runbook":"PRN-SVC-001","risk":"VERDE"}
    elif asset.startswith("HUELLA") or "terminal" in title.lower():
        base={"diagnosis":"Posible pérdida de comunicación, alimentación o sincronización.","confidence":0.72,"runbook":"ATT-CONN-001","risk":"AMARILLO"}
    else:
        base={"diagnosis":"Requiere diagnóstico estructurado de telemetría, logs y estado actual.","confidence":0.55,"runbook":"DIAG-GENERAL-001","risk":"VERDE"}
    if not settings.openai_api_key:
        return {**base,"provider":"heuristic-fallback","note":"OPENAI_API_KEY no configurada."}
    try:
        from openai import AsyncOpenAI
        client=AsyncOpenAI(api_key=settings.openai_api_key)
        prompt=f"""Eres Resolve AI de LENVRAK. Analiza defensivamente este incidente.
No propongas acciones destructivas ni comandos sin runbook. Devuelve un diagnóstico breve y seguro.
Incidente: {incident}"""
        r=await client.responses.create(model=settings.openai_model,input=prompt)
        return {**base,"provider":"openai","ai_text":r.output_text}
    except Exception as exc:
        return {**base,"provider":"heuristic-fallback","note":type(exc).__name__}
