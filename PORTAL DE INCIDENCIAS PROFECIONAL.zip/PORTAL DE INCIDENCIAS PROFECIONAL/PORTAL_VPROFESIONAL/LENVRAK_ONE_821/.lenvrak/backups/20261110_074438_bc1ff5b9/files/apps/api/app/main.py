import time
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.exc import OperationalError

from .settings import settings
from .db import Base, engine
from .routers import (
    health, incidents, access, authorizations, economics, procurement,
    networklab, reports, integrations, audit, runbooks, edge, communications, monitors, organizations
)

def initialize_database(max_attempts: int = 40, delay_seconds: float = 2.0) -> None:
    last_error = None
    for attempt in range(1, max_attempts + 1):
        try:
            Base.metadata.create_all(bind=engine)
            return
        except OperationalError as exc:
            last_error = exc
            if attempt >= max_attempts:
                raise
            time.sleep(delay_seconds)
    if last_error:
        raise last_error

initialize_database()

app = FastAPI(title=settings.app_name, version="0.13.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[x.strip() for x in settings.cors_origins.split(",") if x.strip()],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

for router in [
    health.router, incidents.router, access.router, authorizations.router,
    economics.router, procurement.router, networklab.router, reports.router,
    integrations.router, audit.router, runbooks.router, edge.router, communications.router, monitors.router, organizations.router
]:
    app.include_router(router)
