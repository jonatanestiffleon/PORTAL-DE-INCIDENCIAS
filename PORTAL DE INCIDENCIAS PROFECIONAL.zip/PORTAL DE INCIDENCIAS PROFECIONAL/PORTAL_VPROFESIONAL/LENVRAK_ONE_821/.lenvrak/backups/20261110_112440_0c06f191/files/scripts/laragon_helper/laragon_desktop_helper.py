from __future__ import annotations
import json
import os
import subprocess
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ENV = ROOT / ".env"
BIND = "127.0.0.1"
PORT = 8790

def env_value(key: str, default: str = "") -> str:
    if ENV.exists():
        for line in ENV.read_text(encoding="utf-8", errors="ignore").splitlines():
            if line.strip().startswith(key + "="):
                return line.split("=", 1)[1].strip()
    return os.environ.get(key, default)

TOKEN = env_value("EDGE_AGENT_TOKEN", "")

def run_ps(script: str, timeout: int = 25) -> tuple[bool, str]:
    p = subprocess.run(
        ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script],
        capture_output=True,
        text=True,
        timeout=timeout,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    out = ((p.stdout or "") + "\n" + (p.stderr or "")).strip()
    return p.returncode == 0, out[-5000:]

def laragon_start_all() -> dict:
    """
    Laragon 2026 uses per-service switches instead of an exposed "Start All" control.
    This routine targets only the visible MySQL row:
      1) locate an AutomationElement whose name contains MySQL
      2) try Toggle/Invoke on that element or nearby control in the same row
      3) if Laragon exposes no pattern, click relative to the MySQL label rectangle
         (not an absolute screen coordinate)
    """
    script = r"""
$ErrorActionPreference='SilentlyContinue'
$exe='C:\laragon\laragon.exe'
if(-not (Test-Path $exe)){
  Write-Output 'LARAGON_NOT_FOUND'
  exit 2
}

$p=Get-Process laragon -ErrorAction SilentlyContinue | Select-Object -First 1
if(-not $p){
  Start-Process $exe
  Start-Sleep -Seconds 2
  $p=Get-Process laragon -ErrorAction SilentlyContinue | Select-Object -First 1
}
if(-not $p){
  Write-Output 'LARAGON_NOT_RUNNING'
  exit 3
}

Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes

for($i=0;$i -lt 15;$i++){
  $p.Refresh()
  if($p.MainWindowHandle -ne 0){ break }
  Start-Sleep -Milliseconds 250
}
if($p.MainWindowHandle -eq 0){
  Write-Output 'LARAGON_NO_VISIBLE_WINDOW'
  exit 4
}

Add-Type @'
using System;
using System.Runtime.InteropServices;
public static class LenvrakMouse {
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
  [DllImport("user32.dll")] public static extern bool SetCursorPos(int X, int Y);
  [DllImport("user32.dll")] public static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, UIntPtr dwExtraInfo);
  public const uint LEFTDOWN = 0x0002;
  public const uint LEFTUP   = 0x0004;
}
'@

[LenvrakMouse]::SetForegroundWindow($p.MainWindowHandle) | Out-Null
Start-Sleep -Milliseconds 450

$root=[System.Windows.Automation.AutomationElement]::FromHandle($p.MainWindowHandle)
$all=$root.FindAll([System.Windows.Automation.TreeScope]::Descendants,[System.Windows.Automation.Condition]::TrueCondition)

$mysql=$null
for($i=0;$i -lt $all.Count;$i++){
  $el=$all.Item($i)
  $name=[string]$el.Current.Name
  if($name -match '(?i)mysql'){
    $r=$el.Current.BoundingRectangle
    if($r.Width -gt 0 -and $r.Height -gt 0){
      $mysql=$el
      break
    }
  }
}
if(-not $mysql){
  Write-Output 'MYSQL_ROW_NOT_FOUND'
  exit 5
}

$mr=$mysql.Current.BoundingRectangle
Write-Output ("MYSQL_ELEMENT:{0}|L={1}|T={2}|W={3}|H={4}" -f $mysql.Current.Name,[int]$mr.Left,[int]$mr.Top,[int]$mr.Width,[int]$mr.Height)

# First try patterns on the MySQL element itself.
try{
  $toggle=$mysql.GetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern)
  if($toggle){
    $toggle.Toggle()
    Write-Output 'MYSQL_TOGGLE_PATTERN'
    exit 0
  }
}catch{}

try{
  $invoke=$mysql.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern)
  if($invoke){
    $invoke.Invoke()
    Write-Output 'MYSQL_INVOKE_PATTERN'
    exit 0
  }
}catch{}

# Find a control immediately to the LEFT of the MySQL label on the same visual row.
$best=$null
$bestDist=99999
$myCy=$mr.Top + ($mr.Height/2.0)
for($i=0;$i -lt $all.Count;$i++){
  $el=$all.Item($i)
  $r=$el.Current.BoundingRectangle
  if($r.Width -le 0 -or $r.Height -le 0){ continue }
  $cy=$r.Top + ($r.Height/2.0)
  $dy=[math]::Abs($cy-$myCy)
  if($dy -gt [math]::Max(18,$mr.Height)){ continue }
  if($r.Right -gt ($mr.Left+8)){ continue }
  $dist=$mr.Left-$r.Right
  if($dist -lt 0 -or $dist -gt 110){ continue }

  $ct=[string]$el.Current.ControlType.ProgrammaticName
  if($ct -match 'Button|CheckBox|Custom'){
    if($dist -lt $bestDist){
      $best=$el
      $bestDist=$dist
    }
  }
}

if($best){
  try{
    $toggle=$best.GetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern)
    if($toggle){
      $toggle.Toggle()
      Write-Output 'MYSQL_NEARBY_TOGGLE_PATTERN'
      exit 0
    }
  }catch{}
  try{
    $invoke=$best.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern)
    if($invoke){
      $invoke.Invoke()
      Write-Output 'MYSQL_NEARBY_INVOKE_PATTERN'
      exit 0
    }
  }catch{}
  $br=$best.Current.BoundingRectangle
  $x=[int]($br.Left+$br.Width/2)
  $y=[int]($br.Top+$br.Height/2)
  [LenvrakMouse]::SetCursorPos($x,$y) | Out-Null
  Start-Sleep -Milliseconds 120
  [LenvrakMouse]::mouse_event([LenvrakMouse]::LEFTDOWN,0,0,0,[UIntPtr]::Zero)
  [LenvrakMouse]::mouse_event([LenvrakMouse]::LEFTUP,0,0,0,[UIntPtr]::Zero)
  Write-Output ("MYSQL_NEARBY_CONTROL_CLICK:{0},{1}" -f $x,$y)
  exit 0
}

# Controlled relative fallback:
# Laragon 2026 visually places the service switch immediately to the left of the label.
# Use the MySQL element's own rectangle, never hard-coded absolute screen coordinates.
$clickX=[int]($mr.Left-24)
$clickY=[int]($mr.Top+$mr.Height/2)
if($clickX -lt 0 -or $clickY -lt 0){
  Write-Output 'MYSQL_RELATIVE_CLICK_INVALID'
  exit 6
}
[LenvrakMouse]::SetCursorPos($clickX,$clickY) | Out-Null
Start-Sleep -Milliseconds 150
[LenvrakMouse]::mouse_event([LenvrakMouse]::LEFTDOWN,0,0,0,[UIntPtr]::Zero)
[LenvrakMouse]::mouse_event([LenvrakMouse]::LEFTUP,0,0,0,[UIntPtr]::Zero)
Write-Output ("MYSQL_RELATIVE_TOGGLE_CLICK:{0},{1}" -f $clickX,$clickY)
exit 0
"""
    ok, out = run_ps(script)
    return {"ok": ok, "action": "laragon_mysql_toggle", "output": out}

class Handler(BaseHTTPRequestHandler):
    server_version = "LENVRAKLaragonHelper/0.14.4"

    def log_message(self, fmt, *args):
        pass

    def _json(self, status: int, data: dict):
        raw = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def _auth(self) -> bool:
        return bool(TOKEN) and self.headers.get("X-LENVRAK-EDGE-TOKEN", "") == TOKEN

    def do_GET(self):
        if self.path != "/health":
            return self._json(404, {"ok": False, "error": "not_found"})
        if not self._auth():
            return self._json(401, {"ok": False, "error": "unauthorized"})
        return self._json(200, {
            "ok": True,
            "service": "lenvrak-laragon-desktop-helper",
            "version": "0.14.4",
            "interactive_session": True,
        })

    def do_POST(self):
        if not self._auth():
            return self._json(401, {"ok": False, "error": "unauthorized"})
        if self.path == "/v1/laragon/start-all":
            result = laragon_start_all()
            return self._json(200 if result["ok"] else 409, result)
        return self._json(404, {"ok": False, "error": "not_found"})

if __name__ == "__main__":
    if os.name != "nt":
        raise SystemExit("Laragon Desktop Helper solo funciona en Windows.")
    if not TOKEN:
        raise SystemExit("EDGE_AGENT_TOKEN no configurado.")
    ThreadingHTTPServer((BIND, PORT), Handler).serve_forever()
