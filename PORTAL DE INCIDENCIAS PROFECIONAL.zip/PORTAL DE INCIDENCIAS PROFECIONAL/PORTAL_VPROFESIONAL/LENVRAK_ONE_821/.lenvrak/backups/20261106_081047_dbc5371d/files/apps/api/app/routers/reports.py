from fastapi import APIRouter
router=APIRouter(prefix="/api/v1/reports",tags=["reports"])
@router.post("/preview")
def preview(audience:str="Gerente"):
    templates={"Técnico":["logs","evidence","diagnosis","runbook","result"],"Jefe TI":["sla","mttr","mtbf","recurrence","automation_rate"],"Administración":["costs","quotes","replacement_value","budget"],"Gerente":["impact","cost","downtime","recommendation"],"Dueño":["availability","total_incidents","savings","risks","decisions"]}
    return {"audience":audience,"fields":templates.get(audience,templates["Gerente"])}
