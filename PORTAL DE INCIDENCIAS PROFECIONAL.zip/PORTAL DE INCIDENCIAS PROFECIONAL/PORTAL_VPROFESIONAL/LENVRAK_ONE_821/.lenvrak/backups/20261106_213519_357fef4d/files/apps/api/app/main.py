from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .settings import settings
from .db import Base,engine
from .routers import health,incidents,access,authorizations,economics,procurement,networklab,reports,integrations,audit
Base.metadata.create_all(bind=engine)
app=FastAPI(title=settings.app_name,version="0.9.0")
app.add_middleware(CORSMiddleware,allow_origins=[x.strip() for x in settings.cors_origins.split(",")],allow_credentials=True,allow_methods=["*"],allow_headers=["*"])
for r in [health.router,incidents.router,access.router,authorizations.router,economics.router,procurement.router,networklab.router,reports.router,integrations.router,audit.router]: app.include_router(r)
