from pydantic import BaseModel,Field
from typing import Literal,Any
Severity=Literal["baja","media","alta","critica"]
class IncidentCreate(BaseModel):
    title:str=Field(min_length=3,max_length=160)
    type:str="otro";severity:Severity="media";origin:str="Portal manual";asset:str="N/A";site:str="Sede principal";owner:str="Sin asignar"
    description:str=Field(min_length=20,max_length=2000)
    evidence:dict[str,Any]={}
class AttendanceEvent(BaseModel):
    eventType:str;terminalId:str;severity:Severity="media";summary:str=Field(min_length=10);site:str="Sede principal"
class AuthorizationInterpret(BaseModel): text:str=Field(min_length=3,max_length=1000)
class EconomicInput(BaseModel):
    replacement_value:float;repair_cost:float;downtime_hours:float;downtime_hour_cost:float;failures:int;platform_cost:float=0
class QuoteInput(BaseModel):
    incident_code:str;vendor:str;city:str;option:str;price:float;transport:float=0;delivery_hours:float=0;warranty_days:int=0
class NetworkBlueprintRequest(BaseModel):
    prompt:str;x:str|None=None;y:str|None=None;notes:str="";mode:str="guide"
