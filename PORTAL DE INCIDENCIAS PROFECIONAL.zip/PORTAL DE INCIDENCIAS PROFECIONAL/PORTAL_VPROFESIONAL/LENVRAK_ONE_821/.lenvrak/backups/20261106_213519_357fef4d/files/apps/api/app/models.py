from datetime import datetime
from sqlalchemy import String,Integer,Float,DateTime,Text,Boolean,JSON
from sqlalchemy.orm import Mapped,mapped_column
from .db import Base

class Incident(Base):
    __tablename__="incidents"
    id:Mapped[int]=mapped_column(primary_key=True)
    code:Mapped[str]=mapped_column(String(32),unique=True,index=True)
    title:Mapped[str]=mapped_column(String(160))
    type:Mapped[str]=mapped_column(String(60),default="otro")
    severity:Mapped[str]=mapped_column(String(20),default="media")
    status:Mapped[str]=mapped_column(String(40),default="detectado")
    origin:Mapped[str]=mapped_column(String(80),default="Portal manual")
    asset:Mapped[str]=mapped_column(String(120),default="N/A")
    site:Mapped[str]=mapped_column(String(120),default="Sede principal")
    owner:Mapped[str]=mapped_column(String(120),default="Sin asignar")
    description:Mapped[str]=mapped_column(Text)
    evidence:Mapped[dict]=mapped_column(JSON,default=dict)
    diagnosis:Mapped[str]=mapped_column(Text,default="")
    resolution:Mapped[str]=mapped_column(Text,default="")
    created_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)
    resolved_at:Mapped[datetime|None]=mapped_column(DateTime,nullable=True)

class Asset(Base):
    __tablename__="assets"
    id:Mapped[int]=mapped_column(primary_key=True)
    code:Mapped[str]=mapped_column(String(80),unique=True,index=True)
    name:Mapped[str]=mapped_column(String(160))
    category:Mapped[str]=mapped_column(String(60))
    site:Mapped[str]=mapped_column(String(120),default="Sede principal")
    purchase_price:Mapped[float]=mapped_column(Float,default=0)
    replacement_value:Mapped[float]=mapped_column(Float,default=0)
    active:Mapped[bool]=mapped_column(Boolean,default=True)

class Approval(Base):
    __tablename__="approvals"
    id:Mapped[int]=mapped_column(primary_key=True)
    action:Mapped[str]=mapped_column(String(160))
    risk:Mapped[str]=mapped_column(String(20))
    scope:Mapped[str]=mapped_column(String(160))
    mode:Mapped[str]=mapped_column(String(60))
    enabled:Mapped[bool]=mapped_column(Boolean,default=True)
    created_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)

class Quote(Base):
    __tablename__="quotes"
    id:Mapped[int]=mapped_column(primary_key=True)
    incident_code:Mapped[str]=mapped_column(String(32),index=True)
    vendor:Mapped[str]=mapped_column(String(160))
    city:Mapped[str]=mapped_column(String(120))
    option:Mapped[str]=mapped_column(String(60))
    price:Mapped[float]=mapped_column(Float)
    transport:Mapped[float]=mapped_column(Float,default=0)
    delivery_hours:Mapped[float]=mapped_column(Float,default=0)
    warranty_days:Mapped[int]=mapped_column(Integer,default=0)
    metadata_json:Mapped[dict]=mapped_column(JSON,default=dict)

class AuditEvent(Base):
    __tablename__="audit_events"
    id:Mapped[int]=mapped_column(primary_key=True)
    actor:Mapped[str]=mapped_column(String(120))
    action:Mapped[str]=mapped_column(String(160))
    detail:Mapped[str]=mapped_column(Text,default="")
    created_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)
