from __future__ import annotations
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from pathlib import Path
import json,zipfile,io,os,tempfile,shutil,time,threading,subprocess,sys,uuid,datetime,urllib.request,urllib.parse,socket,ipaddress
from common import *

HOST="127.0.0.1";PORT=int(os.getenv("LENVRAK_UPDATE_PORT","8765"))
TOKEN=os.getenv("LENVRAK_UPDATE_TOKEN") or uuid.uuid4().hex
ALLOWED_ORIGINS={"http://127.0.0.1:8090","http://localhost:8090"}
FEED_URL=os.getenv("LENVRAK_UPDATE_FEED_URL","").strip()
LOCK=threading.RLock()
ensure_state()

def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def json_bytes(obj):return json.dumps(obj,ensure_ascii=False,indent=2).encode("utf-8")

def inspect_zip(data:bytes,store=True):
    if len(data)>MAX_ZIP_BYTES: raise ValueError("ZIP excede 50 MB")
    try:z=zipfile.ZipFile(io.BytesIO(data))
    except Exception as e:raise ValueError("ZIP inválido") from e
    names=z.namelist()
    if "manifest.json" not in names:raise ValueError("Falta manifest.json")
    total=sum(i.file_size for i in z.infolist())
    if total>MAX_UNCOMPRESSED_BYTES:raise ValueError("Contenido descomprimido excesivo")
    for info in z.infolist():
        if info.file_size>MAX_FILE_BYTES:raise ValueError(f"Archivo demasiado grande: {info.filename}")
        mode=(info.external_attr>>16)&0o170000
        if mode==0o120000:raise ValueError(f"Symlink rechazado: {info.filename}")
        safe_relpath(info.filename)
    manifest=json.loads(z.read("manifest.json"))
    if manifest.get("format")!="lenvrak-update-v1":raise ValueError("Formato no compatible")
    if manifest.get("app")!="LENVRAK One":raise ValueError("Paquete para otra aplicación")
    if not verify_signature(manifest):raise ValueError("Firma HMAC inválida")
    current=read_version()
    if semver(manifest["min_version"])>semver(current["version"]):raise ValueError("La versión instalada no cumple min_version")
    if semver(manifest["version"])<=semver(current["version"]):raise ValueError("La actualización no es más nueva que la instalada")
    payload_names={n for n in names if n.startswith("payload/") and not n.endswith("/")}
    expected={"payload/"+safe_relpath(i["path"]) for i in manifest.get("files",[])}
    if payload_names!=expected:raise ValueError("El contenido payload no coincide con el manifiesto")
    modules=set()
    for item in manifest.get("files",[]):
        rel=safe_relpath(item["path"])
        if not managed_path(rel):raise ValueError(f"Ruta no administrada: {rel}")
        raw=z.read("payload/"+rel)
        if len(raw)!=int(item["size"]):raise ValueError(f"Tamaño incorrecto: {rel}")
        if sha256_bytes(raw)!=item["sha256"]:raise ValueError(f"SHA-256 incorrecto: {rel}")
        modules.add(item["module"])
    for item in manifest.get("delete",[]):
        rel=safe_relpath(item["path"])
        if not managed_path(rel):raise ValueError(f"Delete no administrado: {rel}")
        modules.add(item["module"])
    update_id=sha256_bytes(data)[:20]
    if store:(INBOX/f"{update_id}.zip").write_bytes(data)
    return {"update_id":update_id,"manifest":manifest,"modules":sorted(modules),"current":current}

def create_backup(update_id,manifest,selected):
    backup_id=time.strftime("%Y%m%d_%H%M%S")+"_"+update_id[:8]
    d=BACKUPS/backup_id;d.mkdir(parents=True)
    touched=[]
    for item in manifest.get("files",[])+manifest.get("delete",[]):
        if item["module"] not in selected:continue
        rel=safe_relpath(item["path"]);path=ROOT/rel;exists=path.exists()
        touched.append({"path":rel,"existed":exists})
        if exists and path.is_file():
            dest=d/"files"/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,dest)
    shutil.copy2(VERSION,d/"version.json")
    (d/"meta.json").write_text(json.dumps({"backup_id":backup_id,"created_at":now(),"update_id":update_id,"touched":touched,"from_version":read_version()},ensure_ascii=False,indent=2),encoding="utf-8")
    return backup_id

def restore_backup(backup_id):
    d=BACKUPS/backup_id
    meta=json.loads((d/"meta.json").read_text(encoding="utf-8"))
    for t in meta["touched"]:
        rel=t["path"];target=ROOT/rel;old=d/"files"/rel
        if t["existed"]:
            target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(old,target)
        elif target.exists():
            if target.is_file():target.unlink()
            elif target.is_dir():shutil.rmtree(target)
    shutil.copy2(d/"version.json",VERSION)
    return meta

def run_smoke():
    test=ROOT/"tests/smoke_test.py"
    if not test.exists():return {"ok":True,"stdout":"No smoke test configured."}
    try:
        r=subprocess.run([sys.executable,str(test)],cwd=ROOT,capture_output=True,text=True,timeout=30)
        return {"ok":r.returncode==0,"stdout":(r.stdout+r.stderr)[-8000:]}
    except subprocess.TimeoutExpired:return {"ok":False,"stdout":"Smoke test timeout."}

def apply_update(update_id,selected_modules=None):
    with LOCK:
        p=INBOX/f"{update_id}.zip"
        if not p.exists():raise ValueError("update_id no encontrado")
        info=inspect_zip(p.read_bytes(),store=False)
        m=info["manifest"]
        available=set(info["modules"])
        selected=set(selected_modules or available)
        if not selected or not selected.issubset(available):raise ValueError("Selección de módulos no válida")
        backup_id=create_backup(update_id,m,selected)
        z=zipfile.ZipFile(p)
        try:
            for item in m.get("files",[]):
                if item["module"] not in selected:continue
                rel=safe_relpath(item["path"]);target=ROOT/rel
                raw=z.read("payload/"+rel)
                target.parent.mkdir(parents=True,exist_ok=True)
                fd,tmp=tempfile.mkstemp(prefix=".lenvrak_",dir=str(target.parent))
                try:
                    with os.fdopen(fd,"wb") as f:f.write(raw);f.flush();os.fsync(f.fileno())
                    os.replace(tmp,target)
                finally:
                    if os.path.exists(tmp):os.unlink(tmp)
            for item in m.get("delete",[]):
                if item["module"] not in selected:continue
                target=ROOT/safe_relpath(item["path"])
                if target.is_file():target.unlink()
                elif target.is_dir():shutil.rmtree(target)
            v=read_version()
            for mod in selected:
                if mod in m.get("module_versions",{}):v.setdefault("modules",{})[mod]=m["module_versions"][mod]
            if selected==available:v["version"]=m["version"]
            v["last_update"]={"package":m["version"],"modules":sorted(selected),"at":now(),"channel":m["channel"]}
            write_version(v)
            test=run_smoke()
            if not test["ok"]:
                restore_backup(backup_id)
                add_history({"at":now(),"status":"failed_rolled_back","update_id":update_id,"target":m["version"],"backup_id":backup_id,"test":test})
                raise ValueError("Pruebas fallaron. Rollback automático realizado.\n"+test["stdout"][-1500:])
            add_history({"at":now(),"status":"installed","update_id":update_id,"target":m["version"],"modules":sorted(selected),"backup_id":backup_id,"test":test})
            return {"ok":True,"version":read_version(),"backup_id":backup_id,"test":test}
        except Exception:
            raise

def rollback(backup_id):
    with LOCK:
        meta=restore_backup(backup_id)
        test=run_smoke()
        add_history({"at":now(),"status":"manual_rollback","backup_id":backup_id,"restored":meta.get("from_version",{}).get("version"),"test":test})
        return {"ok":test["ok"],"version":read_version(),"test":test}


def safe_remote_url(url):
    u=urllib.parse.urlparse(url)
    if u.scheme!="https" or not u.hostname: raise ValueError("Solo se permiten URLs HTTPS")
    infos=socket.getaddrinfo(u.hostname,u.port or 443,type=socket.SOCK_STREAM)
    for info in infos:
        ip=ipaddress.ip_address(info[4][0])
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast:
            raise ValueError("Destino remoto privado/local rechazado")
    return url

def download_remote(url,expected_sha=""):
    safe_remote_url(url)
    req=urllib.request.Request(url,headers={"User-Agent":"LENVRAK-UpdateManager/1.0"})
    with urllib.request.urlopen(req,timeout=15) as r:
        final=r.geturl();safe_remote_url(final)
        length=int(r.headers.get("Content-Length","0") or 0)
        if length and length>MAX_ZIP_BYTES: raise ValueError("Paquete remoto demasiado grande")
        data=r.read(MAX_ZIP_BYTES+1)
    if len(data)>MAX_ZIP_BYTES: raise ValueError("Paquete remoto demasiado grande")
    if expected_sha and sha256_bytes(data).lower()!=expected_sha.lower(): raise ValueError("SHA-256 remoto no coincide")
    return inspect_zip(data,store=True)

def due_scheduler():
    while True:
        try:
            items=read_json(SCHEDULE,[])
            changed=False
            for x in items:
                if x.get("status")!="scheduled":continue
                when=datetime.datetime.fromisoformat(x["at"])
                if when.tzinfo is None:when=when.replace(tzinfo=datetime.timezone.utc)
                if datetime.datetime.now(datetime.timezone.utc)>=when:
                    try:
                        res=apply_update(x["update_id"],x.get("modules"));x["status"]="installed";x["result"]=res
                    except Exception as e:x["status"]="failed";x["error"]=str(e)
                    changed=True
            if changed:write_json(SCHEDULE,items)
        except Exception:pass
        time.sleep(5)

class H(BaseHTTPRequestHandler):
    server_version="LENVRAKUpdateManager/1.0"
    def log_message(self,fmt,*args):print("[update]",fmt%args)
    def cors(self):
        origin=self.headers.get("Origin","")
        if origin in ALLOWED_ORIGINS:self.send_header("Access-Control-Allow-Origin",origin)
        self.send_header("Access-Control-Allow-Headers","Content-Type,X-Lenvrak-Token")
        self.send_header("Access-Control-Allow-Methods","GET,POST,OPTIONS")
    def send_json(self,obj,status=200):
        data=json_bytes(obj);self.send_response(status);self.cors();self.send_header("Content-Type","application/json; charset=utf-8");self.send_header("Content-Length",str(len(data)));self.end_headers();self.wfile.write(data)
    def auth(self):
        return self.headers.get("X-Lenvrak-Token","")==TOKEN
    def body(self):
        n=int(self.headers.get("Content-Length","0"))
        if n>MAX_ZIP_BYTES+1024*1024:raise ValueError("Cuerpo demasiado grande")
        return self.rfile.read(n)
    def do_OPTIONS(self):self.send_response(204);self.cors();self.end_headers()
    def do_GET(self):
        try:
            if self.path=="/health":return self.send_json({"ok":True,"service":"LENVRAK Update Manager","version":"1.0.0"})
            if self.path=="/status":return self.send_json({"version":read_version(),"history":read_json(HISTORY,[])[:15],"backups":[p.name for p in sorted(BACKUPS.iterdir(),reverse=True) if p.is_dir()][:15],"schedule":read_json(SCHEDULE,[])})
            if self.path.startswith("/remote-check"):
                if not FEED_URL:return self.send_json({"configured":False,"message":"LENVRAK_UPDATE_FEED_URL no configurado."})
                with urllib.request.urlopen(FEED_URL,timeout=8) as r:feed=json.loads(r.read())
                channel=read_version().get("channel","stable")
                candidates=[x for x in feed.get("releases",[]) if x.get("channel")==channel and semver(x["version"])>semver(read_version()["version"])]
                return self.send_json({"configured":True,"channel":channel,"updates":sorted(candidates,key=lambda x:semver(x["version"]),reverse=True)})
            return self.send_json({"error":"Not found"},404)
        except Exception as e:return self.send_json({"error":str(e)},400)
    def do_POST(self):
        try:
            if not self.auth():return self.send_json({"error":"Token inválido"},401)
            if self.path=="/validate":
                info=inspect_zip(self.body(),store=True)
                return self.send_json({"ok":True,**info})
            data=json.loads(self.body() or b"{}")
            if self.path=="/remote-download":
                return self.send_json({"ok":True,**download_remote(data["url"],data.get("sha256",""))})
            if self.path=="/apply":return self.send_json(apply_update(data["update_id"],data.get("modules")))
            if self.path=="/test":
                p=INBOX/f'{data["update_id"]}.zip'
                if not p.exists():raise ValueError("update_id no encontrado")
                info=inspect_zip(p.read_bytes(),store=False)
                return self.send_json({"ok":True,"validation":info,"smoke_current":run_smoke()})
            if self.path=="/rollback":return self.send_json(rollback(data["backup_id"]))
            if self.path=="/schedule":
                at=str(data["at"]);datetime.datetime.fromisoformat(at)
                items=read_json(SCHEDULE,[])
                item={"id":uuid.uuid4().hex[:12],"update_id":data["update_id"],"modules":data.get("modules"),"at":at,"status":"scheduled"}
                items.append(item);write_json(SCHEDULE,items);return self.send_json({"ok":True,"schedule":item})
            if self.path=="/channel":
                ch=data["channel"]
                if ch not in ("stable","beta","dev"):raise ValueError("Canal inválido")
                v=read_version();v["channel"]=ch;write_version(v);return self.send_json({"ok":True,"version":v})
            return self.send_json({"error":"Not found"},404)
        except Exception as e:return self.send_json({"error":str(e)},400)

if __name__=="__main__":
    threading.Thread(target=due_scheduler,daemon=True).start()
    print("="*60)
    print("LENVRAK UPDATE MANAGER")
    print(f"URL   : http://{HOST}:{PORT}")
    print(f"TOKEN : {TOKEN}")
    print("Solo escucha en localhost. Mantén esta ventana abierta.")
    print("="*60)
    ThreadingHTTPServer((HOST,PORT),H).serve_forever()
