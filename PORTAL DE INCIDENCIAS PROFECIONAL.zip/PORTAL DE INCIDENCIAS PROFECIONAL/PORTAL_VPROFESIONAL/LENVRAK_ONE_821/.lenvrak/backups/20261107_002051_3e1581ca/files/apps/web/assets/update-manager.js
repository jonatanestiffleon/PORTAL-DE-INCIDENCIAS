(function(){
"use strict";
const BASE="http://127.0.0.1:8765";
const $=s=>document.querySelector(s);
let updateId="",manifest=null;

function log(x){const el=$("#updLog");if(el)el.textContent=(typeof x==="string"?x:JSON.stringify(x,null,2))}
function token(){return $("#updToken")?.value.trim()||""}
async function req(path,opts={}){
  const headers={...(opts.headers||{})};if(opts.auth!==false)headers["X-Lenvrak-Token"]=token();
  const r=await fetch(BASE+path,{...opts,headers});const data=await r.json().catch(()=>({error:"Respuesta inválida"}));
  if(!r.ok)throw new Error(data.error||`HTTP ${r.status}`);return data
}
function selectedModules(){return [...document.querySelectorAll('#updModules input[type="checkbox"]:checked')].map(x=>x.value)}
async function status(){
  try{
    const d=await req("/status",{auth:false});
    $("#updVersion").textContent=`v${d.version.version} · ${d.version.channel}`;
    $("#updChannel").value=d.version.channel;
    $("#updBackups").innerHTML=(d.backups||[]).length?d.backups.map(b=>`<div class="backup-row"><code>${b}</code><button class="btn ghost" data-rollback="${b}">Rollback</button></div>`).join(""):'<small>Sin backups.</small>';
    document.querySelectorAll("[data-rollback]").forEach(b=>b.onclick=()=>rollback(b.dataset.rollback));
    log({version:d.version,last_history:(d.history||[]).slice(0,5),schedule:d.schedule||[]});
  }catch(e){log("Update Manager no responde.\n\nEjecuta:\npy tools\\update_manager\\server.py\n\n"+e.message)}
}
async function validate(){
  const f=$("#updFile").files[0];if(!f)throw new Error("Selecciona un ZIP.");
  const buf=await f.arrayBuffer();
  const d=await req("/validate",{method:"POST",headers:{"Content-Type":"application/octet-stream"},body:buf});
  updateId=d.update_id;manifest=d.manifest;
  $("#updModules").innerHTML=(d.modules||[]).map(m=>`<label><input type="checkbox" value="${m}" checked>${m}</label>`).join("");
  log(d);
}
async function test(){if(!updateId)throw new Error("Valida primero el paquete.");log(await req("/test",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({update_id:updateId})}))}
async function apply(){
  if(!updateId)throw new Error("Valida primero el paquete.");
  const mods=selectedModules();if(!mods.length)throw new Error("Selecciona al menos un módulo.");
  if(!confirm(`Instalar actualización ${manifest?.version||""} en: ${mods.join(", ")}?`))return;
  const d=await req("/apply",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({update_id:updateId,modules:mods})});log(d);await status()
}
async function rollback(b){
  if(!confirm(`¿Restaurar backup ${b}?`))return;
  const d=await req("/rollback",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({backup_id:b})});log(d);await status()
}
async function schedule(){
  if(!updateId)throw new Error("Valida primero el paquete.");
  const raw=$("#updScheduleAt").value;if(!raw)throw new Error("Elige fecha y hora.");
  const at=new Date(raw).toISOString();
  log(await req("/schedule",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({update_id:updateId,modules:selectedModules(),at})}));await status()
}
async function remote(){
  const d=await req("/remote-check",{auth:false});
  const box=$("#updRemoteList");
  if(!d.configured){box.innerHTML=`<small>${d.message}</small>`;log(d);return}
  box.innerHTML=(d.updates||[]).length?(d.updates||[]).map((u,i)=>`<div class="backup-row"><code>v${u.version} · ${u.notes||u.channel}</code><button class="btn ghost" data-remote-index="${i}">Descargar</button></div>`).join(""):"<small>No hay actualizaciones nuevas en este canal.</small>";
  document.querySelectorAll("[data-remote-index]").forEach(b=>b.onclick=wrap(()=>downloadRemote(d.updates[Number(b.dataset.remoteIndex)])));
  log(d)
}
async function downloadRemote(u){
  const d=await req("/remote-download",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({url:u.url,sha256:u.sha256||""})});
  updateId=d.update_id;manifest=d.manifest;
  $("#updModules").innerHTML=(d.modules||[]).map(m=>`<label><input type="checkbox" value="${m}" checked>${m}</label>`).join("");
  log(d)
}
async function setChannel(){const channel=$("#updChannel").value;log(await req("/channel",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({channel})}));await status()}
function wrap(fn){return async()=>{try{await fn()}catch(e){log("ERROR: "+e.message)} }}
document.addEventListener("DOMContentLoaded",()=>{
  $("#updRefresh").onclick=wrap(status);$("#updRemote").onclick=wrap(remote);$("#updSetChannel").onclick=wrap(setChannel);
  $("#updValidate").onclick=wrap(validate);$("#updTest").onclick=wrap(test);$("#updApply").onclick=wrap(apply);$("#updSchedule").onclick=wrap(schedule);
  status();
});
})();
