from fastapi import APIRouter
router=APIRouter(tags=["health"])
@router.get("/health")
def health(): return {"status":"ok","service":"lenvrak-one-api","version":"0.10.2"}
