from fastapi import APIRouter,Depends
from sqlalchemy.orm import Session
from ..db import get_db
from ..models import Incident,AuditEvent
from ..schemas import AttendanceEvent
from ..services.notifications import dispatch_incident_alert

router=APIRouter(prefix="/api/v1/access",tags=["access"])

@router.post("/events",status_code=201)
async def receive_event(e:AttendanceEvent,db:Session=Depends(get_db)):
    n=db.query(Incident).count()+1001
    obj=Incident(
        code=f"INC-{n:04d}",
        title=f"Access: {e.eventType}",
        type="asistencia",
        severity=e.severity,
        status="detectado",
        origin="LENVRAK Access",
        asset=e.terminalId,
        site=e.site,
        owner="Mesa técnica",
        description=e.summary,
        evidence={"source":"attendance-api","terminal_id":e.terminalId},
    )
    db.add(obj)
    db.add(AuditEvent(actor="access",action="incident.created",detail=obj.code))
    db.commit();db.refresh(obj)
    alert=await dispatch_incident_alert(obj,"created")
    db.add(AuditEvent(actor="notify",action="incident.alert",detail=f"{obj.code} {alert.get('state')}"))
    db.commit()
    return obj
