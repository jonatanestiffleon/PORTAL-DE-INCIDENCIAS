from __future__ import annotations

import base64
import hashlib
import hmac
import secrets
import time
from typing import Any

from fastapi import APIRouter, Cookie, HTTPException, Response
from pydantic import BaseModel, Field

from ..settings import settings

router=APIRouter(prefix="/api/v1/auth",tags=["auth"])
COOKIE_NAME="lenvrak_session"

class LoginRequest(BaseModel):
    username:str=Field(min_length=1,max_length=80)
    password:str=Field(min_length=1,max_length=200)
    remember:bool=True

def _b64e(raw:bytes)->str:
    return base64.urlsafe_b64encode(raw).decode().rstrip("=")

def _b64d(value:str)->bytes:
    return base64.urlsafe_b64decode(value + "="*((4-len(value)%4)%4))

def _sign(payload:str)->str:
    return hmac.new(settings.auth_secret.encode(),payload.encode(),hashlib.sha256).hexdigest()

def _make_token(username:str,remember:bool)->tuple[str,int]:
    max_age=(30*24*3600) if remember else (12*3600)
    exp=int(time.time())+max_age
    payload=f"{username}|{exp}|{secrets.token_urlsafe(12)}"
    token=_b64e(payload.encode())+"."+_sign(payload)
    return token,max_age

def _read_token(token:str|None)->dict[str,Any]|None:
    if not token or "." not in token:return None
    encoded,sig=token.rsplit(".",1)
    try:
        payload=_b64d(encoded).decode()
        if not hmac.compare_digest(sig,_sign(payload)):return None
        username,exp_s,_nonce=payload.split("|",2)
        exp=int(exp_s)
        if exp<int(time.time()):return None
        return {"username":username,"expires_at":exp}
    except Exception:
        return None

def _profile(username:str)->dict[str,Any]:
    return {
        "username":username,
        "display_name":settings.admin_display_name,
        "role":"admin",
        "organization":settings.admin_organization,
    }

@router.post("/login")
def login(data:LoginRequest,response:Response):
    good_user=hmac.compare_digest(data.username.strip(),settings.admin_username)
    good_pass=hmac.compare_digest(data.password,settings.admin_password)
    if not (good_user and good_pass):
        raise HTTPException(401,"Usuario o contraseña incorrectos")
    token,max_age=_make_token(settings.admin_username,data.remember)
    response.set_cookie(
        key=COOKIE_NAME,value=token,max_age=max_age,
        httponly=True,samesite="lax",secure=False,path="/"
    )
    return {"ok":True,"user":_profile(settings.admin_username),"remember":data.remember}

@router.get("/me")
def me(lenvrak_session:str|None=Cookie(default=None)):
    data=_read_token(lenvrak_session)
    if not data:raise HTTPException(401,"Sesión no válida o expirada")
    return {"ok":True,"user":_profile(data["username"]),"expires_at":data["expires_at"]}

@router.post("/logout")
def logout(response:Response):
    response.delete_cookie(COOKIE_NAME,path="/")
    return {"ok":True}
