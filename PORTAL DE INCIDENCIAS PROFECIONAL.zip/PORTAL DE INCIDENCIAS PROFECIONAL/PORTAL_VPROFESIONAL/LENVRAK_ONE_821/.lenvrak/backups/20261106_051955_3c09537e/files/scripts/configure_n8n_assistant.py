from pathlib import Path
import secrets, subprocess, sys, time, os

ROOT=Path(__file__).resolve().parents[1]
ENV=ROOT/".env"

DEFAULTS={
  "N8N_VERSION":"2.46.6",
  "N8N_SANDBOX_VERSION":"1.12.0",
}

def parse_env(text):
    out={}
    for line in text.splitlines():
        s=line.strip()
        if not s or s.startswith("#") or "=" not in s: continue
        k,v=s.split("=",1);out[k.strip()]=v.strip()
    return out

def write_env(values):
    ordered=[
      "N8N_VERSION","N8N_SANDBOX_VERSION","SANDBOX_API_KEYS",
      "SANDBOX_RUNNER_REGISTRATION_TOKEN","SANDBOX_RUNNER_API_KEYS",
      "N8N_SANDBOX_SERVICE_API_KEY","SEARXNG_SECRET"
    ]
    lines=["# LENVRAK / n8n Assistant - secretos locales. NO subir a Git."]
    for k in ordered: lines.append(f"{k}={values[k]}")
    # conservar otras variables previas
    current=parse_env(ENV.read_text(encoding="utf-8")) if ENV.exists() else {}
    for k,v in current.items():
        if k not in ordered: lines.append(f"{k}={v}")
    ENV.write_text("\n".join(lines)+"\n",encoding="utf-8")

def run(*args,check=True):
    print(">",*args)
    return subprocess.run(args,cwd=ROOT,text=True,capture_output=True,check=check)

def main():
    current=parse_env(ENV.read_text(encoding="utf-8")) if ENV.exists() else {}
    values=dict(DEFAULTS)
    api=current.get("SANDBOX_API_KEYS") or secrets.token_urlsafe(36)
    values["SANDBOX_API_KEYS"]=api
    values["N8N_SANDBOX_SERVICE_API_KEY"]=api
    values["SANDBOX_RUNNER_REGISTRATION_TOKEN"]=current.get("SANDBOX_RUNNER_REGISTRATION_TOKEN") or secrets.token_urlsafe(36)
    values["SANDBOX_RUNNER_API_KEYS"]=current.get("SANDBOX_RUNNER_API_KEYS") or secrets.token_urlsafe(36)
    values["SEARXNG_SECRET"]=current.get("SEARXNG_SECRET") or secrets.token_urlsafe(48)
    values["N8N_VERSION"]=current.get("N8N_VERSION") or DEFAULTS["N8N_VERSION"]
    values["N8N_SANDBOX_VERSION"]=current.get("N8N_SANDBOX_VERSION") or DEFAULTS["N8N_SANDBOX_VERSION"]
    write_env(values)

    print("\n[1/4] Descargando/iniciando servicios…")
    r=run("docker","compose","up","-d",check=False)
    print(r.stdout);print(r.stderr)
    if r.returncode!=0:
        print("ERROR: Docker Compose no pudo iniciar.");sys.exit(r.returncode)

    print("\n[2/4] Esperando sandbox-api saludable…")
    ok=False
    for _ in range(36):
        r=run("docker","compose","exec","-T","n8n","wget","-qO-","http://sandbox-api:8080/healthz",check=False)
        if r.returncode==0 and '"status":"ok"' in r.stdout.replace(" ",""):
            ok=True;break
        time.sleep(5)
    if not ok:
        print("Sandbox todavía no responde. Ejecuta:")
        print("docker compose logs sandbox-api")
        print("docker compose logs sandbox-runner-1")
        sys.exit(2)
    print("Sandbox: OK")

    print("\n[3/4] Probando búsqueda web SearXNG…")
    r=run("docker","compose","exec","-T","n8n","wget","-qO-","http://searxng:8080/search?q=lenvrak&format=json",check=False)
    search_ok=r.returncode==0 and '"results"' in r.stdout
    print("SearXNG:", "OK" if search_ok else "REVISAR")
    if not search_ok:
        print(r.stdout[-1000:]);print(r.stderr[-1000:])

    print("\n[4/4] Estado Docker")
    r=run("docker","compose","ps",check=False);print(r.stdout)

    print("\nCONFIGURACIÓN TERMINADA")
    print("n8n: http://127.0.0.1:5678")
    print("LENVRAK: http://127.0.0.1:8090")
    print("Asistencia Castilla: http://127.0.0.1:8080/login")
    print("\nEn n8n recarga con Ctrl+F5 y abre Assistant.")
    print("El modelo OpenAI que ya configuraste se conserva en el volumen de n8n.")
    print("Sandbox y búsqueda web quedan preconfigurados por variables de entorno.")

if __name__=="__main__": main()

