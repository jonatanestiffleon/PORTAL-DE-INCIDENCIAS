@echo off
cd /d "%~dp0\..\.."
echo === CONTENEDORES ===
docker compose ps
echo.
echo === SANDBOX HEALTH DESDE N8N ===
docker compose exec -T n8n wget -qO- http://sandbox-api:8080/healthz
echo.
echo === BUSQUEDA WEB DESDE N8N ===
docker compose exec -T n8n wget -qO- "http://searxng:8080/search?q=test&format=json"
echo.
echo === RUNNER ===
docker compose logs --tail=80 sandbox-runner-1
echo.
pause
