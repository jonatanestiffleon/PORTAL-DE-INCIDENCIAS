# n8n Assistant completo en LENVRAK

Actualización 0.9.3.

Incluye:
- modelo OpenAI: se conserva la configuración que ya hiciste en n8n;
- sandbox local oficial de n8n (`sandbox-certs`, `sandbox-api`, `sandbox-runner-1`);
- búsqueda web interna mediante SearXNG;
- contexto de instancia;
- conteo de tipos de nodo;
- retención de actividad 30 días;
- script automático de secretos;
- diagnóstico.

## Importante sobre puertos
Los puertos `8080` usados por `sandbox-api` y `searxng` existen **solo dentro de la red Docker**.
No se publican en Windows y NO chocan con:
- Asistencia Castilla: `127.0.0.1:8080`
- LENVRAK: `127.0.0.1:8090`

## Después de instalar el update
Ejecuta:
`.\scripts\windows_CONFIGURAR_N8N_ASSISTANT_COMPLETO.bat`

El script:
1. genera secretos;
2. guarda `.env`;
3. inicia los contenedores;
4. verifica sandbox;
5. verifica SearXNG;
6. muestra estado final.

Luego abre `http://127.0.0.1:5678`, pulsa `Ctrl+F5` y vuelve al Assistant.

## Uso
Para desarrollo local, n8n recomienda su sandbox propio.
Para producción pública, n8n recomienda Daytona; no se activa todavía porque esta instalación está en desarrollo local.
