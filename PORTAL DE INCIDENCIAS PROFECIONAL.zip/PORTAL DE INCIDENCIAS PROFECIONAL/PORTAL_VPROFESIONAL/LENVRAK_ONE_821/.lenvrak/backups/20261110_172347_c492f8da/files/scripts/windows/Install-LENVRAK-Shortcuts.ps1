[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$Desktop = [Environment]::GetFolderPath('Desktop')
$PowerShell = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
$Icon = Join-Path $PSScriptRoot 'assets\lenvrak.ico'
$TaskName = 'LENVRAK Edge Agent'
$HelperTaskName = 'LENVRAK Laragon Helper'

# Dejar el token/configuración de Edge preparado ANTES del siguiente docker compose up.
$python = (Get-Command python.exe -ErrorAction SilentlyContinue).Source
$usePy = $false
if (-not $python) {
    $python = (Get-Command py.exe -ErrorAction SilentlyContinue).Source
    $usePy = [bool]$python
}
if (-not $python) { throw 'Python no está disponible en PATH.' }
Push-Location $Root
try {
    if ($usePy) { & $python -3 'scripts\edge_agent\configure_edge_agent.py' }
    else { & $python 'scripts\edge_agent\configure_edge_agent.py' }
    if ($LASTEXITCODE -ne 0) { throw 'No se pudo preparar Edge Agent.' }
} finally { Pop-Location }

# Tarea bajo demanda, ejecutada con privilegios máximos y sin ventana visible.
$action = New-ScheduledTaskAction -Execute $PowerShell -Argument "-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$PSScriptRoot\Edge-Agent-Background.ps1`"" -WorkingDirectory $Root
$principal = New-ScheduledTaskPrincipal -UserId "$env:USERDOMAIN\$env:USERNAME" -LogonType Interactive -RunLevel Highest
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit (New-TimeSpan -Days 3650) -MultipleInstances IgnoreNew
$task = New-ScheduledTask -Action $action -Principal $principal -Settings $settings -Description 'LENVRAK Edge Agent elevado, oculto y ejecutado bajo demanda por el lanzador principal.'
Register-ScheduledTask -TaskName $TaskName -InputObject $task -Force | Out-Null

# Laragon Helper: tarea interactiva persistente, sin consola visible.
# Se ejecuta con el mismo Python que ya fue validado manualmente con `python -u`.
if ($usePy) {
    $helperArgs = "-3 -u `"scripts\laragon_helper\laragon_desktop_helper.py`""
} else {
    $helperArgs = "-u `"scripts\laragon_helper\laragon_desktop_helper.py`""
}
$helperAction = New-ScheduledTaskAction -Execute $python -Argument $helperArgs -WorkingDirectory $Root
$helperPrincipal = New-ScheduledTaskPrincipal -UserId "$env:USERDOMAIN\$env:USERNAME" -LogonType Interactive -RunLevel Highest
$helperSettings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit (New-TimeSpan -Days 3650) -MultipleInstances IgnoreNew
$helperTask = New-ScheduledTask -Action $helperAction -Principal $helperPrincipal -Settings $helperSettings -Description 'LENVRAK Laragon Helper interactivo. Controla Laragon desde la sesión del usuario y escucha solo en 127.0.0.1:8790.'
Register-ScheduledTask -TaskName $HelperTaskName -InputObject $helperTask -Force | Out-Null

$ws = New-Object -ComObject WScript.Shell
function New-Link([string]$Name,[string]$Script,[string]$Description) {
    $lnk = $ws.CreateShortcut((Join-Path $Desktop ($Name + '.lnk')))
    $lnk.TargetPath = $PowerShell
    $lnk.Arguments = "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$Script`""
    $lnk.WorkingDirectory = $Root
    $lnk.Description = $Description
    if (Test-Path $Icon) { $lnk.IconLocation = $Icon }
    $lnk.Save()
}

New-Link 'Iniciar LENVRAK One' (Join-Path $PSScriptRoot 'Start-LENVRAK-One.ps1') 'Inicia toda la plataforma LENVRAK One en segundo plano.'
New-Link 'Detener LENVRAK One' (Join-Path $PSScriptRoot 'Stop-LENVRAK-One.ps1') 'Detiene ordenadamente LENVRAK One sin borrar datos.'

# Estado: visible a propósito para diagnóstico rápido.
$status = $ws.CreateShortcut((Join-Path $Desktop 'Estado LENVRAK One.lnk'))
$status.TargetPath = $PowerShell
$status.Arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$(Join-Path $PSScriptRoot 'Status-LENVRAK-One.ps1')`""
$status.WorkingDirectory = $Root
$status.Description = 'Muestra el estado de los componentes LENVRAK One.'
if (Test-Path $Icon) { $status.IconLocation = $Icon }
$status.Save()

Write-Host 'Accesos directos y tareas Edge/Laragon Helper creados correctamente.' -ForegroundColor Green
