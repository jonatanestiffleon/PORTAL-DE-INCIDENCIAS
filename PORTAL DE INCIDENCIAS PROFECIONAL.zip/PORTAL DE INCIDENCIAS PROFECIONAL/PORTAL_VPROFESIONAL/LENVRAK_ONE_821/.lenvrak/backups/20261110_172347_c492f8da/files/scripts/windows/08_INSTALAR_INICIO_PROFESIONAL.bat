@echo off
setlocal
cd /d "%~dp0\..\.."

net session >nul 2>&1
if not "%errorlevel%"=="0" (
  echo Solicitando permisos de Administrador para la configuracion inicial...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)

echo.
echo =======================================================
echo   LENVRAK One - Instalacion de inicio profesional
echo =======================================================
echo.

powershell -NoProfile -ExecutionPolicy Bypass -File "scripts\windows\Install-LENVRAK-Shortcuts.ps1"
if errorlevel 1 (
  echo.
  echo ERROR: no se pudo completar la instalacion.
  pause
  exit /b 1
)

echo.
echo LISTO.
echo Se crearon accesos directos en el Escritorio:
echo   - Iniciar LENVRAK One
echo   - Detener LENVRAK One
echo   - Estado LENVRAK One
echo.
echo Tambien se registraron las tareas en segundo plano:
echo   - LENVRAK Edge Agent
echo   - LENVRAK Laragon Helper
echo.
echo A partir de ahora use Iniciar LENVRAK One.
pause
endlocal
