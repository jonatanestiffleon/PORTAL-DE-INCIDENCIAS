[CmdletBinding()]
param()
$ErrorActionPreference = 'SilentlyContinue'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$StateDir = Join-Path $Root '.lenvrak\launcher'
$LogFile = Join-Path $StateDir 'launcher.log'
$TaskName = 'LENVRAK Edge Agent'
$HelperTaskName = 'LENVRAK Laragon Helper'
New-Item -ItemType Directory -Force -Path $StateDir | Out-Null
function Log([string]$m) { Add-Content -Path $LogFile -Value "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $m" -Encoding UTF8 }

Log '=== DETENIENDO LENVRAK ONE ==='
try { Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue } catch {}
try { Stop-ScheduledTask -TaskName $HelperTaskName -ErrorAction SilentlyContinue } catch {}
foreach ($port in 8790,8780,8765) {
    try {
        Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue |
            Select-Object -ExpandProperty OwningProcess -Unique |
            ForEach-Object { Stop-Process -Id $_ -Force -ErrorAction SilentlyContinue }
    } catch {}
}

try {
    Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
      Where-Object {
        ($_.Name -eq 'python.exe' -and $_.CommandLine -like '*laragon_desktop_helper.py*')
      } |
      ForEach-Object {
        Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue
      }
} catch {}

Push-Location $Root
try {
    & docker compose stop 2>&1 | Out-String | Add-Content -Path $LogFile -Encoding UTF8
} catch {}
Pop-Location
Log 'Servicios LENVRAK detenidos. Docker Desktop queda disponible para otros proyectos.'
