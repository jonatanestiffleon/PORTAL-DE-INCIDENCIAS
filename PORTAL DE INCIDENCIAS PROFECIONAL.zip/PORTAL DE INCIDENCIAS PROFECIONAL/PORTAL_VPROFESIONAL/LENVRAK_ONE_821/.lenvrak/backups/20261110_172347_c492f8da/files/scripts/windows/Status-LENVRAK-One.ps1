$Root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path

function TestUrl($u){
    try {
        $r=Invoke-WebRequest $u -UseBasicParsing -TimeoutSec 2
        return $true
    } catch {
        return $false
    }
}

$rows=@(
    [pscustomobject]@{Componente='LENVRAK Web';Puerto=8090;Estado=if(TestUrl 'http://127.0.0.1:8090/'){'ONLINE'}else{'OFFLINE'}},
    [pscustomobject]@{Componente='API';Puerto=8000;Estado=if(TestUrl 'http://127.0.0.1:8000/health'){'ONLINE'}else{'OFFLINE'}},
    [pscustomobject]@{Componente='n8n';Puerto=5678;Estado=if(TestUrl 'http://127.0.0.1:5678/'){'ONLINE'}else{'OFFLINE'}},
    [pscustomobject]@{Componente='Update Manager';Puerto=8765;Estado=if(TestUrl 'http://127.0.0.1:8765/health'){'ONLINE'}else{'OFFLINE'}}
)

try {
    $h=Invoke-RestMethod 'http://127.0.0.1:8000/api/v1/runbooks/agent-health' -TimeoutSec 3
    $edge=if($h.ok -and $h.state -eq 'online'){'ONLINE'}else{'OFFLINE'}
} catch {$edge='OFFLINE'}
$rows += [pscustomobject]@{Componente='Edge Agent';Puerto=8780;Estado=$edge}

try {
    $lh=Get-NetTCPConnection -LocalPort 8790 -State Listen -ErrorAction SilentlyContinue
    $lhs=if($lh){'ONLINE'}else{'OFFLINE'}
} catch {$lhs='OFFLINE'}
$rows += [pscustomobject]@{Componente='Laragon Helper';Puerto=8790;Estado=$lhs}
if($lhs -eq 'OFFLINE'){
    try{
        $hi=Get-ScheduledTaskInfo -TaskName 'LENVRAK Laragon Helper' -ErrorAction SilentlyContinue
        if($hi){$helperDiag="Tarea Helper: LastTaskResult=$($hi.LastTaskResult)"}
        else{$helperDiag="Tarea Helper no instalada"}
    }catch{$helperDiag="Tarea Helper no disponible"}
}

Write-Host ''
$rows | Format-Table -AutoSize
Write-Host ''

$online=($rows|Where-Object {$_.Estado -eq 'ONLINE'}).Count
if($online -eq 6){
    Write-Host 'LENVRAK LISTO: todos los componentes operativos.' -ForegroundColor Green
}else{
    Write-Host "LENVRAK PARCIAL: $online/6 componentes ONLINE." -ForegroundColor Yellow
}

Write-Host ''
if($helperDiag){Write-Host $helperDiag -ForegroundColor DarkYellow}
Write-Host "Logs: $Root\.lenvrak\launcher" -ForegroundColor Cyan
Read-Host 'Presione ENTER para cerrar'
