[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$StateDir = Join-Path $Root '.lenvrak\launcher'
$LogFile = Join-Path $StateDir 'launcher.log'
$UpdateOut = Join-Path $StateDir 'update-manager.out.log'
$UpdateErr = Join-Path $StateDir 'update-manager.err.log'
$TaskName = 'LENVRAK Edge Agent'
$DockerTimeoutSeconds = 180
$ServiceTimeoutSeconds = 120

New-Item -ItemType Directory -Force -Path $StateDir | Out-Null

function Write-Log([string]$Message) {
    $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $Message"
    Add-Content -Path $LogFile -Value $line -Encoding UTF8
}

function Show-Error([string]$Message) {
    Write-Log "ERROR: $Message"
    try {
        Add-Type -AssemblyName System.Windows.Forms
        [System.Windows.Forms.MessageBox]::Show(
            "$Message`n`nRevise:`n$LogFile",
            'LENVRAK One',
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    } catch {}
}

function Test-Http([string]$Url, [int]$TimeoutSec = 2) {
    try {
        $r = Invoke-WebRequest -Uri $Url -UseBasicParsing -TimeoutSec $TimeoutSec
        return ($r.StatusCode -ge 200 -and $r.StatusCode -lt 500)
    } catch {
        return $false
    }
}

function Wait-Http([string]$Url, [int]$TimeoutSec) {
    $limit = (Get-Date).AddSeconds($TimeoutSec)
    while ((Get-Date) -lt $limit) {
        if (Test-Http $Url 2) { return $true }
        Start-Sleep -Seconds 2
    }
    return $false
}

function Get-PythonPath {
    $cmd = Get-Command python.exe -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    $cmd = Get-Command py.exe -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    return $null
}

function Ensure-Docker {
    Write-Log 'Comprobando Docker Engine...'
    try {
        & docker info *> $null
        if ($LASTEXITCODE -eq 0) { Write-Log 'Docker ya está activo.'; return $true }
    } catch {}

    $candidates = @(
        "$env:ProgramFiles\Docker\Docker\Docker Desktop.exe",
        "$env:LOCALAPPDATA\Docker\Docker Desktop.exe"
    )
    $dockerDesktop = $candidates | Where-Object { Test-Path $_ } | Select-Object -First 1
    if (-not $dockerDesktop) {
        Show-Error 'No se encontró Docker Desktop. Abra o reinstale Docker Desktop.'
        return $false
    }

    Write-Log "Iniciando Docker Desktop: $dockerDesktop"
    Start-Process -FilePath $dockerDesktop | Out-Null
    $limit = (Get-Date).AddSeconds($DockerTimeoutSeconds)
    while ((Get-Date) -lt $limit) {
        Start-Sleep -Seconds 3
        try {
            & docker info *> $null
            if ($LASTEXITCODE -eq 0) { Write-Log 'Docker Engine listo.'; return $true }
        } catch {}
    }
    Show-Error 'Docker Desktop no quedó listo dentro del tiempo esperado.'
    return $false
}

function Ensure-EdgeConfig {
    $python = Get-PythonPath
    if (-not $python) {
        Show-Error 'Python no está disponible en PATH. Es necesario para Edge Agent y Update Manager.'
        return $false
    }
    Write-Log 'Verificando configuración persistente de Edge Agent...'
    Push-Location $Root
    try {
        if ([IO.Path]::GetFileName($python) -ieq 'py.exe') {
            & $python -3 'scripts\edge_agent\configure_edge_agent.py' *> $null
        } else {
            & $python 'scripts\edge_agent\configure_edge_agent.py' *> $null
        }
        if ($LASTEXITCODE -ne 0) { throw 'configure_edge_agent.py devolvió error.' }
    } finally { Pop-Location }
    return $true
}

function Start-Compose {
    Write-Log 'Levantando contenedores LENVRAK (db, api, web, n8n, sandbox, búsqueda)...'
    Push-Location $Root
    try {
        $out = & docker compose up -d 2>&1 | Out-String
        Add-Content -Path $LogFile -Value $out -Encoding UTF8
        if ($LASTEXITCODE -ne 0) { throw 'docker compose up -d devolvió error.' }
    } finally { Pop-Location }
}

function Start-UpdateManager {
    if (Test-Http 'http://127.0.0.1:8765/health' 1) {
        Write-Log 'Update Manager ya está activo.'
        return $true
    }
    $python = Get-PythonPath
    if (-not $python) { return $false }

    $exe = $python
    $args = @()
    if ([IO.Path]::GetFileName($python) -ieq 'py.exe') {
        $args = @('-3', 'tools\update_manager\server.py')
    } else {
        $args = @('tools\update_manager\server.py')
    }
    Write-Log 'Iniciando Update Manager en segundo plano...'
    $sp = @{
        FilePath = $exe
        ArgumentList = $args
        WorkingDirectory = $Root
        WindowStyle = 'Hidden'
        PassThru = $true
        RedirectStandardOutput = $UpdateOut
        RedirectStandardError = $UpdateErr
    }
    $p = Start-Process @sp
    Set-Content -Path (Join-Path $StateDir 'update-manager.pid') -Value $p.Id -Encoding ASCII
    if (-not (Wait-Http 'http://127.0.0.1:8765/health' 20)) {
        Write-Log 'ADVERTENCIA: Update Manager no respondió en 20 s.'
        return $false
    }
    Write-Log 'Update Manager listo.'
    return $true
}

function Start-EdgeAgent {
    # Se consulta por la API porque el /health del agente requiere token.
    try {
        $h = Invoke-RestMethod -Uri 'http://127.0.0.1:8000/api/v1/runbooks/agent-health' -TimeoutSec 3
        if ($h.ok -and $h.state -eq 'online') {
            Write-Log 'Edge Agent ya está online.'
            return $true
        }
    } catch {}

    $task = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
    if (-not $task) {
        Show-Error "Falta la instalación inicial del acceso directo/Edge Agent. Ejecute una sola vez scripts\windows\08_INSTALAR_INICIO_PROFESIONAL.bat como Administrador."
        return $false
    }

    Write-Log 'Iniciando Edge Agent elevado y oculto mediante Tarea Programada...'
    Start-ScheduledTask -TaskName $TaskName
    $limit = (Get-Date).AddSeconds(30)
    while ((Get-Date) -lt $limit) {
        Start-Sleep -Seconds 2
        try {
            $h = Invoke-RestMethod -Uri 'http://127.0.0.1:8000/api/v1/runbooks/agent-health' -TimeoutSec 3
            if ($h.ok -and $h.state -eq 'online') { Write-Log 'Edge Agent online.'; return $true }
        } catch {}
    }
    Show-Error 'Edge Agent no quedó online. Revise .lenvrak\edge_agent.log.'
    return $false
}

try {
    Write-Log '=== INICIO LENVRAK ONE ==='
    Set-Location $Root

    if (-not (Ensure-EdgeConfig)) { exit 1 }
    if (-not (Ensure-Docker)) { exit 1 }
    Start-Compose

    if (-not (Wait-Http 'http://127.0.0.1:8000/health' $ServiceTimeoutSeconds)) {
        Show-Error 'La API LENVRAK no respondió en http://127.0.0.1:8000/health.'
        exit 1
    }
    Write-Log 'API lista.'

    if (-not (Wait-Http 'http://127.0.0.1:8090/' $ServiceTimeoutSeconds)) {
        Show-Error 'La interfaz LENVRAK no respondió en el puerto 8090.'
        exit 1
    }
    Write-Log 'Web lista.'

    if (-not (Wait-Http 'http://127.0.0.1:5678/' $ServiceTimeoutSeconds)) {
        Write-Log 'ADVERTENCIA: n8n todavía no responde; continuará iniciando en segundo plano.'
    } else { Write-Log 'n8n listo.' }

    [void](Start-UpdateManager)
    if (-not (Start-EdgeAgent)) { exit 1 }

    Write-Log 'Todos los componentes esenciales están activos.'
    Start-Process 'http://127.0.0.1:8090/' | Out-Null
    Write-Log 'Interfaz LENVRAK abierta. === FIN INICIO ==='
} catch {
    Show-Error $_.Exception.Message
    exit 1
}
