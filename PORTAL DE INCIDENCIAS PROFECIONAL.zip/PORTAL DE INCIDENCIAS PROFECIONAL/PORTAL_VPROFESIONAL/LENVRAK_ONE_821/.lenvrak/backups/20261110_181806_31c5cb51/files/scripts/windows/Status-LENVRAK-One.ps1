$Root=(Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path

function TestUrl([string]$Url){
    try{
        $null=Invoke-WebRequest -Uri $Url -UseBasicParsing -TimeoutSec 2
        return $true
    }catch{
        return $false
    }
}

$rows=@()

$rows += [pscustomobject]@{
    Componente='LENVRAK Web'; Puerto=8090
    Estado=if(TestUrl 'http://127.0.0.1:8090/'){'ONLINE'}else{'OFFLINE'}
}
$rows += [pscustomobject]@{
    Componente='API'; Puerto=8000
    Estado=if(TestUrl 'http://127.0.0.1:8000/health'){'ONLINE'}else{'OFFLINE'}
}
$rows += [pscustomobject]@{
    Componente='n8n'; Puerto=5678
    Estado=if(TestUrl 'http://127.0.0.1:5678/'){'ONLINE'}else{'OFFLINE'}
}
$rows += [pscustomobject]@{
    Componente='Update Manager'; Puerto=8765
    Estado=if(TestUrl 'http://127.0.0.1:8765/health'){'ONLINE'}else{'OFFLINE'}
}

try{
    $h=Invoke-RestMethod -Uri 'http://127.0.0.1:8000/api/v1/runbooks/agent-health' -TimeoutSec 3
    $edge=if($h.ok -and $h.state -eq 'online'){'ONLINE'}else{'OFFLINE'}
}catch{
    $edge='OFFLINE'
}
$rows += [pscustomobject]@{Componente='Edge Agent';Puerto=8780;Estado=$edge}

$helper='OFFLINE'
$helperVersion='-'
try{
    $tokenLine=Get-Content (Join-Path $Root '.env') -ErrorAction Stop | Where-Object {$_ -like 'EDGE_AGENT_TOKEN=*'} | Select-Object -First 1
    if($tokenLine){
        $token=($tokenLine -split '=',2)[1].Trim()
        $hh=Invoke-RestMethod -Uri 'http://127.0.0.1:8790/health' -Headers @{'X-LENVRAK-EDGE-TOKEN'=$token} -TimeoutSec 3
        if($hh.ok){
            $helper='ONLINE'
            if($hh.version){$helperVersion=[string]$hh.version}
        }
    }
}catch{
    $helper='OFFLINE'
}
$rows += [pscustomobject]@{Componente='Laragon Helper';Puerto=8790;Estado=$helper}

Write-Host ''
$rows | Format-Table -AutoSize
Write-Host ''

$online=@($rows|Where-Object {$_.Estado -eq 'ONLINE'}).Count
if($online -eq 6){
    Write-Host 'LENVRAK LISTO: 6/6 componentes ONLINE.' -ForegroundColor Green
    Write-Host "Laragon Helper verificado por /health. Version: $helperVersion" -ForegroundColor Green
}else{
    Write-Host "LENVRAK PARCIAL: $online/6 componentes ONLINE." -ForegroundColor Yellow
    if($helper -eq 'OFFLINE'){
        $runtime=Join-Path $Root '.lenvrak\launcher\laragon-helper.runtime.log'
        if(Test-Path $runtime){
            Write-Host 'Ultimo Helper:' -ForegroundColor DarkYellow
            Get-Content $runtime -Tail 4 -ErrorAction SilentlyContinue | ForEach-Object { Write-Host "  $_" -ForegroundColor DarkYellow }
        }
    }
}

Write-Host ''
Write-Host "Logs: $Root\.lenvrak\launcher" -ForegroundColor Cyan
Write-Host ''
Read-Host 'Presione ENTER para cerrar'
