[CmdletBinding()]
param()

$ErrorActionPreference='SilentlyContinue'
$Root=(Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$StateDir=Join-Path $Root '.lenvrak\launcher'
$OutLog=Join-Path $StateDir 'laragon-helper.out.log'
$ErrLog=Join-Path $StateDir 'laragon-helper.err.log'
New-Item -ItemType Directory -Force -Path $StateDir | Out-Null
Set-Location $Root

# Do not start a duplicate if 8790 is already listening.
try {
    $tcp=Get-NetTCPConnection -LocalPort 8790 -State Listen -ErrorAction SilentlyContinue
    if($tcp){ exit 0 }
} catch {}

# Remove stale helper instances left from manual/debug sessions.
try {
    Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
      Where-Object {
        $_.Name -eq 'python.exe' -and
        $_.CommandLine -like '*laragon_desktop_helper.py*'
      } |
      ForEach-Object {
        Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue
      }
} catch {}
Start-Sleep -Milliseconds 500

$python=(Get-Command python.exe -ErrorAction SilentlyContinue).Source
$usePy=$false
if(-not $python){
    $python=(Get-Command py.exe -ErrorAction SilentlyContinue).Source
    $usePy=[bool]$python
}
if(-not $python){
    Add-Content -Path $ErrLog -Value "$(Get-Date -Format s) Python no disponible." -Encoding UTF8
    exit 2
}

try {
    if($usePy){
        & $python -3 -u 'scripts\laragon_helper\laragon_desktop_helper.py' 1>>$OutLog 2>>$ErrLog
    } else {
        & $python -u 'scripts\laragon_helper\laragon_desktop_helper.py' 1>>$OutLog 2>>$ErrLog
    }
    exit $LASTEXITCODE
} catch {
    Add-Content -Path $ErrLog -Value "$(Get-Date -Format s) $($_.Exception.Message)" -Encoding UTF8
    exit 3
}
