from __future__ import annotations
import json
import os
import subprocess
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ENV = ROOT / ".env"
BIND = "127.0.0.1"
PORT = 8790

def env_value(key: str, default: str = "") -> str:
    if ENV.exists():
        for line in ENV.read_text(encoding="utf-8", errors="ignore").splitlines():
            if line.strip().startswith(key + "="):
                return line.split("=", 1)[1].strip()
    return os.environ.get(key, default)

TOKEN = env_value("EDGE_AGENT_TOKEN", "")

def run_ps(script: str, timeout: int = 25) -> tuple[bool, str]:
    p = subprocess.run(
        ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script],
        capture_output=True,
        text=True,
        timeout=timeout,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    out = ((p.stdout or "") + "\n" + (p.stderr or "")).strip()
    return p.returncode == 0, out[-5000:]

def laragon_start_all() -> dict:
    script = r"""
$ErrorActionPreference='SilentlyContinue'
$exe='C:\laragon\laragon.exe'
if(-not (Test-Path $exe)){ Write-Output 'LARAGON_NOT_FOUND'; exit 2 }
$p=Get-Process laragon -ErrorAction SilentlyContinue | Select-Object -First 1
if(-not $p){ Start-Process $exe; Start-Sleep -Seconds 2; $p=Get-Process laragon -ErrorAction SilentlyContinue | Select-Object -First 1 }
if(-not $p){ Write-Output 'LARAGON_NOT_RUNNING'; exit 3 }

Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes
Add-Type @'
using System;
using System.Runtime.InteropServices;
public static class LenvrakMouse {
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
  [DllImport("user32.dll")] public static extern bool SetCursorPos(int X,int Y);
  [DllImport("user32.dll")] public static extern void mouse_event(uint f,uint dx,uint dy,uint data,UIntPtr extra);
  public const uint LEFTDOWN=0x0002, LEFTUP=0x0004;
}
'@

for($i=0;$i -lt 15;$i++){ $p.Refresh(); if($p.MainWindowHandle -ne 0){break}; Start-Sleep -Milliseconds 250 }
if($p.MainWindowHandle -eq 0){ Write-Output 'LARAGON_NO_VISIBLE_WINDOW'; exit 4 }

[LenvrakMouse]::SetForegroundWindow($p.MainWindowHandle)|Out-Null
Start-Sleep -Milliseconds 350
$root=[System.Windows.Automation.AutomationElement]::FromHandle($p.MainWindowHandle)
$rr=$root.Current.BoundingRectangle
Write-Output ("ROOT:{0},{1},{2},{3}" -f [int]$rr.Left,[int]$rr.Top,[int]$rr.Width,[int]$rr.Height)

function ClickPoint([int]$x,[int]$y,[string]$tag){
  [LenvrakMouse]::SetCursorPos($x,$y)|Out-Null
  Start-Sleep -Milliseconds 120
  [LenvrakMouse]::mouse_event([LenvrakMouse]::LEFTDOWN,0,0,0,[UIntPtr]::Zero)
  [LenvrakMouse]::mouse_event([LenvrakMouse]::LEFTUP,0,0,0,[UIntPtr]::Zero)
  Write-Output ($tag+":"+$x+","+$y)
}

$walker=[System.Windows.Automation.TreeWalker]::RawViewWalker
$nodes=New-Object System.Collections.Generic.List[object]
function WalkRaw($parent,[int]$depth){
  if($depth -gt 14){return}
  $c=$walker.GetFirstChild($parent)
  while($c){
    try{$nodes.Add($c)}catch{}
    WalkRaw $c ($depth+1)
    $c=$walker.GetNextSibling($c)
  }
}
WalkRaw $root 0

$mysql=$null
foreach($el in $nodes){
  try{
    $r=$el.Current.BoundingRectangle
    if($r.Width -le 0 -or $r.Height -le 0){continue}
    $txt=([string]$el.Current.Name)+" "+([string]$el.Current.AutomationId)+" "+([string]$el.Current.HelpText)+" "+([string]$el.Current.ClassName)
    if($txt -match '(?i)mysql'){ $mysql=$el; Write-Output ("MYSQL_RAW_FOUND:"+$txt); break }
  }catch{}
}

if($mysql){
  try{$t=$mysql.GetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern);if($t){$t.Toggle();Write-Output 'MYSQL_RAW_TOGGLE';exit 0}}catch{}
  try{$i=$mysql.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern);if($i){$i.Invoke();Write-Output 'MYSQL_RAW_INVOKE';exit 0}}catch{}
  $mr=$mysql.Current.BoundingRectangle
  ClickPoint ([int]($mr.Left-24)) ([int]($mr.Top+$mr.Height/2)) 'MYSQL_LABEL_RELATIVE_CLICK'
  exit 0
}

$items=@()
foreach($el in $nodes){
  try{
    $r=$el.Current.BoundingRectangle
    if($r.Width -ge 12 -and $r.Width -le 80 -and $r.Height -ge 8 -and $r.Height -le 45 `
       -and $r.Left -ge ($rr.Left+25) -and $r.Right -le ($rr.Left+340) `
       -and $r.Top -ge ($rr.Top+70) -and $r.Bottom -le ($rr.Bottom-30)){
      $items += [pscustomobject]@{Y=[int]($r.Top+$r.Height/2); R=$r; E=$el}
    }
  }catch{}
}
$items=$items|Sort-Object Y
$rows=@()
foreach($it in $items){
  $near=$false
  foreach($row in $rows){ if([math]::Abs($row.Y-$it.Y) -le 8){$near=$true;break} }
  if(-not $near){ $rows += $it }
}

$serviceRows=@($rows | Where-Object { $_.Y -gt ($rr.Top+90) -and $_.Y -lt ($rr.Top+430) })
if($serviceRows.Count -ge 3){
  $target=$serviceRows[1]
  try{$t=$target.E.GetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern);if($t){$t.Toggle();Write-Output 'MYSQL_SECOND_ROW_TOGGLE';exit 0}}catch{}
  try{$i=$target.E.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern);if($i){$i.Invoke();Write-Output 'MYSQL_SECOND_ROW_INVOKE';exit 0}}catch{}
  ClickPoint ([int]($target.R.Left+$target.R.Width/2)) ([int]($target.R.Top+$target.R.Height/2)) 'MYSQL_SECOND_ROW_CLICK'
  exit 0
}

$x=[int]($rr.Left+($rr.Width*0.155))
$y=[int]($rr.Top+($rr.Height*0.345))
if($x -gt $rr.Left -and $x -lt $rr.Right -and $y -gt $rr.Top -and $y -lt $rr.Bottom){
  ClickPoint $x $y 'MYSQL_WINDOW_RELATIVE_CLICK'
  exit 0
}

Write-Output 'MYSQL_UI_TARGET_NOT_FOUND'
exit 7
"""
    ok,out=run_ps(script)
    return {"ok":ok,"action":"laragon_mysql_toggle_raw","output":out}

class Handler(BaseHTTPRequestHandler):
    server_version = "LENVRAKLaragonHelper/0.14.5"

    def log_message(self, fmt, *args):
        pass

    def _json(self, status: int, data: dict):
        raw = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def _auth(self) -> bool:
        return bool(TOKEN) and self.headers.get("X-LENVRAK-EDGE-TOKEN", "") == TOKEN

    def do_GET(self):
        if self.path != "/health":
            return self._json(404, {"ok": False, "error": "not_found"})
        if not self._auth():
            return self._json(401, {"ok": False, "error": "unauthorized"})
        return self._json(200, {
            "ok": True,
            "service": "lenvrak-laragon-desktop-helper",
            "version": "0.14.5",
            "interactive_session": True,
        })

    def do_POST(self):
        if not self._auth():
            return self._json(401, {"ok": False, "error": "unauthorized"})
        if self.path == "/v1/laragon/start-all":
            result = laragon_start_all()
            return self._json(200 if result["ok"] else 409, result)
        return self._json(404, {"ok": False, "error": "not_found"})

if __name__ == "__main__":
    if os.name != "nt":
        raise SystemExit("Laragon Desktop Helper solo funciona en Windows.")
    if not TOKEN:
        raise SystemExit("EDGE_AGENT_TOKEN no configurado.")
    ThreadingHTTPServer((BIND, PORT), Handler).serve_forever()
