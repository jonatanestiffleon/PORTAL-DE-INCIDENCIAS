Option Explicit

Dim fso, sh, scriptDir, root, logDir, outLog, errLog, cmd
Set fso = CreateObject("Scripting.FileSystemObject")
Set sh = CreateObject("WScript.Shell")

scriptDir = fso.GetParentFolderName(WScript.ScriptFullName)
root = fso.GetParentFolderName(fso.GetParentFolderName(scriptDir))
logDir = fso.BuildPath(root, ".lenvrak\launcher")

If Not fso.FolderExists(logDir) Then
    fso.CreateFolder(logDir)
End If

outLog = fso.BuildPath(logDir, "laragon-helper.out.log")
errLog = fso.BuildPath(logDir, "laragon-helper.err.log")

' Use exactly the command already proven manually, but hidden.
cmd = "cmd.exe /d /s /c ""cd /d """ & root & """ && python -u ""scripts\laragon_helper\laragon_desktop_helper.py"" 1>>""" & outLog & """ 2>>""" & errLog & """"""

' 0 = hidden window, False = asynchronous.
sh.Run cmd, 0, False
