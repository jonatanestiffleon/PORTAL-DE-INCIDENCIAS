[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$StateDir = Join-Path $Root '.lenvrak\launcher'
$LogFile = Join-Path $StateDir 'launcher.log'
$UpdateOut = Join-Path $StateDir 'update-manager.out.log'
$UpdateErr = Join-Path $StateDir 'update-manager.err.log'
$TaskName = 'LENVRAK Edge Agent'
$DockerTimeoutSeconds = 180
$ServiceTimeoutSeconds = 120

New-Item -ItemType Directory -Force -Path $StateDir | Out-Null

function Write-Log([string]$Message) {
    $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $Message"
    Add-Content -Path $LogFile -Value $line -Encoding UTF8
}

function Show-Error([string]$Message) {
    Write-Log "ERROR: $Message"
    try {
        Add-Type -AssemblyName System.Windows.Forms
        [System.Windows.Forms.MessageBox]::Show(
            "$Message`n`nRevise:`n$LogFile",
            'LENVRAK One',
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    } catch {}
}

function Test-Http([string]$Url, [int]$TimeoutSec = 2) {
    try {
        $r = Invoke-WebRequest -Uri $Url -UseBasicParsing -TimeoutSec $TimeoutSec
        return ($r.StatusCode -ge 200 -and $r.StatusCode -lt 500)
    } catch {
        return $false
    }
}

function Wait-Http([string]$Url, [int]$TimeoutSec) {
    $limit = (Get-Date).AddSeconds($TimeoutSec)
    while ((Get-Date) -lt $limit) {
        if (Test-Http $Url 2) { return $true }
        Start-Sleep -Seconds 2
    }
    return $false
}

function Get-PythonPath {
    $cmd = Get-Command python.exe -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    $cmd = Get-Command py.exe -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    return $null
}

function Ensure-Docker {
    Write-Log 'Comprobando Docker Engine...'
    try {
        & docker info *> $null
        if ($LASTEXITCODE -eq 0) { Write-Log 'Docker ya está activo.'; return $true }
    } catch {}

    $candidates = @(
        "$env:ProgramFiles\Docker\Docker\Docker Desktop.exe",
        "$env:LOCALAPPDATA\Docker\Docker Desktop.exe"
    )
    $dockerDesktop = $candidates | Where-Object { Test-Path $_ } | Select-Object -First 1
    if (-not $dockerDesktop) {
        Show-Error 'No se encontró Docker Desktop. Abra o reinstale Docker Desktop.'
        return $false
    }

    Write-Log "Iniciando Docker Desktop: $dockerDesktop"
    Start-Process -FilePath $dockerDesktop | Out-Null
    $limit = (Get-Date).AddSeconds($DockerTimeoutSeconds)
    while ((Get-Date) -lt $limit) {
        Start-Sleep -Seconds 3
        try {
            & docker info *> $null
            if ($LASTEXITCODE -eq 0) { Write-Log 'Docker Engine listo.'; return $true }
        } catch {}
    }
    Show-Error 'Docker Desktop no quedó listo dentro del tiempo esperado.'
    return $false
}

function Ensure-EdgeConfig {
    $python = Get-PythonPath
    if (-not $python) {
        Show-Error 'Python no está disponible en PATH. Es necesario para Edge Agent y Update Manager.'
        return $false
    }
    Write-Log 'Verificando configuración persistente de Edge Agent...'
    Push-Location $Root
    try {
        if ([IO.Path]::GetFileName($python) -ieq 'py.exe') {
            & $python -3 'scripts\edge_agent\configure_edge_agent.py' *> $null
        } else {
            & $python 'scripts\edge_agent\configure_edge_agent.py' *> $null
        }
        if ($LASTEXITCODE -ne 0) { throw 'configure_edge_agent.py devolvió error.' }
    } finally { Pop-Location }
    return $true
}

function Invoke-NativeProcess([string]$FilePath, [string]$Arguments, [string]$WorkingDirectory, [int]$TimeoutSec = 180) {
    # PowerShell 5.1 convierte parte del stderr de Docker Compose (por ejemplo
    # "Container ... Starting") en ErrorRecord. Con ErrorActionPreference=Stop
    # eso podía abortar el lanzador aunque Docker estuviera funcionando bien.
    # Se ejecuta como proceso nativo y se evalúa SOLO su código de salida real.
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $FilePath
    $psi.Arguments = $Arguments
    $psi.WorkingDirectory = $WorkingDirectory
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $p = New-Object System.Diagnostics.Process
    $p.StartInfo = $psi
    if (-not $p.Start()) { throw "No se pudo iniciar: $FilePath $Arguments" }
    if (-not $p.WaitForExit($TimeoutSec * 1000)) {
        try { $p.Kill() } catch {}
        throw "Tiempo agotado ejecutando: $FilePath $Arguments"
    }
    $stdout = $p.StandardOutput.ReadToEnd()
    $stderr = $p.StandardError.ReadToEnd()
    return [pscustomobject]@{ ExitCode=$p.ExitCode; StdOut=$stdout; StdErr=$stderr }
}

function Wait-Database([int]$TimeoutSec = 120) {
    Write-Log 'Esperando PostgreSQL healthy...'
    $limit = (Get-Date).AddSeconds($TimeoutSec)
    while ((Get-Date) -lt $limit) {
        try {
            Push-Location $Root
            $id = (& docker compose ps -q db 2>$null | Out-String).Trim()
            Pop-Location
            if ($id) {
                $status = (& docker inspect --format='{{.State.Health.Status}}' $id 2>$null | Out-String).Trim()
                if ($status -eq 'healthy') { Write-Log 'PostgreSQL healthy.'; return $true }
            }
        } catch { try { Pop-Location } catch {} }
        Start-Sleep -Seconds 2
    }
    return $false
}

function Invoke-ComposeSafe([string]$Arguments) {
    $tmpOut = Join-Path $StateDir 'compose.out.log'
    $tmpErr = Join-Path $StateDir 'compose.err.log'
    Remove-Item $tmpOut,$tmpErr -Force -ErrorAction SilentlyContinue

    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = 'cmd.exe'
    $psi.Arguments = '/d /s /c "docker compose ' + $Arguments + '"'
    $psi.WorkingDirectory = $Root
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true

    $p = New-Object System.Diagnostics.Process
    $p.StartInfo = $psi
    [void]$p.Start()
    $stdout = $p.StandardOutput.ReadToEnd()
    $stderr = $p.StandardError.ReadToEnd()
    $p.WaitForExit()

    if ($stdout) { Add-Content -Path $LogFile -Value $stdout -Encoding UTF8 }
    if ($stderr) { Add-Content -Path $LogFile -Value $stderr -Encoding UTF8 }

    if ($p.ExitCode -ne 0) {
        throw "docker compose $Arguments devolvió código $($p.ExitCode)."
    }
}

function Start-Compose {
    Write-Log 'Arranque seguro: DB -> API -> Web -> n8n -> servicios opcionales.'

    Invoke-ComposeSafe 'up -d db'
    if (-not (Wait-Database 120)) { throw 'PostgreSQL no alcanzó estado healthy.' }

    Invoke-ComposeSafe 'up -d api'
    if (-not (Wait-Http 'http://127.0.0.1:8000/health' 120)) {
        throw 'API no alcanzó estado healthy.'
    }

    # Web no depende del sandbox.
    Invoke-ComposeSafe 'up -d web'
    if (-not (Wait-Http 'http://127.0.0.1:8090/' 120)) {
        throw 'Web no alcanzó estado disponible.'
    }

    # Search is useful but does not block the platform.
    try {
        Invoke-ComposeSafe 'up -d searxng'
    } catch {
        Write-Log "ADVERTENCIA: SearXNG no inició: $($_.Exception.Message)"
    }

    # Try normal sandbox start. If it fails, keep LENVRAK core alive.
    $sandboxOk = $true
    try {
        Invoke-ComposeSafe 'up -d sandbox-certs sandbox-api sandbox-runner-1'
        Start-Sleep -Seconds 5
    } catch {
        $sandboxOk = $false
        Write-Log "ADVERTENCIA: Sandbox n8n no inició. LENVRAK continuará sin sandbox: $($_.Exception.Message)"
    }

    # n8n is essential for workflows. Start normally when possible;
    # otherwise ignore dependency state so incident workflows remain available.
    try {
        if ($sandboxOk) {
            Invoke-ComposeSafe 'up -d n8n'
        } else {
            Invoke-ComposeSafe 'up -d --no-deps n8n'
        }
    } catch {
        Write-Log "ADVERTENCIA: intento normal de n8n falló; reintentando sin dependencias."
        Invoke-ComposeSafe 'up -d --no-deps n8n'
    }
}

function Start-UpdateManager {
    if (Test-Http 'http://127.0.0.1:8765/health' 1) {
        Write-Log 'Update Manager ya está activo.'
        return $true
    }
    $python = Get-PythonPath
    if (-not $python) { return $false }

    $exe = $python
    $args = @()
    if ([IO.Path]::GetFileName($python) -ieq 'py.exe') {
        $args = @('-3', 'tools\update_manager\server.py')
    } else {
        $args = @('tools\update_manager\server.py')
    }
    Write-Log 'Iniciando Update Manager en segundo plano...'
    $sp = @{
        FilePath = $exe
        ArgumentList = $args
        WorkingDirectory = $Root
        WindowStyle = 'Hidden'
        PassThru = $true
        RedirectStandardOutput = $UpdateOut
        RedirectStandardError = $UpdateErr
    }
    $p = Start-Process @sp
    Set-Content -Path (Join-Path $StateDir 'update-manager.pid') -Value $p.Id -Encoding ASCII
    if (-not (Wait-Http 'http://127.0.0.1:8765/health' 20)) {
        Write-Log 'ADVERTENCIA: Update Manager no respondió en 20 s.'
        return $false
    }
    Write-Log 'Update Manager listo.'
    return $true
}


function Start-LaragonDesktopHelper {
    try {
        $tcp=Get-NetTCPConnection -LocalPort 8790 -State Listen -ErrorAction SilentlyContinue
        if($tcp){ Write-Log 'Laragon Desktop Helper ya está activo.'; return $true }
    } catch {}

    $python=Get-PythonPath
    if(-not $python){
        Write-Log 'ADVERTENCIA: Python no disponible para Laragon Desktop Helper.'
        return $false
    }

    Write-Log 'Iniciando Laragon Desktop Helper en la sesión interactiva...'
    if([IO.Path]::GetFileName($python) -ieq 'py.exe'){
        $p=Start-Process -FilePath $python -ArgumentList @('-3','scripts\laragon_helper\laragon_desktop_helper.py') -WorkingDirectory $Root -WindowStyle Hidden -PassThru
    } else {
        $p=Start-Process -FilePath $python -ArgumentList @('scripts\laragon_helper\laragon_desktop_helper.py') -WorkingDirectory $Root -WindowStyle Hidden -PassThru
    }
    Set-Content -Path (Join-Path $StateDir 'laragon-helper.pid') -Value $p.Id -Encoding ASCII
    Start-Sleep -Seconds 1
    try {
        $tcp=Get-NetTCPConnection -LocalPort 8790 -State Listen -ErrorAction SilentlyContinue
        if($tcp){
            Write-Log 'Laragon Desktop Helper online en 127.0.0.1:8790.'
            return $true
        }
    } catch {}
    Write-Log 'ADVERTENCIA: Laragon Desktop Helper no abrió el puerto 8790.'
    return $false
}

function Start-EdgeAgent {
    # Se consulta por la API porque el /health del agente requiere token.
    try {
        $h = Invoke-RestMethod -Uri 'http://127.0.0.1:8000/api/v1/runbooks/agent-health' -TimeoutSec 3
        if ($h.ok -and $h.state -eq 'online') {
            Write-Log 'Edge Agent ya está online.'
            return $true
        }
    } catch {}

    $task = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
    if (-not $task) {
        Show-Error "Falta la instalación inicial del acceso directo/Edge Agent. Ejecute una sola vez scripts\windows\08_INSTALAR_INICIO_PROFESIONAL.bat como Administrador."
        return $false
    }

    Write-Log 'Iniciando Edge Agent elevado y oculto mediante Tarea Programada...'
    Start-ScheduledTask -TaskName $TaskName
    $limit = (Get-Date).AddSeconds(30)
    while ((Get-Date) -lt $limit) {
        Start-Sleep -Seconds 2
        try {
            $h = Invoke-RestMethod -Uri 'http://127.0.0.1:8000/api/v1/runbooks/agent-health' -TimeoutSec 3
            if ($h.ok -and $h.state -eq 'online') { Write-Log 'Edge Agent online.'; return $true }
        } catch {}
    }
    Show-Error 'Edge Agent no quedó online. Revise .lenvrak\edge_agent.log.'
    return $false
}

try {
    Write-Log '=== INICIO LENVRAK ONE ==='
    Set-Location $Root

    if (-not (Ensure-EdgeConfig)) { exit 1 }
    if (-not (Ensure-Docker)) { exit 1 }
    Start-Compose

    if (-not (Wait-Http 'http://127.0.0.1:8000/health' $ServiceTimeoutSeconds)) {
        Show-Error 'La API LENVRAK no respondió en http://127.0.0.1:8000/health.'
        exit 1
    }
    Write-Log 'API lista.'

    if (-not (Wait-Http 'http://127.0.0.1:8090/' $ServiceTimeoutSeconds)) {
        Show-Error 'La interfaz LENVRAK no respondió en el puerto 8090.'
        exit 1
    }
    Write-Log 'Web lista.'

    if (-not (Wait-Http 'http://127.0.0.1:5678/' $ServiceTimeoutSeconds)) {
        Write-Log 'ADVERTENCIA: n8n todavía no responde; continuará iniciando en segundo plano.'
    } else { Write-Log 'n8n listo.' }

    [void](Start-UpdateManager)
    [void](Start-LaragonDesktopHelper)
    $edgeOk = Start-EdgeAgent
    if (-not $edgeOk) {
        # Un segundo intento cubre equipos donde el Programador de tareas tarda
        # unos segundos adicionales tras arrancar Docker/Windows.
        Write-Log 'Reintentando Edge Agent una vez...'
        Start-Sleep -Seconds 3
        $edgeOk = Start-EdgeAgent
    }

    if ($edgeOk) { Write-Log 'Todos los componentes esenciales están activos.' }
    else { Write-Log 'ADVERTENCIA: plataforma disponible, pero Edge Agent continúa offline. Use Estado LENVRAK One para comprobarlo.' }

    Start-Process 'http://127.0.0.1:8090/' | Out-Null
    Write-Log 'Interfaz LENVRAK abierta. === FIN INICIO ==='
} catch {
    Show-Error $_.Exception.Message
    exit 1
}
