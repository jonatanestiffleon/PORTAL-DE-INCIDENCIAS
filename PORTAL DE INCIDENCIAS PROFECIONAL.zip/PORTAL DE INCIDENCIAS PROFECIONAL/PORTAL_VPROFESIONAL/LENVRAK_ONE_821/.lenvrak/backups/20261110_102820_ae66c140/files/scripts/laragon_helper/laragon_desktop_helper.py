from __future__ import annotations
import json
import os
import subprocess
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ENV = ROOT / ".env"
BIND = "127.0.0.1"
PORT = 8790

def env_value(key: str, default: str = "") -> str:
    if ENV.exists():
        for line in ENV.read_text(encoding="utf-8", errors="ignore").splitlines():
            if line.strip().startswith(key + "="):
                return line.split("=", 1)[1].strip()
    return os.environ.get(key, default)

TOKEN = env_value("EDGE_AGENT_TOKEN", "")

def run_ps(script: str, timeout: int = 25) -> tuple[bool, str]:
    p = subprocess.run(
        ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script],
        capture_output=True,
        text=True,
        timeout=timeout,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    out = ((p.stdout or "") + "\n" + (p.stderr or "")).strip()
    return p.returncode == 0, out[-5000:]

def laragon_start_all() -> dict:
    script = r"""
$ErrorActionPreference='SilentlyContinue'
$exe='C:\laragon\laragon.exe'
if(-not (Test-Path $exe)){
  Write-Output 'LARAGON_NOT_FOUND'
  exit 2
}
$p=Get-Process laragon -ErrorAction SilentlyContinue | Select-Object -First 1
if(-not $p){
  Start-Process $exe
  Start-Sleep -Seconds 2
  $p=Get-Process laragon -ErrorAction SilentlyContinue | Select-Object -First 1
}
if(-not $p){
  Write-Output 'LARAGON_NOT_RUNNING'
  exit 3
}
Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes

for($i=0;$i -lt 12;$i++){
  $p.Refresh()
  if($p.MainWindowHandle -ne 0){ break }
  Start-Sleep -Milliseconds 300
}
if($p.MainWindowHandle -eq 0){
  Start-Process $exe
  Start-Sleep -Seconds 2
  $p=Get-Process laragon -ErrorAction SilentlyContinue | Select-Object -First 1
  $p.Refresh()
}
if($p.MainWindowHandle -eq 0){
  Write-Output 'LARAGON_NO_VISIBLE_WINDOW'
  exit 4
}

$root=[System.Windows.Automation.AutomationElement]::FromHandle($p.MainWindowHandle)
$names=@('Start All','Iniciar todo','Iniciar Todo')
foreach($name in $names){
  $cond=New-Object System.Windows.Automation.PropertyCondition(
    [System.Windows.Automation.AutomationElement]::NameProperty,$name)
  $el=$root.FindFirst([System.Windows.Automation.TreeScope]::Descendants,$cond)
  if($el){
    try{
      $pat=$el.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern)
      $pat.Invoke()
      Write-Output ('LARAGON_UI_INVOKED:'+ $name)
      exit 0
    }catch{}
  }
}

Write-Output 'START_ALL_BUTTON_NOT_EXPOSED'
exit 5
"""
    ok, out = run_ps(script)
    return {"ok": ok, "action": "laragon_start_all", "output": out}

class Handler(BaseHTTPRequestHandler):
    server_version = "LENVRAKLaragonHelper/0.14.3"

    def log_message(self, fmt, *args):
        pass

    def _json(self, status: int, data: dict):
        raw = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def _auth(self) -> bool:
        return bool(TOKEN) and self.headers.get("X-LENVRAK-EDGE-TOKEN", "") == TOKEN

    def do_GET(self):
        if self.path != "/health":
            return self._json(404, {"ok": False, "error": "not_found"})
        if not self._auth():
            return self._json(401, {"ok": False, "error": "unauthorized"})
        return self._json(200, {
            "ok": True,
            "service": "lenvrak-laragon-desktop-helper",
            "version": "0.14.3",
            "interactive_session": True,
        })

    def do_POST(self):
        if not self._auth():
            return self._json(401, {"ok": False, "error": "unauthorized"})
        if self.path == "/v1/laragon/start-all":
            result = laragon_start_all()
            return self._json(200 if result["ok"] else 409, result)
        return self._json(404, {"ok": False, "error": "not_found"})

if __name__ == "__main__":
    if os.name != "nt":
        raise SystemExit("Laragon Desktop Helper solo funciona en Windows.")
    if not TOKEN:
        raise SystemExit("EDGE_AGENT_TOKEN no configurado.")
    ThreadingHTTPServer((BIND, PORT), Handler).serve_forever()
