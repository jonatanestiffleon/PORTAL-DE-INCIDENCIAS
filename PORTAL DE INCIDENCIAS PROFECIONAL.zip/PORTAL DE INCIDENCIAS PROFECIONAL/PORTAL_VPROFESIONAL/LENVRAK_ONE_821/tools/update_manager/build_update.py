from __future__ import annotations
import argparse, json, zipfile, time
from pathlib import Path
from common import ROOT,sign_manifest,sha256_file,safe_relpath,managed_path,semver

def main():
    p=argparse.ArgumentParser(description="Crea paquetes firmados para LENVRAK Update Manager.")
    p.add_argument("--version",required=True)
    p.add_argument("--min-version",default="0.9.0")
    p.add_argument("--channel",choices=["stable","beta","dev"],default="stable")
    p.add_argument("--module",required=True,help="Módulo por defecto para los archivos.")
    p.add_argument("--file",action="append",default=[],help="Archivo relativo al proyecto. Repetible.")
    p.add_argument("--delete",action="append",default=[],help="Ruta a eliminar. Repetible.")
    p.add_argument("--notes",default="")
    p.add_argument("--output",required=True)
    p.add_argument("--module-version",default=None)
    args=p.parse_args()

    semver(args.version);semver(args.min_version)
    files=[]
    for raw in args.file:
        rel=safe_relpath(raw)
        if not managed_path(rel): raise SystemExit(f"Ruta no administrada: {rel}")
        src=ROOT/rel
        if not src.is_file(): raise SystemExit(f"No existe: {src}")
        files.append({"path":rel,"sha256":sha256_file(src),"size":src.stat().st_size,"module":args.module})
    deletes=[]
    for raw in args.delete:
        rel=safe_relpath(raw)
        if not managed_path(rel): raise SystemExit(f"Ruta no administrada: {rel}")
        deletes.append({"path":rel,"module":args.module})

    manifest={
      "format":"lenvrak-update-v1",
      "app":"LENVRAK One",
      "version":args.version,
      "min_version":args.min_version,
      "channel":args.channel,
      "created_at":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()),
      "notes":args.notes,
      "module_versions":{args.module:args.module_version or args.version},
      "files":files,
      "delete":deletes
    }
    manifest["signature"]=sign_manifest(manifest)
    out=Path(args.output)
    if not out.is_absolute(): out=ROOT/out
    out.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(out,"w",zipfile.ZIP_DEFLATED) as z:
        z.writestr("manifest.json",json.dumps(manifest,ensure_ascii=False,indent=2))
        for item in files:z.write(ROOT/item["path"],"payload/"+item["path"])
    print(out)
    print("Firma HMAC-SHA256:",manifest["signature"])
    print("Archivos:",len(files),"Eliminaciones:",len(deletes))

if __name__=="__main__":main()
