# LENVRAK Update Manager

Servicio local independiente que actualiza LENVRAK sin dar al navegador permiso directo sobre el proyecto.

## Seguridad
- Escucha únicamente en `127.0.0.1:8765`.
- Las operaciones de escritura requieren un token de sesión.
- Los paquetes `.zip` usan un manifiesto firmado con HMAC-SHA256.
- Verifica SHA-256 y tamaño de cada archivo.
- Rechaza rutas absolutas, `..`, enlaces simbólicos y rutas no administradas.
- Crea backup antes de aplicar.
- Aplica archivos mediante reemplazo atómico.
- Ejecuta smoke tests.
- Si las pruebas fallan, hace rollback automático.
- Guarda historial y backups.
- Soporta actualizaciones por módulo.
- Soporta canales `stable`, `beta` y `dev`.
- Soporta programación de instalación mientras el Update Manager siga ejecutándose.

## Iniciar
```powershell
py tools\update_manager\server.py
```

Copia el TOKEN que aparece en PowerShell y pégalo en LENVRAK > Actualizaciones.

## Formato de paquete
```text
update.zip
├── manifest.json
└── payload/
    └── ...
```

## Crear un paquete
```powershell
py tools\update_manager\build_update.py ^
  --version 0.9.2 ^
  --channel stable ^
  --module docs ^
  --file docs\MI_CAMBIO.md ^
  --notes "Actualiza documentación" ^
  --output updates\LENVRAK_Update_0.9.2.zip
```

La clave de firma local se crea en `.lenvrak/update_signing_key`. No debe subirse a Git.
