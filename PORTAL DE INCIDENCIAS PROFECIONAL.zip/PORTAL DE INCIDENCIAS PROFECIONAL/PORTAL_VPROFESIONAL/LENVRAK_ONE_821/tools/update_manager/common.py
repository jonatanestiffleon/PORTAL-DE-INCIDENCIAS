from __future__ import annotations
from pathlib import Path
import json, hashlib, hmac, secrets, os, re

ROOT=Path(__file__).resolve().parents[2]
STATE=ROOT/".lenvrak"
INBOX=STATE/"inbox"
BACKUPS=STATE/"backups"
HISTORY=STATE/"history.json"
SCHEDULE=STATE/"schedule.json"
KEY_FILE=STATE/"update_signing_key"
VERSION=ROOT/"version.json"

MANAGED_PREFIXES=(
    "apps/","packages/","workflows/","infra/","docs/","scripts/","tests/",
    "tools/update_manager/"
)
MANAGED_ROOT_FILES={
    "README.md","docker-compose.yml",".env.example",".gitignore","version.json"
}
MAX_ZIP_BYTES=50*1024*1024
MAX_UNCOMPRESSED_BYTES=200*1024*1024
MAX_FILE_BYTES=30*1024*1024

def ensure_state():
    for p in (STATE,INBOX,BACKUPS): p.mkdir(parents=True,exist_ok=True)
    if not KEY_FILE.exists():
        demo=ROOT/"tools/update_manager/demo_signing_key"
        key=demo.read_text(encoding="utf-8").strip() if demo.exists() else secrets.token_hex(32)
        KEY_FILE.write_text(key,encoding="utf-8")
        try: os.chmod(KEY_FILE,0o600)
        except Exception: pass
    if not HISTORY.exists(): HISTORY.write_text("[]",encoding="utf-8")
    if not SCHEDULE.exists(): SCHEDULE.write_text("[]",encoding="utf-8")

def signing_key()->bytes:
    ensure_state()
    return KEY_FILE.read_text(encoding="utf-8").strip().encode()

def canonical_manifest(manifest:dict)->bytes:
    x=dict(manifest);x.pop("signature",None)
    return json.dumps(x,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode("utf-8")

def sign_manifest(manifest:dict)->str:
    return hmac.new(signing_key(),canonical_manifest(manifest),hashlib.sha256).hexdigest()

def verify_signature(manifest:dict)->bool:
    sig=str(manifest.get("signature",""))
    return bool(sig) and hmac.compare_digest(sig,sign_manifest(manifest))

def sha256_bytes(data:bytes)->str:
    return hashlib.sha256(data).hexdigest()

def sha256_file(path:Path)->str:
    h=hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda:f.read(1024*1024),b""):h.update(chunk)
    return h.hexdigest()

def safe_relpath(s:str)->str:
    s=s.replace("\\","/").lstrip("./")
    if not s or s.startswith("/") or re.match(r"^[A-Za-z]:",s):
        raise ValueError("Ruta absoluta/no válida")
    parts=[p for p in s.split("/") if p not in ("",".")]
    if any(p==".." for p in parts): raise ValueError("Traversal no permitido")
    return "/".join(parts)

def managed_path(rel:str)->bool:
    rel=safe_relpath(rel)
    return rel in MANAGED_ROOT_FILES or any(rel.startswith(p) for p in MANAGED_PREFIXES)

def semver(v:str):
    m=re.match(r"^(\d+)\.(\d+)\.(\d+)(?:[-+].*)?$",v or "")
    if not m: raise ValueError(f"Versión semántica no válida: {v}")
    return tuple(map(int,m.groups()))

def read_version():
    return json.loads(VERSION.read_text(encoding="utf-8"))

def write_version(data):
    tmp=VERSION.with_suffix(".tmp")
    tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8")
    os.replace(tmp,VERSION)

def read_json(path:Path,default):
    try:return json.loads(path.read_text(encoding="utf-8"))
    except Exception:return default

def write_json(path:Path,obj):
    tmp=path.with_suffix(path.suffix+".tmp")
    tmp.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding="utf-8")
    os.replace(tmp,path)

def add_history(event:dict):
    items=read_json(HISTORY,[])
    items.insert(0,event)
    write_json(HISTORY,items[:250])
