from pathlib import Path
import secrets, shutil
from common import ROOT,STATE,KEY_FILE,ensure_state
ensure_state()
backup=KEY_FILE.with_name("update_signing_key.previous")
if KEY_FILE.exists(): shutil.copy2(KEY_FILE,backup)
KEY_FILE.write_text(secrets.token_hex(32),encoding="utf-8")
print("Nueva clave local creada:",KEY_FILE)
print("Los paquetes firmados con la clave anterior dejarán de ser válidos.")
