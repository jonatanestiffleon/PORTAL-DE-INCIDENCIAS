import json,pathlib,time
P=json.loads(pathlib.Path(__file__).with_name("policy.json").read_text(encoding="utf-8"))
if __name__=="__main__":
    print("LENVRAK Operator · modo seguro:",P["default_mode"])
    print("Control real se activa con UI Automation, allowlist y STOP global.")
    while True: time.sleep(60)
