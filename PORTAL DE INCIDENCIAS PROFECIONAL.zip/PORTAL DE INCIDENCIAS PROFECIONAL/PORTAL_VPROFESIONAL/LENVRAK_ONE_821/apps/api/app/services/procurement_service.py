def total_cost(price,transport,hours,downtime_hour_cost=20):
    return price+transport+(hours*downtime_hour_cost)
def rank_quotes(quotes,downtime_hour_cost=20):
    out=[]
    for q in quotes:
        q=dict(q);q["economic_total"]=total_cost(q["price"],q.get("transport",0),q.get("delivery_hours",0),downtime_hour_cost);out.append(q)
    return sorted(out,key=lambda x:x["economic_total"])
