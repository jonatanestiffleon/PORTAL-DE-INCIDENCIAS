from __future__ import annotations
from typing import Any

def _p(code:str,name:str,risk:str,category:str,action_type:str,
       auto_allowed:bool=False,preauthorized:bool=False,blocked:bool=False,
       implemented:bool=False,requires_agent:bool=True,
       action:str="",verification:str="",limitations:str="")->dict[str,Any]:
    return {
        "code":code,
        "name":name,
        "risk":risk,
        "category":category,
        "action_type":action_type,
        "auto_allowed":bool(auto_allowed),
        "preauthorized":bool(preauthorized),
        "blocked":bool(blocked),
        "implemented":bool(implemented),
        "requires_agent":bool(requires_agent),
        "authorization_text":f"Autorizar política {code}: {name}.",
        "action":action or name,
        "verification":verification or "Verificar que el estado objetivo se haya recuperado antes de cerrar el incidente.",
        "limitations":limitations or "No se permiten cambios fuera del activo, alcance y evidencia del incidente.",
    }

POLICIES: dict[str,dict[str,Any]] = {}

def add(x:dict[str,Any])->None:
    POLICIES[x["code"]]=x

# IMPORTANT: implemented and actively used adapters.
add(_p("PRN-SVC-001","Reiniciar y verificar Print Spooler","VERDE","impresion","restart_windows_service",
       True,True,False,True,True,
       "Reiniciar únicamente el servicio Print Spooler.",
       "Comprobar que Spooler quede Running.",
       "No modifica drivers, colas, impresoras físicas ni red."))
add(_p("DIAG-GENERAL-001","Diagnóstico general seguro","VERDE","diagnostico","collect_system_health",
       True,True,False,True,True,
       "Recopilar telemetría básica del sistema.",
       "Confirmar que la telemetría pudo recopilarse.",
       "Es diagnóstico; por sí solo no constituye una reparación."))
add(_p("TCP-VERIFY-001","Verificar disponibilidad TCP de activo","VERDE","red","tcp_verify",
       True,True,False,False,True))
add(_p("HTTP-VERIFY-001","Verificar endpoint HTTP/HTTPS","VERDE","web","http_verify",
       True,True,False,False,True))
add(_p("PING-VERIFY-001","Verificar conectividad ICMP","VERDE","red","ping_verify",
       True,True,False,False,True))

# Fill GREEN policies to exactly 100.
green_categories = [
    ("OBS","Observabilidad"),("NET","Diagnóstico de red"),("WEB","Salud web"),
    ("LOG","Recolección de logs"),("SYS","Salud del sistema"),("DNS","Diagnóstico DNS"),
    ("DISK","Capacidad de disco"),("PROC","Estado de procesos"),("CERT","Certificados"),
    ("DOCKER","Contenedores"),("DB","Diagnóstico de base de datos"),("N8N","n8n"),
    ("ACCESS","Terminales de asistencia"),("PRINT","Impresión"),("GNS3","GNS3 diagnóstico"),
    ("BACKUP","Verificación de respaldos"),("TIME","Sincronización horaria"),("PORT","Puertos"),
    ("API","API health"),("FILE","Integridad de archivos"),
]
i=1
while len([p for p in POLICIES.values() if p["risk"]=="VERDE"]) < 100:
    pref,label=green_categories[(i-1)%len(green_categories)]
    code=f"SAFE-{pref}-{i:03d}"
    if code not in POLICIES:
        add(_p(code,f"{label}: comprobación segura {i:03d}","VERDE",pref.lower(),"observe",
               True,True,False,False,True,
               f"Ejecutar comprobación de solo lectura para {label.lower()}.",
               "Registrar evidencia sin alterar configuración.",
               "Solo lectura; no reinicia, borra ni modifica configuración."))
    i+=1

# YELLOW: pre-authorized by organization policy; reversible actions only.
add(_p("ATT-CONN-001","Comprobar conectividad de terminal de asistencia","AMARILLO","access","attendance_connectivity",
       False,True,False,True,True,
       "Realizar prueba activa de conectividad contra la IP registrada.",
       "Confirmar respuesta de la terminal.",
       "No cambia IP, firmware ni configuración; si no responde se escala."))
add(_p("MYSQL-LARAGON-001","Recuperar MySQL local administrado por Laragon","AMARILLO","database","recover_mysql_laragon",
       False,True,False,True,True,
       "Reiniciar el mismo proceso mysqld previamente observado por LENVRAK.",
       "Confirmar que el puerto TCP 3306 vuelva a aceptar conexiones.",
       "Solo host local. Usa un perfil de proceso capturado mientras MySQL estaba sano; no modifica datos ni configuración."))
add(_p("GNS3-CTRL-001","Recuperar Controller local de GNS3","AMARILLO","network_lab","recover_gns3_controller",
       False,True,False,True,True,
       "Iniciar el mismo gns3server previamente observado o el ejecutable local conocido.",
       "Confirmar que HTTP 127.0.0.1:3080/v2/version responda.",
       "No modifica proyectos, nodos, enlaces, IOS, VLAN, OSPF, ACL ni topologías."))
add(_p("WIN-SVC-RESTART-001","Reiniciar servicio Windows autorizado","AMARILLO","windows","restart_named_service",
       False,True,False,True,True,
       "Reiniciar únicamente el servicio indicado en evidence.service_name.",
       "Verificar que el servicio quede Running.",
       "Solo nombres de servicio presentes en evidencia generada por un monitor configurado."))

yellow_actions=[
    ("APP","Reinicio de aplicación autorizada"),("DB","Recuperación de motor de base de datos"),
    ("WEB","Reinicio de servidor web"),("NET","Renovación controlada de conectividad"),
    ("DOCKER","Reinicio de contenedor autorizado"),("API","Reinicio de API autorizada"),
    ("N8N","Reinicio de worker n8n"),("ACCESS","Reconexión de terminal"),
    ("PRINT","Recuperación de servicio de impresión"),("GNS3","Recuperación de servicio GNS3"),
    ("CACHE","Limpieza de caché operativa"),("QUEUE","Reinicio de cola"),
    ("AGENT","Reinicio de agente"),("DNS","Recuperación DNS local"),
]
i=1
while len([p for p in POLICIES.values() if p["risk"]=="AMARILLO"]) < 70:
    pref,label=yellow_actions[(i-1)%len(yellow_actions)]
    code=f"AUTH-{pref}-{i:03d}"
    if code not in POLICIES:
        add(_p(code,f"{label} {i:03d}","AMARILLO",pref.lower(),"controlled_remediation",
               False,True,False,False,True,
               f"Ejecutar acción reversible y acotada: {label.lower()}.",
               "Comprobar recuperación del estado objetivo; si no se verifica, escalar.",
               "Preautorizada, pero solo se ejecuta cuando existe adaptador específico y evidencia suficiente."))
    i+=1

# RED: explicit deny. They count toward the 200 governed authorizations but can never auto-run.
red_names=[
    "Eliminar base de datos","DROP/TRUNCATE masivo","Borrar respaldos","Formatear disco",
    "Eliminar particiones","Deshabilitar antivirus/EDR","Deshabilitar firewall completo",
    "Abrir firewall a cualquier origen","Cambiar credenciales administrativas",
    "Restablecer contraseñas sin identidad verificada","Eliminar usuarios masivamente",
    "Modificar ACL de red sin revisión","Cambiar rutas por defecto","Resetear router/switch",
    "Actualizar firmware no supervisado","Borrar configuración de GNS3","Eliminar proyectos GNS3",
    "Eliminar máquinas virtuales","Eliminar volúmenes Docker","Purgar logs de auditoría",
    "Desactivar auditoría","Desactivar cifrado","Exfiltrar secretos","Copiar llaves privadas",
    "Ejecutar binarios no confiables","Modificar BIOS/UEFI","Deshabilitar MFA",
    "Cambiar políticas de dominio","Borrar evidencia forense","Acción destructiva no clasificada",
]
for idx,name in enumerate(red_names,1):
    add(_p(f"DENY-{idx:03d}",name,"ROJO","blocked","deny",
           False,False,True,False,True,
           "Bloquear la operación.",
           "Registrar intento y escalar a aprobación humana especializada.",
           "Nunca se ejecuta automáticamente, incluso si un operador intenta preautorizarla."))

assert len(POLICIES)==200, len(POLICIES)
assert sum(1 for p in POLICIES.values() if p["risk"]=="VERDE")==100
assert sum(1 for p in POLICIES.values() if p["risk"]=="AMARILLO")==70
assert sum(1 for p in POLICIES.values() if p["risk"]=="ROJO")==30

def summary()->dict[str,Any]:
    return {
        "total":len(POLICIES),
        "green":sum(1 for p in POLICIES.values() if p["risk"]=="VERDE"),
        "yellow":sum(1 for p in POLICIES.values() if p["risk"]=="AMARILLO"),
        "red":sum(1 for p in POLICIES.values() if p["risk"]=="ROJO"),
        "preauthorized":sum(1 for p in POLICIES.values() if p.get("preauthorized")),
        "implemented":sum(1 for p in POLICIES.values() if p.get("implemented")),
        "blocked":sum(1 for p in POLICIES.values() if p.get("blocked")),
        "policy":"Verde automático; Amarillo preautorizado solo con adaptador y evidencia; Rojo bloqueado.",
    }
