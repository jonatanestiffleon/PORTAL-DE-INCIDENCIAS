def blueprint(prompt,x,y,notes,mode):
    X=x or "X";Y=y or "Y"
    return {"mode":mode,"understood":{"prompt":prompt,"X":X,"Y":Y,"notes":notes},
    "devices":["R1","R2","R3","R4","R5","R6","SW1","SW2","SW3","SW4","SW5","PC1..PC10","SRV1"],
    "links":[{"a":"R1 G0/0","b":"R2 G0/0","network":f"10.{X}.12.0/30"},{"a":"R2 G0/1","b":"R3 G0/0","network":f"10.{X}.23.0/30"}],
    "services":["OSPF","DHCP","DNS","NAT","ACL"],"tests":["show ip interface brief","show ip route","show ip ospf neighbor","ping end-to-end"]}
