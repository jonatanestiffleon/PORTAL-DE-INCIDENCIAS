def evaluate(data):
    downtime=data.downtime_hours*data.downtime_hour_cost
    current=data.repair_cost+downtime
    ratio=(current/data.replacement_value*100) if data.replacement_value else 0
    avoided=max(0,(data.failures*0.6*80)-data.platform_cost)
    if ratio>=70 or data.failures>=15: rec="evaluar_reemplazo_prioritario"
    elif ratio>=40 or data.failures>=8: rec="cotizar_reparacion_y_reemplazo"
    else: rec="continuar_con_mantenimiento"
    return {"downtime_cost":downtime,"period_cost":current,"replacement_ratio_pct":round(ratio,2),"estimated_automation_savings":avoided,"recommendation":rec}
