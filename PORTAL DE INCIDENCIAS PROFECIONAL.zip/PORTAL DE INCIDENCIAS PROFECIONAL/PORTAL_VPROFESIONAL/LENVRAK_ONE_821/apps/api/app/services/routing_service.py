def route_incident(severity,category,support_model="it_internal"):
    if support_model=="no_technician": return ["LENVRAK automation","Dueño/Gerente"]
    if support_model=="external": return ["LENVRAK automation","Proveedor externo","Administración si requiere compra"]
    if severity=="critica": return ["LENVRAK automation","Técnico/Analista","Jefe TI","Gerencia"]
    return ["LENVRAK automation","Técnico responsable","Jefe TI si vence SLA"]
