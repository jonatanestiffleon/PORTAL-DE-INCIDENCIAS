from __future__ import annotations

import asyncio
from html import escape
from typing import Any

import httpx
from sqlalchemy import select

from ..db import SessionLocal
from ..models import DirectoryContact, Incident, NotificationRecipient
from ..settings import settings

RANK={"baja":1,"media":2,"alta":3,"critica":4}

def _event_label(event:str)->str:
    return {"created":"INCIDENTE DETECTADO","approval_required":"APROBACIÓN REQUERIDA",
            "escalated":"INCIDENTE ESCALADO","resolved":"INCIDENTE RESUELTO"}.get(event,"ACTUALIZACIÓN DE INCIDENTE")

def _role_allowed(role:str,event:str,severity:str)->bool:
    rank=RANK.get(severity,2)
    if role in {"tecnico","tecnico_planta","jefe_ti"}: return True
    if role in {"gerente_area","gerente_general"}: return event in {"approval_required","escalated"} or rank>=3
    if role=="dueno": return event in {"approval_required","escalated"} or rank>=4
    return False

def _matches_scope(c:DirectoryContact,incident:Incident)->bool:
    site=(c.site or "").strip().lower()
    area=(c.area or "").strip().lower()
    incident_site=(incident.site or "").strip().lower()
    owner=(incident.owner or "").strip().lower()
    title=(incident.title or "").lower()
    if site and site not in {"todas","todos","general"} and site!=incident_site: return False
    if area and area not in {"todas","todos","general"} and area not in owner and area not in title: return False
    return True

def _directory_recipients(incident:Incident,event:str)->list[dict[str,str]]:
    db=SessionLocal()
    try:
        contacts=list(db.scalars(select(DirectoryContact).where(
            DirectoryContact.active==True,DirectoryContact.auto_alerts==True
        )).all())
        result=[];seen=set()

        # 1) Normal role + scope routing.
        for c in contacts:
            email=(c.email or "").strip().lower()
            if not email or "@" not in email: continue
            if not _role_allowed(c.role,event,incident.severity or "media"): continue
            if not _matches_scope(c,incident): continue
            result.append({"id":c.id,"role":c.role,"name":c.name,"email":email});seen.add(email)

        # 2) For HIGH/CRITICAL, never silently lose the alert because site/area was configured too narrowly.
        if not result and RANK.get(incident.severity or "media",2)>=3:
            for c in contacts:
                email=(c.email or "").strip().lower()
                if not email or "@" not in email or email in seen: continue
                if _role_allowed(c.role,event,incident.severity or "media"):
                    result.append({"id":c.id,"role":c.role,"name":c.name,"email":email});seen.add(email)

        # 3) Legacy recipients.
        if not result:
            legacy=list(db.scalars(select(NotificationRecipient).where(NotificationRecipient.enabled==True)).all())
            mapping={"tecnico":"tecnico","gerente":"gerente_general","dueno":"dueno"}
            for c in legacy:
                email=(c.email or "").strip().lower()
                role=mapping.get(c.role,c.role)
                if email and "@" in email and _role_allowed(role,event,incident.severity or "media") and email not in seen:
                    result.append({"id":c.id,"role":role,"name":c.name or role,"email":email});seen.add(email)
        return result
    finally:
        db.close()

def build_alert_payload(incident:Incident,event:str="created",detail:str="")->dict[str,Any]:
    label=_event_label(event);severity=(incident.severity or "media").upper()
    recipients=_directory_recipients(incident,event)
    subject=f"LENVRAK · {label} · {severity} · {incident.code}"
    state_help={"created":"LENVRAK ya inició diagnóstico/remediación automática según política.",
                "approval_required":"Se requiere decisión humana. Ingrese a LENVRAK → Autorizaciones.",
                "escalated":"La remediación no pudo verificarse o está bloqueada. Requiere atención técnica.",
                "resolved":"La remediación fue ejecutada y verificada por LENVRAK."}.get(event,"Revise el incidente.")
    html=f"""<!doctype html><html><body style="margin:0;background:#eef3f6;font-family:Arial,sans-serif;color:#13222d">
<div style="max-width:720px;margin:24px auto;background:#fff;border-radius:16px;overflow:hidden;border:1px solid #d8e3e8">
<div style="background:#07131d;color:#fff;padding:24px 28px"><div style="font-size:12px;letter-spacing:2px;color:#40d6da;font-weight:700">LENVRAK ONE · INCIDENT ALERT</div><h1>{escape(label)}</h1></div>
<div style="padding:26px 28px"><p><b>{escape(incident.code)} · {escape(incident.title)}</b></p>
<p>Activo: {escape(incident.asset or "N/A")}<br>Severidad: {escape(severity)}<br>Origen: {escape(incident.origin or "")}<br>Estado: {escape(incident.status or "")}</p>
<div style="padding:16px;border-left:4px solid #29c8cb;background:#f4fbfb">{escape(detail or incident.diagnosis or incident.description or "")}</div>
<p><b>{escape(state_help)}</b></p></div></div></body></html>"""
    return {"code":incident.code,"event":event,"severity":incident.severity,"subject":subject,"html":html,
            "text":f"{label} · {incident.code} · {incident.title} · {incident.status}",
            "recipients":recipients,"recipients_csv":",".join(x["email"] for x in recipients)}

async def dispatch_incident_alert(incident:Incident,event:str="created",detail:str="")->dict[str,Any]:
    if not settings.incident_alerts_enabled:
        return {"ok":True,"state":"disabled","recipients":[]}
    payload=build_alert_payload(incident,event,detail)
    if not payload["recipients"]:
        return {"ok":False,"state":"no_recipients","recipients":[],"hint":"Configure al menos un contacto activo con Alertas automáticas."}
    url=settings.n8n_base_url.rstrip("/")+settings.incident_alert_webhook_path
    last_error=""
    for attempt in range(1,4):
        try:
            async with httpx.AsyncClient(timeout=8.0) as client:
                response=await client.post(url,json=payload)
                response.raise_for_status()
            return {"ok":True,"state":"sent_to_n8n","attempt":attempt,
                    "recipients":payload["recipients"],"recipients_csv":payload["recipients_csv"]}
        except Exception as exc:
            last_error=f"{type(exc).__name__}: {exc}"
            if attempt<3: await asyncio.sleep(0.6*attempt)
    return {"ok":False,"state":"workflow_unavailable","error":last_error,
            "recipients":payload["recipients"],"recipients_csv":payload["recipients_csv"],
            "hint":"Verifique que 'LENVRAK - Alertas internas dinámicas' esté Published y que Gmail tenga credencial."}
