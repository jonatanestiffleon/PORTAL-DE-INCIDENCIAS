from ..settings import settings

async def diagnose(incident:dict)->dict:
    asset=str(incident.get("asset",""))
    title=str(incident.get("title",""))
    description=str(incident.get("description",""))
    evidence=incident.get("evidence") or {}
    text=f"{asset} {title} {description} {evidence}".lower()
    host=str(evidence.get("host") or "").lower()
    port=int(evidence.get("port") or 0)

    if asset.startswith("IMP") or "spooler" in text or "impres" in text:
        base={
            "diagnosis":"Falla del servicio de impresión detectada. LENVRAK puede reiniciar únicamente Print Spooler y verificar su estado.",
            "confidence":0.92,"runbook":"PRN-SVC-001","risk":"VERDE",
        }
    elif ("mysql" in text or port==3306) and host in {"127.0.0.1","localhost","::1",""}:
        base={
            "diagnosis":"MySQL local no responde en TCP 3306. Se intentará recuperar el mismo proceso mysqld previamente observado en estado sano y después se verificará el puerto.",
            "confidence":0.94,"runbook":"MYSQL-LARAGON-001","risk":"AMARILLO",
            "recommendation":"Si no existe perfil de recuperación o el puerto no vuelve, escalar sin modificar datos.",
        }
    elif "gns3" in text or port==3080:
        base={
            "diagnosis":"El Controller local de GNS3 no responde. Se intentará iniciar el mismo gns3server previamente observado y se verificará /v2/version.",
            "confidence":0.94,"runbook":"GNS3-CTRL-001","risk":"AMARILLO",
            "recommendation":"No modificar topologías, nodos ni configuraciones de red.",
        }
    elif asset.startswith("HUELLA") or "terminal" in text or "biometr" in text:
        base={
            "diagnosis":"Posible pérdida de comunicación, alimentación o sincronización de la terminal.",
            "confidence":0.78,"runbook":"ATT-CONN-001","risk":"AMARILLO",
        }
    elif evidence.get("service_name"):
        base={
            "diagnosis":"Servicio Windows monitoreado fuera de estado. Puede reiniciarse únicamente el servicio registrado y verificar Running.",
            "confidence":0.82,"runbook":"WIN-SVC-RESTART-001","risk":"AMARILLO",
        }
    else:
        base={
            "diagnosis":"Falla real detectada por monitoreo. Se recopilará diagnóstico seguro; si no existe adaptador de remediación específico se escalará.",
            "confidence":0.64,"runbook":"DIAG-GENERAL-001","risk":"VERDE",
        }

    if not settings.openai_api_key:
        return {**base,"provider":"heuristic-policy-engine","note":"Diagnóstico determinista por políticas LENVRAK."}

    try:
        from openai import AsyncOpenAI
        client=AsyncOpenAI(api_key=settings.openai_api_key)
        prompt=f"""Eres Resolve AI de LENVRAK. Analiza defensivamente el incidente.
El runbook seleccionado por política es {base['runbook']}; no lo reemplaces por comandos libres.
No propongas acciones destructivas. Nunca marques resuelto sin verificación.
Incidente: {incident}"""
        r=await client.responses.create(model=settings.openai_model,input=prompt)
        return {**base,"provider":"openai+policy","ai_text":r.output_text}
    except Exception as exc:
        return {**base,"provider":"heuristic-policy-engine","note":type(exc).__name__}
