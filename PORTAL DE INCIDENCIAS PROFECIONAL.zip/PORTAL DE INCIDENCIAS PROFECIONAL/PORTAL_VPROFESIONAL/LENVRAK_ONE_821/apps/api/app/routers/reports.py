from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import select
from collections import Counter, defaultdict
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
from html import escape

from ..db import get_db
from ..models import Incident, Quote, DirectoryContact, NotificationRecipient

router = APIRouter(prefix="/api/v1/reports", tags=["reports"])

LIMA = ZoneInfo("America/Lima")
DEFAULT_TECH_VISIT_COST = 80.0
DEFAULT_DOWNTIME_HOUR_COST = 20.0

OPEN_STATUSES = {
    "detectado",
    "diagnosticando",
    "solucion_propuesta",
    "esperando_aprobacion",
    "remediando",
    "verificando",
    "escalado",
}
AUTOMATION_ORIGINS = {
    "LENVRAK Edge",
    "LENVRAK Access",
    "Network Lab",
    "Operator",
    "API externa",
}

def money(value: float) -> str:
    return f"S/ {value:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")

def fmt_dt(value):
    if not value:
        return "—"
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.astimezone(LIMA).strftime("%d/%m/%Y %I:%M %p")

def local_day_start_utc_naive():
    now_local = datetime.now(LIMA)
    start_local = now_local.replace(hour=0, minute=0, second=0, microsecond=0)
    return start_local.astimezone(timezone.utc).replace(tzinfo=None), now_local

def economic_total(q: Quote) -> float:
    return float(q.price or 0) + float(q.transport or 0) + float(q.delivery_hours or 0) * DEFAULT_DOWNTIME_HOUR_COST

def collect_metrics(db: Session):
    incidents = list(db.scalars(select(Incident).order_by(Incident.created_at.desc())).all())
    quotes = list(db.scalars(select(Quote).order_by(Quote.id.desc())).all())

    start_utc, now_local = local_day_start_utc_naive()
    today = [i for i in incidents if i.created_at and i.created_at >= start_utc]
    open_incidents = [i for i in incidents if i.status in OPEN_STATUSES or i.status != "resuelto"]
    resolved = [i for i in incidents if i.status == "resuelto"]
    resolved_today = [i for i in resolved if i.resolved_at and i.resolved_at >= start_utc]
    critical_open = [i for i in open_incidents if i.severity == "critica"]
    escalated = [i for i in incidents if i.status == "escalado"]

    automated_resolved_today = [
        i for i in resolved_today
        if i.origin in AUTOMATION_ORIGINS
        or "automat" in (i.resolution or "").lower()
        or "runbook" in (i.resolution or "").lower()
    ]

    severity = Counter(i.severity for i in incidents)
    status = Counter(i.status for i in incidents)
    assets = Counter(i.asset for i in incidents if i.asset and i.asset != "N/A")
    recurrent = assets.most_common(5)

    quote_by_incident = defaultdict(list)
    for q in quotes:
        quote_by_incident[q.incident_code].append(q)

    best_quotes = []
    for incident_code, items in quote_by_incident.items():
        best = min(items, key=economic_total)
        best_quotes.append({
            "incident_code": incident_code,
            "vendor": best.vendor,
            "city": best.city,
            "option": best.option,
            "economic_total": economic_total(best),
            "warranty_days": best.warranty_days,
            "delivery_hours": best.delivery_hours,
        })

    estimated_savings = len(automated_resolved_today) * DEFAULT_TECH_VISIT_COST
    quoted_total = sum(x["economic_total"] for x in best_quotes)

    recommendations = []
    if critical_open:
        recommendations.append(
            f"Atender inmediatamente {len(critical_open)} incidente(s) crítico(s) abierto(s)."
        )
    if recurrent and recurrent[0][1] >= 3:
        recommendations.append(
            f"El activo {recurrent[0][0]} registra {recurrent[0][1]} incidentes; "
            "conviene hacer análisis de causa raíz y comparar reparación frente a reemplazo."
        )
    if best_quotes:
        recommendations.append(
            f"Hay {len(best_quotes)} incidente(s) con alternativas cotizadas. "
            "Comparar costo total, tiempo de entrega y garantía antes de aprobar."
        )
    if len(open_incidents) >= 5:
        recommendations.append(
            f"Existen {len(open_incidents)} incidentes pendientes; revisar carga del equipo y SLA."
        )
    if not recommendations:
        recommendations.append(
            "No se detectan alertas ejecutivas extraordinarias. Mantener monitoreo y revisión preventiva."
        )

    recent = incidents[:7]

    return {
        "generated_at": now_local.strftime("%d/%m/%Y %I:%M %p"),
        "total": len(incidents),
        "today": len(today),
        "open": len(open_incidents),
        "critical_open": len(critical_open),
        "resolved": len(resolved),
        "resolved_today": len(resolved_today),
        "automated_resolved_today": len(automated_resolved_today),
        "escalated": len(escalated),
        "estimated_savings": estimated_savings,
        "quotes_count": len(quotes),
        "quoted_best_total": quoted_total,
        "severity": dict(severity),
        "status": dict(status),
        "recurrent_assets": recurrent,
        "best_quotes": best_quotes,
        "recommendations": recommendations,
        "recent": recent,
    }

def kpi_card(label, value, note, color):
    return f"""
    <td width="25%" style="padding:6px;vertical-align:top;">
      <div style="background:#0f2230;border:1px solid #1e4051;border-radius:12px;padding:16px;min-height:92px;">
        <div style="font-size:11px;color:#89a7b7;text-transform:uppercase;letter-spacing:.6px;">{escape(label)}</div>
        <div style="font-size:27px;font-weight:800;color:{color};margin:5px 0;">{escape(str(value))}</div>
        <div style="font-size:11px;color:#6f8c9e;">{escape(note)}</div>
      </div>
    </td>
    """

def incident_rows(items):
    if not items:
        return '<tr><td colspan="5" style="padding:16px;color:#7895a6;">Sin incidentes registrados.</td></tr>'
    colors = {"critica":"#ff6578","alta":"#ffad4d","media":"#e2c74e","baja":"#47d789"}
    rows = []
    for i in items:
        rows.append(f"""
        <tr>
          <td style="padding:10px;border-bottom:1px solid #e7eef2;font-size:12px;"><b>{escape(i.code)}</b></td>
          <td style="padding:10px;border-bottom:1px solid #e7eef2;font-size:12px;">{escape(i.title)}</td>
          <td style="padding:10px;border-bottom:1px solid #e7eef2;font-size:12px;">{escape(i.asset or "N/A")}</td>
          <td style="padding:10px;border-bottom:1px solid #e7eef2;font-size:12px;color:{colors.get(i.severity,"#445")};font-weight:700;">{escape((i.severity or "—").upper())}</td>
          <td style="padding:10px;border-bottom:1px solid #e7eef2;font-size:12px;">{escape((i.status or "—").replace("_"," "))}</td>
        </tr>
        """)
    return "".join(rows)

def recommendations_html(items):
    return "".join(
        f'<li style="margin:0 0 8px 0;color:#263b46;line-height:1.45;">{escape(x)}</li>'
        for x in items
    )

def build_executive_html(audience: str, m: dict):
    audience = audience or "Gerente"
    title_by_audience = {
        "Técnico": "Resumen técnico de incidentes",
        "Jefe TI": "Resumen operativo de TI",
        "Administración": "Resumen administrativo y económico",
        "Gerente": "Resumen gerencial de operaciones",
        "Dueño": "Resumen ejecutivo general",
        "Proveedor externo": "Resumen técnico para proveedor",
    }
    title = title_by_audience.get(audience, "Resumen operativo LENVRAK")

    economic_note = (
        f"Ahorro técnico estimado hoy: {money(m['estimated_savings'])}. "
        f"Referencia: {money(DEFAULT_TECH_VISIT_COST)} por intervención automatizada. "
        "Debe sustituirse por el costo histórico real de cada organización cuando exista."
    )

    quote_note = (
        money(m["quoted_best_total"])
        if m["best_quotes"]
        else "Sin cotizaciones activas"
    )

    html = f"""<!doctype html>
<html>
<body style="margin:0;padding:0;background:#f3f7f9;font-family:Arial,Helvetica,sans-serif;color:#18313c;">
<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background:#f3f7f9;padding:24px 10px;">
<tr><td align="center">
<table role="presentation" width="760" cellspacing="0" cellpadding="0" style="max-width:760px;width:100%;background:#ffffff;border-radius:18px;overflow:hidden;border:1px solid #dce8ed;">
<tr>
  <td style="background:#071925;padding:25px 28px;">
    <div style="font-size:11px;color:#43d9c8;letter-spacing:1.7px;font-weight:800;">LENVRAK ONE · INTELLIGENT OPERATIONS</div>
    <div style="font-size:25px;color:#ffffff;font-weight:800;margin-top:8px;">{escape(title)}</div>
    <div style="font-size:12px;color:#8eacbb;margin-top:7px;">Generado automáticamente · {escape(m['generated_at'])}</div>
  </td>
</tr>
<tr><td style="padding:20px 20px 4px;">
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0"><tr>
    {kpi_card("Incidentes abiertos", m["open"], "Pendientes de cierre", "#4b9cff")}
    {kpi_card("Críticos abiertos", m["critical_open"], "Atención inmediata", "#ff6578")}
    {kpi_card("Resueltos hoy", m["resolved_today"], "Cierres del día", "#47d789")}
    {kpi_card("Automatizados hoy", m["automated_resolved_today"], "Sin soporte reactivo", "#43d9c8")}
  </tr></table>
</td></tr>

<tr><td style="padding:12px 26px;">
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td width="50%" style="padding:8px 8px 8px 0;vertical-align:top;">
      <div style="background:#ecfaf7;border-left:4px solid #22bfae;border-radius:10px;padding:16px;">
        <div style="font-size:12px;color:#53717d;">Ahorro técnico estimado</div>
        <div style="font-size:25px;font-weight:800;color:#087e72;margin:5px 0;">{money(m["estimated_savings"])}</div>
        <div style="font-size:11px;color:#627d87;line-height:1.45;">{escape(economic_note)}</div>
      </div>
    </td>
    <td width="50%" style="padding:8px 0 8px 8px;vertical-align:top;">
      <div style="background:#fff7e8;border-left:4px solid #f1a33c;border-radius:10px;padding:16px;">
        <div style="font-size:12px;color:#725d3d;">Alternativas cotizadas</div>
        <div style="font-size:25px;font-weight:800;color:#9a6214;margin:5px 0;">{escape(quote_note)}</div>
        <div style="font-size:11px;color:#7c6a4f;">{m["quotes_count"]} cotización(es) registrada(s) en Procurement.</div>
      </div>
    </td>
  </tr>
  </table>
</td></tr>

<tr><td style="padding:10px 26px 2px;">
  <div style="font-size:17px;font-weight:800;color:#0c2b38;margin:8px 0 10px;">Incidentes recientes</div>
  <table width="100%" cellspacing="0" cellpadding="0" style="border-collapse:collapse;border:1px solid #e2ebef;border-radius:10px;overflow:hidden;">
    <tr style="background:#eef5f7;">
      <th align="left" style="padding:9px;font-size:10px;color:#597480;">ID</th>
      <th align="left" style="padding:9px;font-size:10px;color:#597480;">INCIDENTE</th>
      <th align="left" style="padding:9px;font-size:10px;color:#597480;">ACTIVO</th>
      <th align="left" style="padding:9px;font-size:10px;color:#597480;">SEVERIDAD</th>
      <th align="left" style="padding:9px;font-size:10px;color:#597480;">ESTADO</th>
    </tr>
    {incident_rows(m["recent"])}
  </table>
</td></tr>

<tr><td style="padding:18px 26px;">
  <div style="background:#f4f8fa;border-radius:12px;padding:17px;">
    <div style="font-size:16px;font-weight:800;color:#0c2b38;margin-bottom:10px;">Recomendaciones LENVRAK</div>
    <ul style="margin:0;padding-left:20px;">{recommendations_html(m["recommendations"])}</ul>
  </div>
</td></tr>

<tr><td style="padding:0 26px 24px;">
  <div style="font-size:11px;color:#708995;line-height:1.5;">
    Este informe se genera con la información registrada en LENVRAK Sentinel, Resolve, Economics y Procurement.
    Las cifras marcadas como estimadas son referenciales hasta que la organización configure sus costos históricos reales.
  </div>
</td></tr>
<tr><td style="background:#071925;padding:16px 26px;color:#7fa0b0;font-size:10px;">
  LENVRAK One · Detecta · Diagnostica · Resuelve · Verifica · Documenta · Decide
</td></tr>
</table>
</td></tr></table>
</body></html>"""
    return title, html

def build_text(audience: str, m: dict):
    lines = [
        f"LENVRAK One - {audience}",
        f"Generado: {m['generated_at']}",
        "",
        f"Incidentes abiertos: {m['open']}",
        f"Críticos abiertos: {m['critical_open']}",
        f"Resueltos hoy: {m['resolved_today']}",
        f"Resueltos automáticamente hoy: {m['automated_resolved_today']}",
        f"Ahorro técnico estimado: {money(m['estimated_savings'])}",
        "",
        "Recomendaciones:",
    ]
    lines.extend(f"- {x}" for x in m["recommendations"])
    return "\n".join(lines)

@router.post("/preview")
def preview(audience: str = "Gerente", db: Session = Depends(get_db)):
    m = collect_metrics(db)
    title, html = build_executive_html(audience, m)
    subject = f"LENVRAK · {title} · {m['generated_at'].split(' ')[0]}"
    preferred_roles = {"tecnico_planta", "gerente_general", "dueno"}
    contacts = list(db.scalars(select(DirectoryContact).where(
        DirectoryContact.active == True,
        DirectoryContact.report_executive == True
    )).all())
    recipients = []
    for c in contacts:
        email = (c.email or "").strip().lower()
        if c.role in preferred_roles and email and "@" in email and email not in recipients:
            recipients.append(email)
    if not recipients:
        legacy = list(db.scalars(select(NotificationRecipient).where(NotificationRecipient.enabled == True)).all())
        recipients = list(dict.fromkeys((x.email or "").strip().lower() for x in legacy if (x.email or "").strip()))
    return {
        "audience": audience,
        "subject": subject,
        "html": html,
        "text": build_text(audience, m),
        "recipients": recipients,
        "recipients_csv": ",".join(recipients),
        "metrics": {
            "total": m["total"],
            "today": m["today"],
            "open": m["open"],
            "critical_open": m["critical_open"],
            "resolved_today": m["resolved_today"],
            "automated_resolved_today": m["automated_resolved_today"],
            "estimated_savings": m["estimated_savings"],
            "quotes_count": m["quotes_count"],
            "quoted_best_total": m["quoted_best_total"],
        },
        "recommendations": m["recommendations"],
    }

@router.post("/executive")
def executive(audience: str = "Gerente", db: Session = Depends(get_db)):
    return preview(audience=audience, db=db)
