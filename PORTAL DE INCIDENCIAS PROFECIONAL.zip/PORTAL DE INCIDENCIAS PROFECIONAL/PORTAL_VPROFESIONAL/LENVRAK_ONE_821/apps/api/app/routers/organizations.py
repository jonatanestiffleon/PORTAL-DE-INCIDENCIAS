from __future__ import annotations
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import get_db
from ..models import AuditEvent, ClientOrganization, MonitorTarget

router=APIRouter(prefix="/api/v1/organizations",tags=["organizations"])

class OrgInput(BaseModel):
    code:str=Field(min_length=2,max_length=80)
    name:str=Field(min_length=2,max_length=180)
    kind:str="institucion"
    city:str=""
    address:str=""
    active:bool=True

def _s(x:ClientOrganization):
    return {"id":x.id,"code":x.code,"name":x.name,"kind":x.kind,"city":x.city,"address":x.address,"active":x.active}

@router.get("")
def list_orgs(db:Session=Depends(get_db)):
    return [_s(x) for x in db.scalars(select(ClientOrganization).order_by(ClientOrganization.name)).all()]

@router.post("",status_code=201)
def create_org(data:OrgInput,db:Session=Depends(get_db)):
    code=data.code.strip().upper()
    if db.scalar(select(ClientOrganization).where(ClientOrganization.code==code)):
        raise HTTPException(409,"Ya existe una institución con ese código")
    obj=ClientOrganization(code=code,name=data.name.strip(),kind=data.kind.strip(),city=data.city.strip(),address=data.address.strip(),active=data.active)
    db.add(obj);db.add(AuditEvent(actor="organizations",action="organization.created",detail=f"{obj.code} {obj.name}"));db.commit();db.refresh(obj)
    return _s(obj)

@router.put("/{org_id}")
def update_org(org_id:int,data:OrgInput,db:Session=Depends(get_db)):
    obj=db.get(ClientOrganization,org_id)
    if not obj: raise HTTPException(404,"Institución no encontrada")
    obj.code=data.code.strip().upper();obj.name=data.name.strip();obj.kind=data.kind.strip();obj.city=data.city.strip();obj.address=data.address.strip();obj.active=data.active
    db.add(AuditEvent(actor="organizations",action="organization.updated",detail=f"{obj.code} {obj.name}"));db.commit();db.refresh(obj)
    return _s(obj)

@router.delete("/{org_id}")
def delete_org(org_id:int,db:Session=Depends(get_db)):
    obj=db.get(ClientOrganization,org_id)
    if not obj: raise HTTPException(404,"Institución no encontrada")
    in_use=db.scalar(select(MonitorTarget.id).where(MonitorTarget.organization_id==org_id).limit(1))
    if in_use: raise HTTPException(409,"La institución tiene dispositivos/monitores registrados. Muévalos o elimínelos primero.")
    db.delete(obj);db.add(AuditEvent(actor="organizations",action="organization.deleted",detail=obj.code));db.commit()
    return {"ok":True}
