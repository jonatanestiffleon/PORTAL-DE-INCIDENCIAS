from fastapi import APIRouter
from ..schemas import AuthorizationInterpret
router=APIRouter(prefix="/api/v1/authorizations",tags=["authorizations"])
@router.post("/interpret")
def interpret(x:AuthorizationInterpret):
    t=x.text.lower()
    if "impres" in t or "spool" in t:return [{"action":"Reiniciar Print Spooler","risk":"VERDE"},{"action":"Limpiar cola bloqueada","risk":"AMARILLO"},{"action":"Reinstalar driver","risk":"ROJO"}]
    return [{"action":"Recopilar diagnóstico","risk":"VERDE"},{"action":"Reiniciar servicio","risk":"AMARILLO"},{"action":"Modificar configuración","risk":"ROJO"}]
