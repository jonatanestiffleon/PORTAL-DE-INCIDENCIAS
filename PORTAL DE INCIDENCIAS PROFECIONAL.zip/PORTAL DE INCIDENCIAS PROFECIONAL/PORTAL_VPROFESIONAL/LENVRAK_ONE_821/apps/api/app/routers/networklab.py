from fastapi import APIRouter
from ..schemas import NetworkBlueprintRequest
from ..services.network_service import blueprint
router=APIRouter(prefix="/api/v1/networklab",tags=["networklab"])
@router.post("/blueprint")
def make_blueprint(x:NetworkBlueprintRequest): return blueprint(x.prompt,x.x,x.y,x.notes,x.mode)
