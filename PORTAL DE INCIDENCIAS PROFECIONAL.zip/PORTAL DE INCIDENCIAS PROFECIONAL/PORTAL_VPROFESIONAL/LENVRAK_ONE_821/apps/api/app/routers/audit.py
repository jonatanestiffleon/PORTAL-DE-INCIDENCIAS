from fastapi import APIRouter,Depends
from sqlalchemy.orm import Session
from sqlalchemy import select
from ..db import get_db
from ..models import AuditEvent
router=APIRouter(prefix="/api/v1/audit",tags=["audit"])
@router.get("")
def list_audit(db:Session=Depends(get_db)): return db.scalars(select(AuditEvent).order_by(AuditEvent.created_at.desc()).limit(200)).all()
