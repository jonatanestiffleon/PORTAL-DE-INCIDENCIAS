from fastapi import APIRouter
from ..settings import settings
router=APIRouter(prefix="/api/v1/integrations",tags=["integrations"])
@router.get("/status")
def status(): return {"openai":bool(settings.openai_api_key),"n8n":bool(settings.n8n_base_url),"aws_region":settings.aws_region,"aws_ssm":settings.aws_ssm_enabled,"attendance":bool(settings.attendance_api_url),"gns3":settings.gns3_url}
