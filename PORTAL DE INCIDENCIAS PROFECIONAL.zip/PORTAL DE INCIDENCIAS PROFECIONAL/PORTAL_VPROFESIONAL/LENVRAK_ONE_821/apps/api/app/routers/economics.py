from fastapi import APIRouter
from ..schemas import EconomicInput
from ..services.economics_service import evaluate
router=APIRouter(prefix="/api/v1/economics",tags=["economics"])
@router.post("/evaluate")
def economic_evaluate(data:EconomicInput): return evaluate(data)
