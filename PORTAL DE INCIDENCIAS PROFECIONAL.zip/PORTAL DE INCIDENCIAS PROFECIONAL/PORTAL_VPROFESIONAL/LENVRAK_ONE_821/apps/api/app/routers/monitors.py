from __future__ import annotations
from fastapi import APIRouter, Depends, Header, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session
from ..db import get_db
from ..models import AuditEvent, MonitorTarget, ClientOrganization
from ..settings import settings

router=APIRouter(prefix="/api/v1/monitors",tags=["monitors"])
CHECK_TYPES={"ping","tcp","http","windows_service"}
SOURCES={"access","edge"}
SEVERITIES={"baja","media","alta","critica"}

class MonitorInput(BaseModel):
    code:str=Field(min_length=2,max_length=80)
    name:str=Field(min_length=2,max_length=160)
    organization_id:int|None=None
    source:str="edge"
    category:str="general"
    check_type:str="ping"
    host:str=""
    port:int=0
    path:str=""
    service_name:str=""
    severity:str="media"
    site:str="Sede principal"
    area:str=""
    location:str=""
    enabled:bool=True
    auto_orchestrate:bool=True

def _serialize(x:MonitorTarget):
    return {"id":x.id,"code":x.code,"name":x.name,"organization_id":x.organization_id,"source":x.source,"category":x.category,
            "check_type":x.check_type,"host":x.host,"port":x.port,"path":x.path,
            "service_name":x.service_name,"severity":x.severity,"site":x.site,"area":x.area,"location":x.location,
            "enabled":x.enabled,"auto_orchestrate":x.auto_orchestrate}

def _validate(data:MonitorInput):
    if data.source not in SOURCES: raise HTTPException(422,"source inválido")
    if data.check_type not in CHECK_TYPES: raise HTTPException(422,"Tipo de comprobación inválido")
    if data.severity not in SEVERITIES: raise HTTPException(422,"Severidad inválida")
    if data.check_type in {"ping","tcp","http"} and not data.host.strip(): raise HTTPException(422,"Debe indicar IP/host")
    if data.check_type=="tcp" and not (1<=data.port<=65535): raise HTTPException(422,"TCP requiere puerto válido")
    if data.check_type=="windows_service" and not data.service_name.strip(): raise HTTPException(422,"Debe indicar el nombre del servicio Windows")

@router.get("")
def list_targets(source:str|None=Query(default=None),db:Session=Depends(get_db)):
    stmt=select(MonitorTarget).order_by(MonitorTarget.source,MonitorTarget.name)
    if source: stmt=stmt.where(MonitorTarget.source==source)
    return [_serialize(x) for x in db.scalars(stmt).all()]

@router.post("",status_code=201)
def create_target(data:MonitorInput,db:Session=Depends(get_db)):
    _validate(data)
    code=data.code.strip().upper()
    if db.scalar(select(MonitorTarget).where(MonitorTarget.code==code)): raise HTTPException(409,"Ya existe ese código")
    values=data.model_dump()
    values.update({"code":code,"name":data.name.strip(),"host":data.host.strip(),"path":data.path.strip(),"service_name":data.service_name.strip(),"site":data.site.strip(),"area":data.area.strip(),"location":data.location.strip()})
    obj=MonitorTarget(**values)
    db.add(obj);db.add(AuditEvent(actor="monitor",action="monitor.created",detail=f"{obj.code} {obj.check_type}"))
    db.commit();db.refresh(obj);return _serialize(obj)

@router.put("/{target_id}")
def update_target(target_id:int,data:MonitorInput,db:Session=Depends(get_db)):
    _validate(data)
    obj=db.get(MonitorTarget,target_id)
    if not obj: raise HTTPException(404,"Monitor no encontrado")
    values=data.model_dump()
    values.update({"code":data.code.strip().upper(),"name":data.name.strip(),"host":data.host.strip(),"path":data.path.strip(),"service_name":data.service_name.strip(),"site":data.site.strip(),"area":data.area.strip(),"location":data.location.strip()})
    for k,v in values.items(): setattr(obj,k,v)
    db.add(AuditEvent(actor="monitor",action="monitor.updated",detail=f"{obj.code} {obj.check_type}"))
    db.commit();db.refresh(obj);return _serialize(obj)

@router.delete("/{target_id}")
def delete_target(target_id:int,db:Session=Depends(get_db)):
    obj=db.get(MonitorTarget,target_id)
    if not obj: raise HTTPException(404,"Monitor no encontrado")
    db.delete(obj);db.add(AuditEvent(actor="monitor",action="monitor.deleted",detail=obj.code));db.commit()
    return {"ok":True}

@router.get("/agent-targets")
def agent_targets(x_lenvrak_edge_token:str|None=Header(default=None),db:Session=Depends(get_db)):
    if not settings.edge_agent_token or x_lenvrak_edge_token!=settings.edge_agent_token:
        raise HTTPException(401,"Edge Agent unauthorized")
    return [_serialize(x) for x in db.scalars(select(MonitorTarget).where(MonitorTarget.enabled==True)).all()]
