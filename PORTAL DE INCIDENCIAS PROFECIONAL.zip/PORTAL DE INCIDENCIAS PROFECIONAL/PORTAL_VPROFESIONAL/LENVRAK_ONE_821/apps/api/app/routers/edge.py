from __future__ import annotations

from datetime import datetime
from typing import Any

import httpx
from fastapi import APIRouter, Depends, Header, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..db import get_db
from ..models import AuditEvent, Incident
from ..settings import settings
from ..services.notifications import dispatch_incident_alert
from ..services.ai_service import diagnose as ai_diagnose
from ..services.policy_catalog import POLICIES
from ..db import SessionLocal

router = APIRouter(prefix="/api/v1/edge", tags=["edge"])

_EDGE_STATUS: dict[str, Any] = {
    "online": False,
    "monitoring": False,
    "last_seen": None,
    "agent": {},
    "checks": [],
}


class EdgeCheck(BaseModel):
    key: str = Field(min_length=3, max_length=160)
    name: str = Field(min_length=2, max_length=160)
    status: str = Field(min_length=1, max_length=80)
    ok: bool
    asset: str = Field(default="N/A", max_length=120)
    detail: str = Field(default="", max_length=1000)
    checked_at: str | None = None


class EdgeTelemetry(BaseModel):
    agent: dict[str, Any] = {}
    monitoring: dict[str, Any] = {}
    checks: list[EdgeCheck] = []


class EdgeDetection(BaseModel):
    monitor_key: str = Field(min_length=3, max_length=160)
    title: str = Field(min_length=3, max_length=160)
    type: str = Field(default="servicio", max_length=60)
    severity: str = Field(default="media", max_length=20)
    asset: str = Field(default="N/A", max_length=120)
    site: str = Field(default="Sede principal", max_length=120)
    description: str = Field(min_length=20, max_length=2000)
    evidence: dict[str, Any] = {}
    origin: str = Field(default="LENVRAK Edge", max_length=80)
    auto_orchestrate: bool = True


def _authorized(token: str | None) -> bool:
    expected = settings.edge_agent_token
    return bool(expected) and bool(token) and token == expected


def _next_code(db: Session) -> str:
    n = db.scalar(select(func.count()).select_from(Incident)) or 0
    return f"INC-{1001+n:04d}"


@router.get("/status")
def status():
    return _EDGE_STATUS


@router.post("/telemetry")
def telemetry(data: EdgeTelemetry, x_lenvrak_edge_token: str | None = Header(default=None)):
    if not _authorized(x_lenvrak_edge_token):
        raise HTTPException(401, "Edge Agent unauthorized")
    _EDGE_STATUS.update({
        "online": True,
        "monitoring": bool(data.monitoring.get("active", True)),
        "last_seen": datetime.utcnow().isoformat() + "Z",
        "agent": data.agent,
        "monitor": data.monitoring,
        "checks": [x.model_dump() for x in data.checks],
    })
    return {"ok": True}


@router.post("/detections")
async def detection(data: EdgeDetection, x_lenvrak_edge_token: str | None = Header(default=None), db: Session = Depends(get_db)):
    if not _authorized(x_lenvrak_edge_token):
        raise HTTPException(401, "Edge Agent unauthorized")

    # Prevent duplicate incidents while the same fault remains active.
    existing_rows = db.scalars(
        select(Incident).where(Incident.origin.in_(["LENVRAK Edge","LENVRAK Access"]), Incident.status.notin_(["resuelto","escalado"]))
        .order_by(Incident.created_at.desc())
        .limit(100)
    ).all()
    for item in existing_rows:
        evidence = item.evidence or {}
        if evidence.get("monitor_key") == data.monitor_key:
            return {"ok": True, "state": "already_open", "incident_code": item.code, "status": item.status}

    evidence = dict(data.evidence or {})
    evidence.update({
        "monitor_key": data.monitor_key,
        "detected_by": "LENVRAK Edge Monitor",
        "detected_at": datetime.utcnow().isoformat() + "Z",
    })
    obj = Incident(
        code=_next_code(db),
        title=data.title,
        type=data.type,
        severity=data.severity if data.severity in {"baja", "media", "alta", "critica"} else "media",
        status="detectado",
        origin=data.origin,
        asset=data.asset,
        site=data.site,
        owner="Mesa técnica",
        description=data.description,
        evidence=evidence,
    )
    db.add(obj)
    db.add(AuditEvent(actor="edge-monitor", action="incident.detected_automatically", detail=f"{obj.code} {data.monitor_key}"))
    db.commit()
    db.refresh(obj)
    alert = await dispatch_incident_alert(obj, "created")
    db.add(AuditEvent(actor="notify", action="incident.alert", detail=f"{obj.code} {alert.get('state')}"))
    db.commit()

    return await _auto_process_detected_incident(obj, db, source="edge-detection")


async def _auto_process_detected_incident(obj: Incident, db: Session, source: str = "edge") -> dict[str, Any]:
    """Detect -> alert -> diagnose -> execute authorized runbook -> verify -> close/escalate."""
    if obj.status in {"resuelto","esperando_aprobacion","esperando_agente"}:
        return {"ok":True,"state":obj.status,"incident_code":obj.code}

    obj.status="diagnosticando"
    db.commit()
    result=await ai_diagnose({
        "code":obj.code,"title":obj.title,"asset":obj.asset,
        "description":obj.description,"evidence":obj.evidence or {},
    })
    obj.diagnosis=result.get("diagnosis","")
    evidence=dict(obj.evidence or {})
    evidence["resolve_ai"]={
        "confidence":result.get("confidence"),"runbook":result.get("runbook"),
        "risk":result.get("risk"),"provider":result.get("provider"),
        "recommendation":result.get("recommendation",""),
    }
    obj.evidence=evidence
    db.add(AuditEvent(actor="resolve-ai",action="incident.auto_diagnosed",detail=f"{obj.code} {result.get('runbook')}"))
    db.commit()

    runbook=str(result.get("runbook") or "")
    definition=POLICIES.get(runbook)
    if not definition or definition.get("blocked") or not definition.get("implemented"):
        obj.status="escalado"
        obj.resolution="Escalado automáticamente: no existe un adaptador autorizado e implementado para esta falla."
        db.add(AuditEvent(actor="policy-engine",action="incident.auto_escalated_policy",detail=f"{obj.code} {runbook or 'NONE'}"))
        db.commit()
        alert=await dispatch_incident_alert(obj,"escalated",obj.resolution)
        db.add(AuditEvent(actor="notify",action="incident.escalated_alert",detail=f"{obj.code} {alert.get('state')}"))
        db.commit()
        return {"ok":True,"state":"escalated","incident_code":obj.code,"runbook":runbook}

    # Execute through the API's runbook engine; n8n is NOT a dependency for remediation.
    try:
        payload={
            "incident_code":obj.code,
            "runbook":runbook,
            "approved":bool(definition.get("preauthorized")),
            "requested_by":"edge-auto-policy",
        }
        async with httpx.AsyncClient(timeout=30.0) as client:
            r=await client.post("http://127.0.0.1:8000/api/v1/runbooks/execute",json=payload)
            if r.status_code==409:
                obj.status="escalado"
                obj.resolution=f"Escalado: política {runbook} existe pero su adaptador no está disponible."
                db.commit()
                await dispatch_incident_alert(obj,"escalated",obj.resolution)
                return {"ok":False,"state":"escalated","incident_code":obj.code,"runbook":runbook}
            r.raise_for_status()
            execution=r.json()
        state=execution.get("state")
        if state=="approval_required":
            return {"ok":True,"state":"approval_required","incident_code":obj.code,"runbook":runbook}
        if state not in {"executed","resolved"}:
            # execute endpoint already writes correct incident state when agent fails.
            db.refresh(obj)
            if obj.status=="escalado":
                await dispatch_incident_alert(obj,"escalated",obj.resolution or "La acción automática no pudo ejecutarse.")
            return {"ok":False,"state":obj.status,"incident_code":obj.code,"runbook":runbook,"execution":execution}
        if state=="resolved":
            return {"ok":True,"state":"resolved","incident_code":obj.code,"runbook":runbook}
        execution_id=execution.get("execution_id")
        if not execution_id:
            raise RuntimeError("RUNBOOK_EXECUTION_ID_MISSING")
        async with httpx.AsyncClient(timeout=35.0) as client:
            v=await client.post(f"http://127.0.0.1:8000/api/v1/runbooks/{execution_id}/verify")
            v.raise_for_status()
            verified=v.json()
        return {"ok":bool(verified.get("ok")),"state":verified.get("state"),
                "incident_code":obj.code,"runbook":runbook,"verification":verified}
    except Exception as exc:
        db.refresh(obj)
        if obj.status not in {"resuelto","esperando_aprobacion"}:
            obj.status="escalado"
            obj.resolution=f"Escalado automáticamente: error de orquestación {type(exc).__name__}; requiere revisión técnica."
            db.add(AuditEvent(actor="policy-engine",action="incident.auto_orchestration_error",detail=f"{obj.code} {type(exc).__name__}"))
            db.commit()
            await dispatch_incident_alert(obj,"escalated",obj.resolution)
        return {"ok":False,"state":obj.status,"incident_code":obj.code,"warning":type(exc).__name__}


async def recover_open_detected_incidents() -> None:
    """Recover incidents that were detected before this update and were left pending."""
    db = SessionLocal()
    try:
        rows = list(db.scalars(
            select(Incident)
            .where(
                Incident.origin.in_(["LENVRAK Edge","LENVRAK Access"]),
                Incident.status == "detectado",
            )
            .order_by(Incident.created_at.asc())
            .limit(50)
        ).all())
        for obj in rows:
            try:
                await _auto_process_detected_incident(obj, db, source="startup-recovery")
            except Exception as exc:
                db.add(AuditEvent(actor="startup", action="incident.recovery_error", detail=f"{obj.code} {type(exc).__name__}"))
                db.commit()
    finally:
        db.close()


@router.post("/reprocess/{incident_code}")
async def reprocess_incident(incident_code: str, db: Session = Depends(get_db)):
    obj = db.scalar(select(Incident).where(Incident.code == incident_code))
    if not obj:
        raise HTTPException(404, "Incident not found")
    if obj.origin not in {"LENVRAK Edge","LENVRAK Access"}:
        raise HTTPException(409, "Only automatically monitored incidents can be reprocessed here")
    if obj.status in {"resuelto","esperando_aprobacion","esperando_agente"}:
        return {"ok": True, "state": obj.status, "incident_code": obj.code}
    if obj.status == "escalado":
        # Allow a controlled retry only if explicitly requested.
        obj.status = "detectado"
        obj.resolution = ""
        db.commit()
    return await _auto_process_detected_incident(obj, db, source="manual-reprocess")
