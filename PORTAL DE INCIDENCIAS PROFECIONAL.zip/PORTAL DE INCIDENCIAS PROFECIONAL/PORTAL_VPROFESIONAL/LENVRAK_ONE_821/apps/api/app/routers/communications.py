from __future__ import annotations

from html import escape
from typing import Literal

import httpx
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import get_db
from ..models import (
    AuditEvent, DirectoryContact, Incident, NotificationRecipient,
    RunbookExecution, VendorContact
)
from ..settings import settings

router = APIRouter(prefix="/api/v1/communications", tags=["communications"])

ROLES = {
    "tecnico_planta", "tecnico", "jefe_ti", "gerente_area",
    "gerente_general", "dueno", "administrativo"
}
SPECIALTIES = {"general", "impresoras", "biometria", "redes", "servidores", "software", "hardware"}
REPORT_TYPES = {"technical", "manager", "executive", "provider"}


class ContactInput(BaseModel):
    name: str = Field(min_length=2, max_length=160)
    email: str = Field(min_length=5, max_length=240)
    role: str = Field(max_length=60)
    area: str = Field(default="", max_length=120)
    site: str = Field(default="", max_length=120)
    active: bool = True
    auto_alerts: bool = True
    report_technical: bool = True
    report_manager: bool = False
    report_executive: bool = False


class VendorInput(BaseModel):
    name: str = Field(min_length=2, max_length=160)
    email: str = Field(min_length=5, max_length=240)
    city: str = Field(default="", max_length=120)
    specialty: str = Field(default="general", max_length=80)
    phone: str = Field(default="", max_length=80)
    enabled: bool = True


class ProcurementDispatchInput(BaseModel):
    incident_code: str
    specialty: str | None = None


class ManualReportInput(BaseModel):
    report_type: str
    contact_ids: list[int] = []
    extra_emails: list[str] = []
    note: str = ""


def _clean_email(value: str) -> str:
    return (value or "").strip().lower()


def _valid_email(value: str) -> bool:
    value = _clean_email(value)
    return bool(value and "@" in value and "." in value.split("@")[-1])


def _serialize_contact(x: DirectoryContact):
    return {
        "id": x.id, "name": x.name, "email": x.email, "role": x.role,
        "area": x.area, "site": x.site, "active": x.active,
        "auto_alerts": x.auto_alerts,
        "report_technical": x.report_technical,
        "report_manager": x.report_manager,
        "report_executive": x.report_executive,
    }


def _migrate_legacy(db: Session) -> None:
    if db.scalar(select(DirectoryContact.id).limit(1)):
        return
    legacy = list(db.scalars(select(NotificationRecipient)).all())
    mapping = {"tecnico": "tecnico", "gerente": "gerente_general", "dueno": "dueno"}
    for item in legacy:
        if not item.enabled or not _valid_email(item.email):
            continue
        role = mapping.get(item.role, item.role)
        db.add(DirectoryContact(
            name=item.name or role,
            email=_clean_email(item.email),
            role=role,
            active=True,
            auto_alerts=True,
            report_technical=role in {"tecnico", "tecnico_planta", "jefe_ti"},
            report_manager=role in {"gerente_area", "gerente_general"},
            report_executive=role in {"gerente_general", "dueno", "tecnico_planta"},
        ))
    db.commit()




@router.get("/health")
def communications_health(db: Session = Depends(get_db)):
    _migrate_legacy(db)
    contacts = list(db.scalars(select(DirectoryContact)).all())
    vendors = list(db.scalars(select(VendorContact)).all())
    return {"status":"ok","module":"communications","version":"0.11.2","contacts":len(contacts),"vendors":len(vendors)}

@router.get("/directory")
def list_directory(db: Session = Depends(get_db)):
    _migrate_legacy(db)
    rows = list(db.scalars(select(DirectoryContact).order_by(DirectoryContact.name)).all())
    return [_serialize_contact(x) for x in rows]


@router.post("/directory", status_code=201)
def add_contact(data: ContactInput, db: Session = Depends(get_db)):
    if data.role not in ROLES:
        raise HTTPException(422, "Rol no reconocido")
    if not _valid_email(data.email):
        raise HTTPException(422, "Correo inválido")
    obj = DirectoryContact(
        name=data.name.strip(), email=_clean_email(data.email), role=data.role,
        area=data.area.strip(), site=data.site.strip(), active=data.active,
        auto_alerts=data.auto_alerts,
        report_technical=data.report_technical,
        report_manager=data.report_manager,
        report_executive=data.report_executive,
    )
    db.add(obj)
    db.add(AuditEvent(actor="communications", action="contact.created", detail=f"{obj.name} {obj.role}"))
    db.commit(); db.refresh(obj)
    return _serialize_contact(obj)


@router.put("/directory/{contact_id}")
def update_contact(contact_id: int, data: ContactInput, db: Session = Depends(get_db)):
    obj = db.get(DirectoryContact, contact_id)
    if not obj:
        raise HTTPException(404, "Contacto no encontrado")
    if data.role not in ROLES or not _valid_email(data.email):
        raise HTTPException(422, "Rol o correo inválido")
    for key, value in data.model_dump().items():
        if key == "email": value = _clean_email(value)
        if isinstance(value, str): value = value.strip()
        setattr(obj, key, value)
    db.add(AuditEvent(actor="communications", action="contact.updated", detail=f"{obj.name} {obj.role}"))
    db.commit(); db.refresh(obj)
    return _serialize_contact(obj)


@router.delete("/directory/{contact_id}")
def delete_contact(contact_id: int, db: Session = Depends(get_db)):
    obj = db.get(DirectoryContact, contact_id)
    if not obj:
        raise HTTPException(404, "Contacto no encontrado")
    db.delete(obj)
    db.add(AuditEvent(actor="communications", action="contact.deleted", detail=obj.email))
    db.commit()
    return {"ok": True}


@router.get("/vendors")
def list_vendors(db: Session = Depends(get_db)):
    rows = db.scalars(select(VendorContact).order_by(VendorContact.name)).all()
    return [
        {"id":x.id,"name":x.name,"email":x.email,"city":x.city,"specialty":x.specialty,
         "phone":x.phone,"enabled":x.enabled}
        for x in rows
    ]


@router.post("/vendors", status_code=201)
def add_vendor(data: VendorInput, db: Session = Depends(get_db)):
    if not _valid_email(data.email):
        raise HTTPException(422, "Correo de proveedor inválido")
    specialty=(data.specialty or "general").strip().lower()
    if specialty not in SPECIALTIES: specialty="general"
    obj=VendorContact(
        name=data.name.strip(),email=_clean_email(data.email),city=data.city.strip(),
        specialty=specialty,phone=data.phone.strip(),enabled=data.enabled
    )
    db.add(obj)
    db.add(AuditEvent(actor="procurement",action="vendor.created",detail=f"{obj.name} {obj.specialty}"))
    db.commit();db.refresh(obj)
    return {"id":obj.id,"name":obj.name,"email":obj.email,"city":obj.city,
            "specialty":obj.specialty,"phone":obj.phone,"enabled":obj.enabled}


@router.delete("/vendors/{vendor_id}")
def delete_vendor(vendor_id:int,db:Session=Depends(get_db)):
    obj=db.get(VendorContact,vendor_id)
    if not obj: raise HTTPException(404,"Proveedor no encontrado")
    db.delete(obj)
    db.add(AuditEvent(actor="procurement",action="vendor.deleted",detail=obj.name))
    db.commit()
    return {"ok":True}


def _infer_specialty(incident:Incident)->str:
    text=f"{incident.type} {incident.asset} {incident.title}".lower()
    if any(x in text for x in ("imp","printer","impres")): return "impresoras"
    if any(x in text for x in ("huella","biometr","asistencia","qr-")): return "biometria"
    if any(x in text for x in ("vlan","switch","router","red","wifi","ap-")): return "redes"
    if any(x in text for x in ("srv","server","servidor")): return "servidores"
    if any(x in text for x in ("windows","app","software","servicio")): return "software"
    return "general"


def _quote_email(incident:Incident,vendor:VendorContact,specialty:str):
    subject=f"LENVRAK Procurement · Solicitud de cotización · {incident.code}"
    html=f"""<!doctype html><html><body style="font-family:Arial,sans-serif;background:#f3f7f9;padding:22px;color:#17313c">
<div style="max-width:680px;margin:auto;background:white;border:1px solid #dce7ec;border-radius:14px;overflow:hidden">
<div style="background:#071925;color:white;padding:22px"><b style="color:#43d9c8;letter-spacing:1px">LENVRAK PROCUREMENT</b><h2>Solicitud de cotización</h2></div>
<div style="padding:24px"><p>Estimado proveedor <b>{escape(vendor.name)}</b>:</p>
<p>Solicitamos cotización para atender:</p>
<p><b>{escape(incident.code)} · {escape(incident.title)}</b><br>Activo: {escape(incident.asset or "N/A")}<br>Severidad: {escape((incident.severity or "").upper())}<br>Especialidad: {escape(specialty)}</p>
<p>Indicar: diagnóstico/propuesta, precio, transporte, plazo de atención, garantía y disponibilidad.</p>
<p style="font-size:12px;color:#718892">Solicitud generada por LENVRAK One.</p></div></div></body></html>"""
    return subject,html


@router.post("/procurement/dispatch")
async def dispatch_procurement(data:ProcurementDispatchInput,db:Session=Depends(get_db)):
    incident=db.scalar(select(Incident).where(Incident.code==data.incident_code))
    if not incident: raise HTTPException(404,"Incidente no encontrado")
    specialty=(data.specialty or _infer_specialty(incident)).strip().lower()
    rows=list(db.scalars(select(VendorContact).where(VendorContact.enabled==True)).all())
    vendors=[x for x in rows if x.specialty in {specialty,"general"} and _valid_email(x.email)]
    if not vendors:
        return {"ok":False,"state":"no_vendors","incident_code":incident.code,"specialty":specialty,"sent":0}

    webhook=settings.n8n_base_url.rstrip("/")+"/webhook/lenvrak-procurement-provider"
    sent=[];errors=[]
    async with httpx.AsyncClient(timeout=7.0) as client:
        for vendor in vendors:
            subject,html=_quote_email(incident,vendor,specialty)
            payload={"incident_code":incident.code,"vendor_id":vendor.id,"vendor_name":vendor.name,
                     "vendor_email":vendor.email,"specialty":specialty,"subject":subject,"html":html}
            try:
                r=await client.post(webhook,json=payload);r.raise_for_status();sent.append(vendor.email)
            except Exception as exc:
                errors.append({"email":vendor.email,"error":type(exc).__name__})
    db.add(AuditEvent(actor="procurement",action="quote_requests.dispatched",
                      detail=f"{incident.code} specialty={specialty} sent={len(sent)} errors={len(errors)}"))
    db.commit()
    return {"ok":bool(sent),"state":"sent" if sent else "workflow_unavailable",
            "incident_code":incident.code,"specialty":specialty,"sent":len(sent),
            "recipients":sent,"errors":errors}


def _latest_execution(db:Session,code:str):
    return db.scalar(
        select(RunbookExecution)
        .where(RunbookExecution.incident_code==code)
        .order_by(RunbookExecution.id.desc()).limit(1)
    )


def _report_content(incident:Incident,report_type:str,execution:RunbookExecution|None,note:str):
    rt=report_type if report_type in REPORT_TYPES else "technical"
    labels={"technical":"Reporte técnico","manager":"Reporte gerencial",
            "executive":"Reporte ejecutivo","provider":"Informe para proveedor"}
    subject=f"LENVRAK · {labels[rt]} · {incident.code}"
    if rt=="technical":
        sections=[
            ("Incidente",f"{incident.code} · {incident.title}"),
            ("Activo",incident.asset),("Severidad",incident.severity.upper()),
            ("Estado",incident.status.replace("_"," ")),("Origen",incident.origin),
            ("Descripción",incident.description),("Diagnóstico",incident.diagnosis or "No registrado"),
            ("Runbook",execution.runbook if execution else "No registrado"),
            ("Ejecución",execution.status if execution else "No registrada"),
            ("Resolución",incident.resolution or "Pendiente"),
        ]
    elif rt=="manager":
        sections=[
            ("Incidente",f"{incident.code} · {incident.title}"),
            ("Severidad",incident.severity.upper()),("Estado",incident.status.replace("_"," ")),
            ("Activo afectado",incident.asset),("Impacto",incident.description),
            ("Diagnóstico resumido",incident.diagnosis or "En análisis"),
            ("Resultado",incident.resolution or "Pendiente de cierre"),
        ]
    elif rt=="executive":
        sections=[
            ("Situación",incident.title),("Riesgo",incident.severity.upper()),
            ("Estado actual",incident.status.replace("_"," ")),
            ("Activo / área",f"{incident.asset} · {incident.site}"),
            ("Decisión / resultado",incident.resolution or "Requiere seguimiento"),
        ]
    else:
        sections=[
            ("Solicitud",f"{incident.code} · {incident.title}"),
            ("Activo",incident.asset),("Descripción necesaria",incident.description),
            ("Diagnóstico relevante",incident.diagnosis or "Pendiente"),
            ("Requerimiento","Indicar propuesta, precio, plazo, garantía, transporte y disponibilidad."),
        ]
    if note.strip():
        sections.append(("Nota del remitente",note.strip()))

    rows="".join(
        f'<tr><td style="padding:8px 10px;color:#637a87;width:30%">{escape(str(k))}</td>'
        f'<td style="padding:8px 10px"><b>{escape(str(v or "-"))}</b></td></tr>'
        for k,v in sections
    )
    html=f"""<!doctype html><html><body style="margin:0;background:#edf3f6;font-family:Arial,sans-serif;color:#13242e">
<div style="max-width:760px;margin:24px auto;background:#fff;border:1px solid #d6e1e7;border-radius:16px;overflow:hidden">
<div style="background:#071722;color:white;padding:24px 28px"><div style="color:#41d7ca;font-size:12px;letter-spacing:2px;font-weight:700">LENVRAK ONE</div><h1 style="margin:8px 0">{escape(labels[rt])}</h1></div>
<div style="padding:25px 28px"><table style="width:100%;border-collapse:collapse">{rows}</table>
<p style="margin-top:22px;color:#657c88;font-size:12px">Generado desde Sentinel. El envío queda registrado en Auditoría.</p></div></div>
</body></html>"""
    text="\n".join(f"{k}: {v}" for k,v in sections)
    return subject,html,text,labels[rt]


def _selected_recipients(db:Session,ids:list[int],extra:list[str]):
    rows=list(db.scalars(select(DirectoryContact).where(DirectoryContact.id.in_(ids))).all()) if ids else []
    recipients=[];seen=set()
    for x in rows:
        email=_clean_email(x.email)
        if x.active and _valid_email(email) and email not in seen:
            recipients.append({"id":x.id,"name":x.name,"email":email,"role":x.role})
            seen.add(email)
    for value in extra:
        email=_clean_email(value)
        if _valid_email(email) and email not in seen:
            recipients.append({"id":None,"name":"Correo adicional","email":email,"role":"extra"})
            seen.add(email)
    return recipients


@router.post("/incidents/{incident_code}/report/preview")
def preview_incident_report(incident_code:str,data:ManualReportInput,db:Session=Depends(get_db)):
    incident=db.scalar(select(Incident).where(Incident.code==incident_code))
    if not incident: raise HTTPException(404,"Incidente no encontrado")
    execution=_latest_execution(db,incident.code)
    subject,html,text,label=_report_content(incident,data.report_type,execution,data.note)
    recipients=_selected_recipients(db,data.contact_ids,data.extra_emails)
    return {"incident_code":incident.code,"report_type":data.report_type,"label":label,
            "subject":subject,"html":html,"text":text,"recipients":recipients,
            "recipients_csv":",".join(x["email"] for x in recipients)}


@router.post("/incidents/{incident_code}/report/send")
async def send_incident_report(incident_code:str,data:ManualReportInput,db:Session=Depends(get_db)):
    preview=preview_incident_report(incident_code,data,db)
    if not preview["recipients"]:
        raise HTTPException(422,"Seleccione al menos un destinatario")
    payload={**preview,"sender":"Sentinel"}
    url=settings.n8n_base_url.rstrip("/")+"/webhook/lenvrak-manual-incident-report"
    try:
        async with httpx.AsyncClient(timeout=7.0) as client:
            response=await client.post(url,json=payload);response.raise_for_status()
    except Exception as exc:
        raise HTTPException(503,f"No se pudo iniciar el envío por n8n: {type(exc).__name__}")
    db.add(AuditEvent(actor="sentinel",action="incident.report.sent",
                      detail=f"{incident_code} {data.report_type} -> {preview['recipients_csv']}"))
    db.commit()
    return {"ok":True,"state":"sent_to_n8n",**preview}
