import os,time,socket,platform,json
from datetime import datetime
try: import psutil
except ImportError: psutil=None
DEVICE=os.getenv("DEVICE_CODE","EDGE-DEMO-01");SITE=os.getenv("SITE","Sede principal")
def snapshot():
    out={"device":DEVICE,"site":SITE,"time":datetime.utcnow().isoformat()+"Z","hostname":socket.gethostname(),"os":platform.platform()}
    if psutil: out.update({"cpu":psutil.cpu_percent(interval=.2),"memory":psutil.virtual_memory().percent,"disk":psutil.disk_usage("/").percent})
    return out
if __name__=="__main__":
    print("LENVRAK Edge Agent demo")
    while True: print(json.dumps(snapshot(),ensure_ascii=False));time.sleep(30)
