(function(){
"use strict";
const HOST=(location.hostname==="localhost")?"localhost":"127.0.0.1";
const BASE=`http://${HOST}:8765`;
const $=s=>document.querySelector(s);
let updateId="",manifest=null,sessionReady=false;

function log(x){const el=$("#updLog");if(el)el.textContent=(typeof x==="string"?x:JSON.stringify(x,null,2))}
function recoveryToken(){return $("#updToken")?.value.trim()||""}
function setAuthState(text,ok=true){const el=$("#updAuthState");if(el){el.textContent=text;el.className=ok?"status ready":"status"}}
async function raw(path,opts={}){
  const headers={...(opts.headers||{})};
  const t=recoveryToken();if(t)headers["X-Lenvrak-Token"]=t;
  const r=await fetch(BASE+path,{...opts,headers,credentials:"include"});
  const data=await r.json().catch(()=>({error:"Respuesta inválida"}));
  if(!r.ok)throw new Error(data.error||`HTTP ${r.status}`);return data
}
async function ensureSession(){
  try{
    await raw("/session/local",{method:"POST"});sessionReady=true;setAuthState("Sesión local protegida · no requiere token",true);return true
  }catch(e){sessionReady=false;setAuthState("Sesión no vinculada · usa recuperación manual",false);return false}
}
async function pairRecovery(){
  const t=recoveryToken();if(!t)throw new Error("Pega el token de recuperación una sola vez.");
  await raw("/session",{method:"POST"});sessionReady=true;setAuthState("Sesión protegida vinculada",true);$("#updToken").value="";return status()
}
async function req(path,opts={}){
  if(opts.auth!==false&&!sessionReady)await ensureSession();
  try{return await raw(path,opts)}catch(e){
    if(opts.auth!==false&&/401|autorizada|Token/i.test(String(e.message))){sessionReady=false;setAuthState("Sesión vencida · reinicia Update Manager",false)}
    throw e
  }
}
function selectedModules(){return [...document.querySelectorAll('#updModules input[type="checkbox"]:checked')].map(x=>x.value)}
async function status(){
  try{
    const d=await req("/status",{auth:false});
    $("#updVersion").textContent=`v${d.version.version} · ${d.version.channel}`;
    $("#updChannel").value=d.version.channel;
    $("#updBackups").innerHTML=(d.backups||[]).length?d.backups.map(b=>`<div class="backup-row"><code>${b}</code><button class="btn ghost" data-rollback="${b}">Rollback</button></div>`).join(""):'<small>Sin backups.</small>';
    document.querySelectorAll("[data-rollback]").forEach(b=>b.onclick=()=>rollback(b.dataset.rollback));
    log({version:d.version,last_history:(d.history||[]).slice(0,5),schedule:d.schedule||[]});
  }catch(e){log("Update Manager no responde.\n\nEjecuta:\npy tools\\update_manager\\server.py\n\n"+e.message)}
}
async function validate(){
  const f=$("#updFile").files[0];if(!f)throw new Error("Selecciona un ZIP.");
  const buf=await f.arrayBuffer();
  const d=await req("/validate",{method:"POST",headers:{"Content-Type":"application/octet-stream"},body:buf});
  updateId=d.update_id;manifest=d.manifest;
  $("#updModules").innerHTML=(d.modules||[]).map(m=>`<label><input type="checkbox" value="${m}" checked>${m}</label>`).join("");log(d)
}
async function test(){if(!updateId)throw new Error("Valida primero el paquete.");log(await req("/test",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({update_id:updateId})}))}
async function apply(){
  if(!updateId)throw new Error("Valida primero el paquete.");const mods=selectedModules();if(!mods.length)throw new Error("Selecciona al menos un módulo.");
  if(!confirm(`Instalar actualización ${manifest?.version||""} en: ${mods.join(", ")}?`))return;
  const d=await req("/apply",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({update_id:updateId,modules:mods})});
  log(d);
  if(d.deploy?.update_manager_restart_required)alert("Actualización instalada. Reinicia una sola vez la ventana de Update Manager para activar su nuevo motor.");
  else if(d.deploy?.attempted&&!d.deploy?.ok)alert("La actualización se instaló, pero Docker no pudo reconstruirse automáticamente. Revisa Historial / diagnóstico.");
  await status()
}
async function rollback(b){if(!confirm(`¿Restaurar backup ${b}?`))return;const d=await req("/rollback",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({backup_id:b})});log(d);await status()}
async function schedule(){if(!updateId)throw new Error("Valida primero el paquete.");const raw=$("#updScheduleAt").value;if(!raw)throw new Error("Elige fecha y hora.");const at=new Date(raw).toISOString();log(await req("/schedule",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({update_id:updateId,modules:selectedModules(),at})}));await status()}
async function remote(){const d=await req("/remote-check",{auth:false});const box=$("#updRemoteList");if(!d.configured){box.innerHTML=`<small>${d.message}</small>`;log(d);return}box.innerHTML=(d.updates||[]).length?(d.updates||[]).map((u,i)=>`<div class="backup-row"><code>v${u.version} · ${u.notes||u.channel}</code><button class="btn ghost" data-remote-index="${i}">Descargar</button></div>`).join(""):"<small>No hay actualizaciones nuevas en este canal.</small>";document.querySelectorAll("[data-remote-index]").forEach(b=>b.onclick=wrap(()=>downloadRemote(d.updates[Number(b.dataset.remoteIndex)])));log(d)}
async function downloadRemote(u){const d=await req("/remote-download",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({url:u.url,sha256:u.sha256||""})});updateId=d.update_id;manifest=d.manifest;$("#updModules").innerHTML=(d.modules||[]).map(m=>`<label><input type="checkbox" value="${m}" checked>${m}</label>`).join("");log(d)}
async function setChannel(){const channel=$("#updChannel").value;log(await req("/channel",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({channel})}));await status()}
function wrap(fn){return async()=>{try{await fn()}catch(e){log("ERROR: "+e.message)}}}
document.addEventListener("DOMContentLoaded",async()=>{
  $("#updRefresh").onclick=wrap(status);$("#updRemote").onclick=wrap(remote);$("#updSetChannel").onclick=wrap(setChannel);
  $("#updValidate").onclick=wrap(validate);$("#updTest").onclick=wrap(test);$("#updApply").onclick=wrap(apply);$("#updSchedule").onclick=wrap(schedule);
  $("#updPairToken")?.addEventListener("click",wrap(pairRecovery));
  await ensureSession();await status();
});
})();
