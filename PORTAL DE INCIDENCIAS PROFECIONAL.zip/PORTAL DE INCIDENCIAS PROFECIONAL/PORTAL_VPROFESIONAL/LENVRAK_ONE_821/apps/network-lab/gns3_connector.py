import os,httpx
GNS3=os.getenv("GNS3_URL","http://127.0.0.1:3080")
class GNS3Connector:
    def __init__(self,base_url=GNS3): self.base=base_url.rstrip("/")
    def projects(self): return httpx.get(f"{self.base}/v2/projects",timeout=5).json()
    def nodes(self,pid): return httpx.get(f"{self.base}/v2/projects/{pid}/nodes",timeout=5).json()
    def links(self,pid): return httpx.get(f"{self.base}/v2/projects/{pid}/links",timeout=5).json()
    def start_node(self,pid,nid): return httpx.post(f"{self.base}/v2/projects/{pid}/nodes/{nid}/start",timeout=10).json()
