# LENVRAK 0.13.2 · Sandbox opcional

Corrige el caso donde `sandbox-api` unhealthy impedía iniciar toda la plataforma.

Nuevo comportamiento:
1. PostgreSQL -> healthy
2. API -> healthy
3. Web -> disponible
4. SearXNG -> opcional
5. Sandbox -> se intenta, pero si falla NO bloquea LENVRAK
6. n8n -> se inicia incluso sin sandbox
7. Update Manager
8. Edge Agent

El sandbox solo afecta funciones avanzadas del Assistant de n8n.
Sentinel, API, PostgreSQL, n8n workflows, Gmail, Edge y Procurement siguen operativos.
