# LENVRAK 0.10.9 · Comunicaciones por rol y proveedores

## Correos internos
Configure una sola vez en LENVRAK → Integraciones:
- Técnico
- Gerente
- Dueño

Política:
- Técnico: recibe incidentes detectados y cierres.
- Gerente: recibe altas/críticas, aprobaciones y escalados.
- Dueño: recibe críticas, aprobaciones y escalados.
- El Reporte Ejecutivo usa los tres correos configurados.

## Proveedores
En LENVRAK → Procurement registre proveedores con:
empresa, correo, ciudad, especialidad y teléfono.

Al solicitar cotizaciones:
- LENVRAK infiere especialidad desde el incidente o usa la elegida.
- selecciona proveedores activos de esa especialidad + proveedores generales;
- envía una solicitud individual a cada proveedor mediante n8n/Gmail;
- los proveedores no ven los correos de sus competidores.

## n8n
Importar y publicar:
1. `05_internal_alerts_roles_0.10.9.template.json`
2. `03_procurement_providers_0.10.9.template.json`
3. `02_executive_report_roles_0.10.9.template.json`

En cada nodo Gmail seleccione el mismo `Gmail account` ya conectado.
No escriba correos manualmente dentro de n8n: los destinatarios vienen de PostgreSQL.
