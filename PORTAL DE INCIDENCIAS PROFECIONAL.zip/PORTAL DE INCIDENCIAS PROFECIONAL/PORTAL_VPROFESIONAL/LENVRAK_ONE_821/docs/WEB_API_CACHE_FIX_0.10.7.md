# LENVRAK 0.10.7 · Web/API same-origin + cache fix

Corrige:
- Chrome ejecutando un app.js anterior.
- Failed to fetch entre Web 8090 y API 8000.
- Fallback silencioso a incidentes demo INC-018x.

Ahora:
- El navegador usa /api/v1/... en el mismo origen 8090.
- Nginx envía /api/* al contenedor api:8000.
- app.js se carga con ?v=0.10.7.
- Si la API cae, Sentinel no muestra datos demo.
- Conserva la lógica 0.10.6: Detalles, Autorizar y bloqueo de Resolver en escalados.

Después de instalar:
docker compose up -d --build --force-recreate web
