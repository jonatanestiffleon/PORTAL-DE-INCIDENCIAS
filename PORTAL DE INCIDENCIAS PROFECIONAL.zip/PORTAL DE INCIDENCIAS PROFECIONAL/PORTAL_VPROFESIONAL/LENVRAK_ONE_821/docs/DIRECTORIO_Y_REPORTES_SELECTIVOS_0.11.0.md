# LENVRAK 0.11.0 · Directorio empresarial y reportes selectivos

## Directorio
Integraciones permite registrar múltiples personas:
- técnico de planta
- técnico
- jefe TI
- gerente de área
- gerente general
- dueño
- administrativo

Cada persona tiene nombre, correo, área, sede y preferencias de alertas/reportes.

## Alertas automáticas
LENVRAK solo envía a contactos que existen y están habilitados.
No inventa un técnico de planta si la empresa no tiene uno.

## Reporte ejecutivo automático
Se dirige a los contactos habilitados con reporte ejecutivo y rol:
- técnico de planta
- gerente general
- dueño

## Sentinel
Cada incidente tiene **Enviar reporte**.
Permite elegir:
- Técnico
- Gerencial
- Ejecutivo / Dueño
- Proveedor

Luego puede marcar una o varias personas del directorio, agregar correos extra, previsualizar y enviar.
El envío queda registrado en Auditoría.

## Proveedores
Procurement conserva su agenda separada por especialidad y envía solicitudes individuales.

## n8n
Importar y publicar los 4 workflows de esta actualización.
En cada nodo Gmail seleccionar el Gmail account ya conectado.
Los destinatarios vienen desde PostgreSQL, no se escriben manualmente en los nodos.
