# LENVRAK 0.15.0 — Login y sesión persistente

Corrige el comportamiento de la interfaz al refrescar/volver a escribir 127.0.0.1:8090.

## Comportamiento nuevo
- Usuario + contraseña reales contra la API.
- Cookie HttpOnly firmada por HMAC.
- SameSite=Lax.
- La contraseña no se almacena en localStorage.
- Con “Mantener sesión iniciada”: 30 días.
- Sin recordar: 12 horas.
- Refrescar (F5), Enter en la URL o volver a abrir 8090 restaura la sesión.
- Botón “Cerrar sesión” elimina la cookie inmediatamente.

## Credenciales iniciales locales
Usuario: admin
Contraseña: LENVRAK-2026!

Cambiar antes de despliegue real mediante:
LENVRAK_ADMIN_USERNAME
LENVRAK_ADMIN_PASSWORD
LENVRAK_AUTH_SECRET

Esta actualización corrige la experiencia de sesión; la automatización Edge/n8n no depende
de esta sesión web y continúa trabajando en segundo plano.
