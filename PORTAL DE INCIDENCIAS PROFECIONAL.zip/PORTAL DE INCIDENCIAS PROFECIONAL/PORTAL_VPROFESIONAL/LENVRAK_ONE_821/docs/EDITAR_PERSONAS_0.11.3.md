# LENVRAK 0.11.3 · Editar personas

Añade edición completa al Directorio de personas.

Flujo:
1. Clic en **Editar**.
2. El formulario carga nombre, correo, rol, área, sede y preferencias.
3. El botón cambia a **Guardar cambios**.
4. Guardar usa `PUT /api/v1/communications/directory/{id}`.
5. Se actualiza el mismo registro; no crea duplicados.
6. **Cancelar edición** restaura el formulario para registrar una persona nueva.

También conserva Eliminar y todas las preferencias de alertas/reportes.
