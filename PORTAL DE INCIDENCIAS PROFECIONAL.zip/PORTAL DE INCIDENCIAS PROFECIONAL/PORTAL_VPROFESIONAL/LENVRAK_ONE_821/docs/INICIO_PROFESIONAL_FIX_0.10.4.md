# LENVRAK One 0.10.4 · Launcher Fix

Corrección del inicio profesional en Windows PowerShell 5.1.

- Docker Compose ya no interpreta mensajes transitorios `Container ... Starting` como errores.
- `sandbox-certs` se permite como contenedor de inicialización (one-shot).
- El lanzador espera la salud real de API, Web y n8n por HTTP.
- Edge Agent se inicia después de que API esté disponible y se reintenta una vez.
- Si Edge no logra quedar online, LENVRAK Web se abre igualmente y el estado queda registrado para diagnóstico.
- No modifica base de datos, workflows ni configuraciones de negocio.

Los accesos directos existentes apuntan al script actualizado, por lo que no es necesario recrearlos.
