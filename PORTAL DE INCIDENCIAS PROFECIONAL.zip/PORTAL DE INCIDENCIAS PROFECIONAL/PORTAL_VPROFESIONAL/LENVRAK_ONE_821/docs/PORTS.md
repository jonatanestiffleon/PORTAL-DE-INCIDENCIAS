# Puertos reservados de LENVRAK

- Asistencia Castilla: `8080` (reservado; LENVRAK no debe usarlo).
- LENVRAK Web: `8090`.
- LENVRAK API: `8000`.
- n8n: `5678`.
- LENVRAK Update Manager: `8765`.

Los scripts de Windows comprueban si LENVRAK Web o Update Manager ya estan activos antes de iniciar otra instancia.
