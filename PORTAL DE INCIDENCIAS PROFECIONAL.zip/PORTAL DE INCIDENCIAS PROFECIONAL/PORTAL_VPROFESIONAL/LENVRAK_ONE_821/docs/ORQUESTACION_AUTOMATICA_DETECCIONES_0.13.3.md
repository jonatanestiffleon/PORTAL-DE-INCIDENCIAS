# LENVRAK 0.13.3 · Orquestación automática de detecciones

## Nuevo flujo real
Edge detecta una falla
→ crea incidente
→ envía alerta inmediata según el directorio
→ Resolve AI diagnostica automáticamente
→ si existe un runbook seguro conocido: n8n lo ejecuta
→ si n8n no está disponible: escala, no vuelve a detectado
→ si no existe runbook seguro específico: escala automáticamente con evidencia

## MySQL
MySQL/3306:
- detección automática
- alerta automática
- diagnóstico automático
- escalamiento automático porque no hay runbook seguro específico para Laragon/XAMPP/Docker/remoto

No se inicia MySQL arbitrariamente sin saber cómo está desplegado.

## GNS3
GNS3/3080:
- detección automática
- alerta automática
- diagnóstico automático
- escalamiento si no existe runbook específico de recuperación

## Recuperación
Al arrancar la API, los incidentes automáticos que quedaron en `detectado` se reprocesan solos.
También existe `/api/v1/edge/reprocess/{incident_code}` para soporte/control.
