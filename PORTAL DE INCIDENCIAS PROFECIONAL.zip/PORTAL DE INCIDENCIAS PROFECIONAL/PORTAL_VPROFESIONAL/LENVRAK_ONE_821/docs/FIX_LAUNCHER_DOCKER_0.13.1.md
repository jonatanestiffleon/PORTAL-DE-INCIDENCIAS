# LENVRAK 0.13.1 · Fix Launcher Docker

Corrige el falso error de inicio como:

`Container lenvrak_one_821-db-1 Running`

Docker puede escribir mensajes normales de progreso por STDERR. PowerShell 5.1,
con ErrorActionPreference=Stop, podía interpretarlos como una excepción y abortar
el lanzador aunque el contenedor estuviera funcionando.

La corrección ejecuta Docker Compose mediante `cmd.exe` con captura explícita de
STDOUT/STDERR y decide el éxito únicamente por el código real de salida.

El flujo sigue siendo:
PostgreSQL healthy -> API healthy -> Web/n8n -> Update Manager -> Edge Agent.
