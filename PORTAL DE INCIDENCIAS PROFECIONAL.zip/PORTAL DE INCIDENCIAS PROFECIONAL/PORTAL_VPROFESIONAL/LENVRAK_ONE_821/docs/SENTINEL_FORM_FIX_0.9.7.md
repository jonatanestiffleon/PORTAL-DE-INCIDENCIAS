# LENVRAK 0.9.7 · Corrección de registro Sentinel

Corrige el falso error mostrado después de registrar un incidente desde Sentinel.

## Causa
El formulario utilizaba `e.currentTarget.reset()` después de una operación asíncrona (`await`).
En el navegador, `currentTarget` puede quedar en `null` cuando continúa la ejecución, aunque el incidente ya haya sido creado correctamente en la API.

## Corrección
El formulario se guarda en una referencia local antes del `await` y luego se usa `form.reset()`.

## Resultado
- El incidente se guarda en la API/PostgreSQL.
- El formulario se limpia correctamente.
- Sentinel muestra el código real creado.
- Se elimina el mensaje falso `No se pudo guardar en API: Cannot read properties of null (reading 'reset')`.
