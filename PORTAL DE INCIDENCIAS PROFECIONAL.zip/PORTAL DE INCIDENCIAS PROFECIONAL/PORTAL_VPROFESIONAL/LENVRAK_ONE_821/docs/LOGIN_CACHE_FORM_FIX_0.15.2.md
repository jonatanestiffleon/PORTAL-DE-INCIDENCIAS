# LENVRAK 0.15.2 — Login cache/form fix

Corrige dos causas del botón aparentemente inactivo:

1. `index.html` todavía solicitaba `assets/app.js?v=0.13.0`.
   Ahora fuerza `assets/app.js?v=0.15.2`.
2. El acceso ahora usa un `<form>` real:
   - clic en Entrar
   - Enter desde contraseña
   - mensaje visible de estado

Al cargar correctamente debe verse:
`Interfaz cargada. Ingrese sus credenciales.`

Al pulsar Entrar:
`Ingresando...`

Credenciales iniciales:
Usuario: admin
Contraseña: LENVRAK-2026!
