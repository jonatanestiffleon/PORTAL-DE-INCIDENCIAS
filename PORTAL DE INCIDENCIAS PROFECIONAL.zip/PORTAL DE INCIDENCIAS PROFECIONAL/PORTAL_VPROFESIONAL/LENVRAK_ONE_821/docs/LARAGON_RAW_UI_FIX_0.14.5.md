# LENVRAK 0.14.5 — Laragon RAW UI Fix

Corrige `MYSQL_ROW_NOT_FOUND` mediante:
- RawViewWalker de Windows UI Automation;
- búsqueda de MySQL por propiedades RAW;
- selección de la segunda fila de servicios si no hay texto accesible;
- clic relativo a la ventana como último respaldo;
- verificación obligatoria de TCP 3306 antes de cerrar RESUELTO.

También limpia helpers obsoletos, registra stderr/stdout y espera hasta 10 segundos por 8790.
