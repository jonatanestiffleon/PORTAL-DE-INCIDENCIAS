# LENVRAK 0.16.4 — Laragon sin segunda instancia

Corrección principal:
- Si `laragon.exe` ya existe, LENVRAK NO vuelve a ejecutar Laragon.
- Si la ventana está oculta/minimizada, intenta restaurar la instancia existente.
- Si existe el proceso pero no se puede obtener una ventana utilizable, la acción se detiene de forma segura en vez de abrir otra instancia.
- Se cierra únicamente el diálogo modal `Warning/Advertencia` de Laragon cuando bloquea el clic; no se cierra Laragon.
- Mantiene el clic calibrado del interruptor MySQL y verifica TCP 3306.

Estado:
- Laragon Helper se valida por `/health` autenticado con `EDGE_AGENT_TOKEN`.
- Muestra la versión del Helper cuando 6/6 está ONLINE.
- Archivo guardado con BOM UTF-8 para evitar texto mojibake en Windows PowerShell.

No modifica Docker, API, n8n, Sentinel ni datos.
