# LENVRAK 0.14.2 — Recuperación visible mediante Laragon

Objetivo: permitir una demostración práctica visual, no dependiente de PowerShell.

Flujo:
1. El docente observa Laragon.
2. Se detiene MySQL desde Laragon.
3. Edge detecta TCP 3306 caído.
4. LENVRAK diagnostica y selecciona MYSQL-LARAGON-001.
5. Edge abre/trae Laragon y usa Windows UI Automation para invocar `Start All` / `Iniciar todo`.
6. Verifica TCP 3306.
7. Si pasa, el incidente queda RESUELTO.
8. Si la UI de Laragon no expone ese control, queda el perfil mysqld aprendido como respaldo.

Para máxima fiabilidad de la demo, active una vez:
Laragon -> Menu -> Preferences -> General -> Start All automatically.

La integración no modifica bases, usuarios, contraseñas ni my.ini.
