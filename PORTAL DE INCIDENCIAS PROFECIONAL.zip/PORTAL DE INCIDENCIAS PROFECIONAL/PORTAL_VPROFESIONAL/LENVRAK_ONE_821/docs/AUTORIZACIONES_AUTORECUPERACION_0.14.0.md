# LENVRAK One 0.14.0 — 200 autorizaciones + autorrecuperación

## Catálogo gobernado
- 200 políticas en total.
- 100 VERDES: automáticas/seguras.
- 70 AMARILLAS: preautorizadas por política, pero solo se ejecutan cuando existe un adaptador técnico y evidencia suficiente.
- 30 ROJAS: bloqueo absoluto; nunca se ejecutan automáticamente.

## Adaptadores reales incluidos
- PRN-SVC-001 — Print Spooler.
- MYSQL-LARAGON-001 — MySQL local/Laragon con perfil capturado.
- GNS3-CTRL-001 — GNS3 Controller local.
- WIN-SVC-RESTART-001 — servicio Windows monitorizado.
- ATT-CONN-001 — conectividad de terminal.
- DIAG-GENERAL-001 — diagnóstico seguro.

## MySQL / Laragon
LENVRAK aprende el comando exacto de `mysqld.exe` mientras el monitor TCP 3306 está sano.
Cuando MySQL cae, ejecuta ese mismo perfil y verifica TCP 3306 antes de marcar RESUELTO.
No cambia bases, usuarios, contraseñas, archivos de configuración ni datos.

IMPORTANTE: después de instalar 0.14.0, inicie MySQL manualmente una vez y déjelo 10–15 s
para que Edge capture el perfil. Después ya puede realizar la prueba apagándolo desde Laragon.

## GNS3
Mientras 3080 está sano, Edge captura el proceso gns3server.
Ante caída intenta recuperarlo y valida `http://127.0.0.1:3080/v2/version`.
No toca topologías ni configuraciones.

## Notificaciones
- Routing por rol/alcance.
- Fallback para incidentes ALTA/CRÍTICA si un alcance demasiado estricto deja cero destinatarios.
- 3 intentos al webhook n8n.
- Endpoint de prueba:
  POST /api/v1/runbooks/notification-test/{incident_code}

## Ejecución
La remediación ya no depende de n8n. La API llama al motor de runbooks directamente.
n8n se mantiene para Gmail y automatizaciones de comunicación.

## Verificación
Ningún adaptador marca RESUELTO por ejecutar un comando. Solo cierra cuando la verificación
del estado objetivo es positiva.
