# LENVRAK 0.11.5 · Acciones operativas

La columna se renombra a **Acciones** y siempre muestra acciones reales:

- Detectado / diagnosticable → **Resolver** · Detalles · Enviar reporte
- Esperando aprobación → **Autorizar** · Detalles · Enviar reporte
- Procesando / esperando agente → **Ver proceso** · Enviar reporte
- Resuelto → **Ver resolución** · Enviar reporte
- Escalado → **Derivar** · Detalles · Enviar reporte

**Derivar** lleva el incidente escalado a Procurement y lo deja preseleccionado para
gestionar soporte externo/cotizaciones.

Principio:
- Estado = condición actual.
- Acciones = siguiente operación disponible para el usuario.
