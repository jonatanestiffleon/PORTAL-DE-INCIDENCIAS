# LENVRAK 0.16.3 — Laragon Helper singleton + autoheal

Diagnóstico confirmado:
- El lanzador llegó a registrar 8790 ONLINE.
- Después coexistieron dos procesos Python del Helper.
- El puerto 8790 desapareció aunque los procesos siguieron vivos.

Corrección:
1. Mutex de Windows `Local\LENVRAK_LARAGON_HELPER_8790`.
   - Solo puede existir UNA instancia real del Helper.
   - Una segunda instancia se cierra inmediatamente.
2. Antes del arranque se eliminan:
   - python/pythonw antiguos del Helper
   - cmd antiguos del Helper
   - wscript retrasados de Start-Laragon-Helper.vbs
3. El servidor HTTP usa `allow_reuse_address`.
4. Autoheal:
   - si `serve_forever` o el socket falla, el mismo proceso recrea 8790.
5. Log de runtime:
   `.lenvrak\launcher\laragon-helper.runtime.log`
6. Estado LENVRAK muestra las últimas líneas del runtime si el Helper está OFFLINE.

No cambia Docker, API, n8n, Sentinel ni los datos.
