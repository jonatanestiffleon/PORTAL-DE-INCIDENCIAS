# LENVRAK 0.10.2 · Edge Monitor Proactivo

Esta versión convierte Edge de ejecutor reactivo a monitor proactivo demostrable.

## Prueba real
1. Ejecutar Edge Agent 0.10.2 como Administrador.
2. Edge consulta Print Spooler cada 5 segundos.
3. Detener el servicio con `Stop-Service Spooler`.
4. Edge detecta `Stopped` sin intervención del usuario.
5. La API crea un incidente con origen `LENVRAK Edge`, evidencia y hora de detección.
6. La API dispara el webhook publicado de n8n.
7. Resolve AI selecciona PRN-SVC-001.
8. Edge reinicia Print Spooler, verifica `Running` y el incidente termina `resuelto`.

## Protección
Mientras una misma falla siga abierta, la API evita incidentes duplicados por `monitor_key`.
