# LENVRAK 0.15.7 — Inicio unificado de un clic

Objetivo:
No dejar ninguna consola PowerShell abierta durante el uso normal o la exposición.

## Iniciar LENVRAK One
Un solo acceso directo inicia en segundo plano:
1. Docker Desktop si hace falta.
2. PostgreSQL.
3. API 8000.
4. Web 8090.
5. n8n 5678.
6. SearXNG/sandbox como opcionales.
7. Update Manager 8765.
8. Laragon Desktop Helper 8790.
9. Edge Agent 8780.
10. Abre solamente la interfaz web.

## Laragon Helper
Se añade `Laragon-Helper-Background.ps1`.
Reproduce el método manual que fue validado:
`python -u scripts\laragon_helper\laragon_desktop_helper.py`
pero ejecutado oculto en segundo plano.

El lanzador:
- elimina helpers viejos;
- evita duplicados;
- espera hasta 15 s por 8790;
- reintenta una vez si falla;
- guarda logs.

## Detener LENVRAK One
Detiene:
- Edge Agent
- Laragon Helper y wrapper
- Update Manager
- contenedores Docker de LENVRAK
sin borrar datos.

## Estado LENVRAK One
Solo comprueba los seis componentes.
No inicia procesos.

Resultado esperado para exposición:
abrir `Iniciar LENVRAK One` y no mantener ninguna consola abierta.
