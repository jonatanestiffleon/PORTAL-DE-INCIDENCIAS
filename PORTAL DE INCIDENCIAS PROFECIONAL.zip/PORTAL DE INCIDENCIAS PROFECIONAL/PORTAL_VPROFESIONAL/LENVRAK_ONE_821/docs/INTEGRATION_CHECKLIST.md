# Qué necesito de ti para activar producción
**No necesito estas cuentas para que la demo funcione.** Solo se requieren para activar integraciones reales.

## n8n
- Puede correr localmente con Docker.
- Para Gmail/Google: iniciar OAuth dentro de n8n.
- Importar los workflows de `workflows/n8n/`.

## OpenAI
- Una organización/proyecto API y credencial API segura.
- No pegar la clave en el código; usar `.env`/Secrets Manager.

## AWS
- Cuenta AWS.
- Usuario/rol de despliegue con permisos mínimos.
- Región elegida.
- Presupuesto/alertas.

## Cloudflare
- Cuenta Cloudflare.
- Dominio añadido.
- Token con permisos mínimos para DNS/Tunnel/Access según se use.

## Namecheap
- Solo si el dominio está registrado allí.
- Iniciar sesión y apuntar nameservers a Cloudflare cuando corresponda.

## Sistema escolar
- URL o acceso al código/API.
- Token de integración separado.
- Definir eventos: terminal offline, sincronización, fallos, etc.

## GNS3
- GNS3 Server accesible.
- URL típica local configurada en `GNS3_URL`.

## Packet Tracer
- Se implementa por modo de laboratorio, Network Controller/API cuando aplique, o guía/Operator.
