# LENVRAK 0.9.5 · Reporte ejecutivo profesional

Esta actualización convierte el correo de prueba en un reporte empresarial HTML.

## Datos incluidos
- incidentes abiertos;
- incidentes críticos;
- resueltos del día;
- resueltos automáticamente;
- ahorro técnico estimado;
- cotizaciones activas;
- incidentes recientes;
- activos recurrentes;
- recomendaciones automáticas.

## Audiencias
El endpoint acepta:
- Técnico
- Jefe TI
- Administración
- Gerente
- Dueño
- Proveedor externo

Ejemplo:
`POST http://api:8000/api/v1/reports/preview?audience=Gerente`

## Cambios en el workflow n8n ya importado
El Update Manager actualiza la plantilla, pero n8n conserva su copia importada.
En tu workflow existente cambia solo el nodo **Enviar Gmail**:

- **Subject/Tema** → Expression: `{{ $json.subject }}`
- **Email Type / Tipo de correo** → `HTML`
- **Message / Mensaje** → Expression: `{{ $json.html }}`
- Desactiva `Append n8n attribution` si quieres un correo completamente corporativo.

El nodo **Generar resumen** puede quedarse usando:
`http://api:8000/api/v1/reports/preview?audience=Gerente`
