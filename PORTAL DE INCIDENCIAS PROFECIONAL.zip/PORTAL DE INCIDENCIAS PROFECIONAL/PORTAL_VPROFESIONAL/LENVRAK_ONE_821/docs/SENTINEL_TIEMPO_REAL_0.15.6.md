# LENVRAK 0.15.6 — Sentinel en tiempo real (1 segundo)

Objetivo:
La interfaz no debe requerir F5, Enter en la URL ni recargar la página para ver incidentes.

Nuevo comportamiento:
- Polling de la API cada 1 segundo mientras LENVRAK esté visible y la sesión esté activa.
- No recarga la página completa.
- Actualiza automáticamente:
  - Sentinel
  - estado del incidente
  - acciones
  - Dashboard/KPIs
  - Resolve AI
  - incidentes disponibles en Procurement
- Detecta incidentes nuevos y cambios de estado.
- Toast visual:
  - `INC-XXXX: incidente detectado`
  - cambios de estado
  - `INC-XXXX: RESUELTO automáticamente`
- Sentinel muestra indicador `● EN VIVO · 1 s` y hora de última sincronización.
- Se detiene el polling al cerrar sesión.

Demostración esperada:
MySQL ON -> apagar MySQL -> en ~1 s aparece incidente en Sentinel ->
LENVRAK recupera MySQL -> el mismo incidente cambia a RESUELTO sin tocar el navegador.
