# LENVRAK 0.16.1 — Helper estable + Sentinel ordenado

## Laragon Helper
- Se elimina la dependencia de pythonw/tarea programada para el Helper.
- Windows Script Host (`wscript.exe`) ejecuta ocultamente el mismo comando ya validado:
  `python -u scripts\laragon_helper\laragon_desktop_helper.py`
- No queda consola visible.
- Se limpian instancias viejas antes de iniciar.
- El lanzador espera 15 s por 127.0.0.1:8790.
- Detener LENVRAK elimina helper Python/cmd residual.

## Sentinel
Los incidentes se muestran siempre de lo más nuevo a lo más antiguo.
Prioridad de orden:
1. `created_at` descendente.
2. número de incidente descendente como desempate.

Ejemplo:
INC-1040
INC-1039
INC-1038
...
