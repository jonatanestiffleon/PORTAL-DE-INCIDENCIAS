# Académica vs Profesional
La versión académica se mantiene separada y cumple HTML/CSS/JavaScript puro.
Esta carpeta es la versión profesional: puede usar backend, IA, AWS, n8n, Cloudflare, agentes y APIs.
El tema central se conserva: **Portal de Reporte de Incidentes**, implementado como LENVRAK Sentinel.
