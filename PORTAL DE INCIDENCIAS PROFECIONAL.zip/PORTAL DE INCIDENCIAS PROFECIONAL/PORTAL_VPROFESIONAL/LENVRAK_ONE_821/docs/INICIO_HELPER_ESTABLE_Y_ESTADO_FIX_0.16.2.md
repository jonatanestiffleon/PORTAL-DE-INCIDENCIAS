# LENVRAK 0.16.2 — Inicio Helper estable + Estado reparado

Correcciones:
1. Laragon Helper:
   - el lanzador resuelve la ruta EXACTA de python.exe;
   - se la pasa a Start-Laragon-Helper.vbs;
   - el VBS ejecuta `python.exe -u <helper>` oculto, en la carpeta exacta del proyecto;
   - ya no depende de PATH dentro de wscript;
   - evita instancias duplicadas;
   - espera 15 s por 8790.

2. Estado LENVRAK:
   - Status-LENVRAK-One.ps1 fue reescrito desde cero;
   - sin llaves/catch sobrantes;
   - siempre espera ENTER antes de cerrar.

3. Sentinel:
   - conserva orden del más nuevo al más antiguo;
   - conserva actualización en vivo.
