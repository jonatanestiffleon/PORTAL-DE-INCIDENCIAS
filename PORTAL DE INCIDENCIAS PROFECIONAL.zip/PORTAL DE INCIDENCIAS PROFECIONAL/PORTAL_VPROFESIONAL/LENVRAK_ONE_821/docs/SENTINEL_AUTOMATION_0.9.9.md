# LENVRAK 0.9.9 · Sentinel → n8n automático

## Cambios
- El botón de Sentinel ahora inicia el workflow publicado de n8n mediante la API.
- Ya no se requiere PowerShell para resolver un incidente desde Sentinel.
- Sentinel sigue el estado automáticamente hasta `resuelto`, `escalado`, `esperando_aprobacion` o `esperando_agente`.
- Los incidentes ya resueltos quedan protegidos: no pueden volver a `diagnosticando` por error.
- La acción del listado cambia a **Resolver** y muestra **Procesando…** o **Resuelto** según el estado.

## Requisito
El workflow `LENVRAK - Resolución de incidente 0.9.8` debe estar publicado y su webhook de producción debe ser `/webhook/lenvrak-incident`.

## Después de instalar
```powershell
docker compose up -d --build api web
```
Después abra `http://127.0.0.1:8090` y use `Ctrl+F5`.
