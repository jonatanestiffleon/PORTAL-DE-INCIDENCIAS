# LENVRAK 0.11.2 · Guardar persona robusto

Corrige específicamente el registro de personas en Integraciones.

Cambios:
- Reaplica modelos y endpoint `/api/v1/communications/directory`.
- Añade `/api/v1/communications/health`.
- El botón usa un listener delegado robusto.
- Muestra estado persistente:
  - Guardando persona en PostgreSQL…
  - Persona guardada…
  - ERROR al guardar: <detalle>
- Valida nombre, correo y rol antes de enviar.
- No modifica incidentes, runbooks ni datos existentes.

Después de instalar, use Detener LENVRAK One → Iniciar LENVRAK One.
