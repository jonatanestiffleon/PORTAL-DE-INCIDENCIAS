# Seguridad y límites
1. La IA no obtiene una terminal ilimitada.
2. Toda acción ejecutable debe mapear a un runbook conocido.
3. Riesgo VERDE: lectura/diagnóstico/acción segura expresamente permitida.
4. AMARILLO: regla adicional o aprobación.
5. ROJO: aprobación humana obligatoria.
6. Operator mantiene lista de aplicaciones y acciones permitidas.
7. Debe existir botón global STOP.
8. Nunca automatizar contraseñas, UAC, pagos bancarios ni desactivar controles de seguridad.
9. Secretos en Secrets Manager / variables, nunca en Git.
10. Auditoría obligatoria para acciones remotas.
11. Antes de acciones destructivas: backup/rollback cuando sea viable.
12. Systems Manager y otros ejecutores deben usar mínimo privilegio.
