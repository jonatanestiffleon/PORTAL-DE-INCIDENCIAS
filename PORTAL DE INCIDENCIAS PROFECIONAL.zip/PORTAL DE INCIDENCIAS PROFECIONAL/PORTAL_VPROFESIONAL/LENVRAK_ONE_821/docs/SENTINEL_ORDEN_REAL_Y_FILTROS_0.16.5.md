# LENVRAK 0.16.5 — Sentinel: orden real + filtros visibles

Correcciones:
- El Portal de Reporte de Incidentes mantiene orden estricto de más nuevo a más antiguo.
- Se elimina el segundo ordenamiento por severidad que ocultaba incidentes recientes de severidad media/baja debajo de incidentes antiguos de severidad alta.
- Se agrega botón “Limpiar filtros” para quitar búsqueda, severidad y estado de una sola vez.
- Se conserva sincronización en vivo cada 1 segundo.
- No modifica API, Edge, Laragon Helper, n8n, Docker ni datos.

Caso comprobado:
INC-1046 Print Spooler existe y está resuelto en la API; con este cambio debe aparecer arriba por ser el incidente más reciente cuando no hay filtros activos.
