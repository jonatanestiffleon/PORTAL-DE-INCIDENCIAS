# LENVRAK 0.14.3 — Laragon Desktop Helper

Corrige el fallo observado con NC/INC-1018 y el error de `component_reference_cache.dll`.

Laragon usa su propia orquestación y entorno. LENVRAK ya NO intenta iniciar `mysqld.exe`
directamente.

Arquitectura:
Edge Agent -> 127.0.0.1:8790 -> Laragon Desktop Helper -> UI Automation -> Start All
-> Edge verifica TCP 3306 -> RESUELTO.

El helper:
- corre en la sesión interactiva del usuario;
- solo escucha en 127.0.0.1;
- exige EDGE_AGENT_TOKEN;
- solo expone la acción Start All;
- no modifica datos, my.ini, usuarios ni contraseñas.

El lanzador inicia el helper automáticamente y Estado LENVRAK lo muestra como:
Laragon Helper | 8790 | ONLINE/OFFLINE.
