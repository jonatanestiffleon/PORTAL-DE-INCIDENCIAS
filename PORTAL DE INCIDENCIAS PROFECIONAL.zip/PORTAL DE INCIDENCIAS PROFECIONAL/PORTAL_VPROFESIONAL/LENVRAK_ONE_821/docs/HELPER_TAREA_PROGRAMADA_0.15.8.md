# LENVRAK 0.15.8 — Laragon Helper como tarea programada

Problema corregido:
El Helper funcionaba con `python -u` manualmente, pero `Start-Process` oculto no era estable
y podía generar instancias duplicadas o salir antes de abrir 8790.

Solución:
- Nueva tarea programada: `LENVRAK Laragon Helper`.
- LogonType Interactive: corre en la misma sesión del usuario y puede interactuar con Laragon.
- RunLevel Highest.
- Ejecuta directamente Python con `-u scripts\laragon_helper\laragon_desktop_helper.py`.
- MultipleInstances IgnoreNew.
- El lanzador limpia helpers manuales viejos y arranca SOLO la tarea registrada.
- Espera hasta 15 s por 127.0.0.1:8790.
- Detener LENVRAK detiene Edge + Helper + Update Manager + Docker.
- Estado LENVRAK muestra diagnóstico de la tarea si 8790 está OFFLINE.

PASO ÚNICO DESPUÉS DE INSTALAR ESTA ACTUALIZACIÓN:
Ejecutar una vez:
`scripts\windows\08_INSTALAR_INICIO_PROFESIONAL.bat`
y aceptar el aviso UAC.

Después:
Detener LENVRAK One -> Iniciar LENVRAK One -> Estado LENVRAK One.
No debe quedar ningún PowerShell abierto.
