# LENVRAK 0.10.8 · Estabilización final

Esta actualización es acumulativa para los componentes críticos.

## Corrige definitivamente
- Carrera de arranque PostgreSQL/API (`No address associated with hostname`).
- API espera hasta que PostgreSQL esté healthy.
- API tiene reintentos propios de conexión a la base de datos.
- Web espera a que API esté healthy.
- n8n espera a que API esté healthy.
- Sentinel consume la API por proxy same-origin `/api`, sin CORS.
- Sentinel nunca muestra incidentes demo si la API está caída.
- Si API tarda unos segundos, Sentinel reintenta automáticamente.
- Conserva Detalles, Autorizar, Escalado y bloqueo de Resolver.
- Reaplica monitor Edge, runbooks y alertas críticas.
- El acceso directo Iniciar LENVRAK arranca por etapas: DB → API → Web/n8n → Update Manager → Edge.

## Después de instalar
No se requieren comandos.
1. Use `Detener LENVRAK One`.
2. Use `Iniciar LENVRAK One`.
3. Espere a que abra la interfaz.
4. En Sentinel deben aparecer los incidentes reales INC-100x.
