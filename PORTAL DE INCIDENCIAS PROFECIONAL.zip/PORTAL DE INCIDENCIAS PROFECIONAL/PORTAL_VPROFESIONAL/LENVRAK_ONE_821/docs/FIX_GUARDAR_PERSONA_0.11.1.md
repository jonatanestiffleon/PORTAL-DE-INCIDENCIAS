# LENVRAK 0.11.1 · Fix Guardar Persona

Corrige un error de JavaScript en el arranque de la interfaz.

Causa:
- La vista Procurement 0.11.0 ya no contiene el botón antiguo `#addQuote`.
- El script intentaba ejecutar `$("#addQuote").onclick=...`.
- Al ser null, JavaScript se detenía antes de enlazar `#contactAdd`.
- Por eso `Guardar persona` parecía un botón sin función.

Corrección:
- El enlace antiguo se hace opcional/seguro.
- `Guardar persona`, `Guardar proveedor` y `Enviar solicitud a proveedores`
  vuelven a enlazarse normalmente.
- No modifica PostgreSQL, incidentes, n8n ni configuración existente.
