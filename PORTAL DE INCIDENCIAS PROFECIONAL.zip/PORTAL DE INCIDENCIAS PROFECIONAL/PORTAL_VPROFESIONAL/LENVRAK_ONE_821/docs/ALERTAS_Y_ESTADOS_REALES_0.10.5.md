# LENVRAK 0.10.5 · Alertas y estados reales

## Cambios
- Sentinel ya no permite relanzar `Resolver` cuando un incidente está `esperando_aprobacion`.
- En ese estado muestra **Autorizar** y abre el Approval Center.
- Un incidente `escalado` queda bloqueado como escalado; no vuelve a diagnóstico por accidente.
- Alertas inmediatas por n8n/Gmail:
  - incidentes `alta` y `critica`;
  - toda solicitud de aprobación;
  - todo escalamiento;
  - resolución de incidentes de severidad alta/crítica.
- Los incidentes de severidad media/baja permanecen en el Reporte Ejecutivo diario para evitar ruido.
- La alerta no bloquea Sentinel si n8n/Gmail está temporalmente fuera de línea.

## Configuración única de Gmail
Importar `workflows/n8n/05_incident_alerts.template.json` en n8n.
En `Enviar alerta Gmail`:
1. seleccionar el mismo `Gmail account` ya usado por Reporte Ejecutivo;
2. reemplazar `CAMBIAR_POR_SU_CORREO`;
3. publicar el workflow.

## Interpretación correcta de INC-1006
`ATT-CONN-001` verifica conectividad de una terminal real. Si no hay IP válida o la terminal continúa offline,
LENVRAK debe **escalar**, no fingir que está resuelta. Una vez escalado, Sentinel ya no permite volver a lanzar
la misma resolución automáticamente.
