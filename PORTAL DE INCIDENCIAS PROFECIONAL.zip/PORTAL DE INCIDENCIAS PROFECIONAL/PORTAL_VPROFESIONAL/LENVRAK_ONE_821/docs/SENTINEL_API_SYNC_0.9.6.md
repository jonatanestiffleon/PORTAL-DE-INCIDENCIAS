# LENVRAK 0.9.6 · Sentinel conectado al backend real

Corrige la separación entre el frontend de demostración y la base de datos profesional.

## Ahora
- **Nuevo incidente** en Sentinel → `POST /api/v1/incidents` → PostgreSQL.
- Sentinel consulta `GET /api/v1/incidents`.
- Resolve AI usa `POST /api/v1/incidents/{codigo}/diagnose`.
- La simulación de Access usa `POST /api/v1/access/events`.
- El Reporte Ejecutivo consulta la misma base de datos, por lo que deja de mostrar ceros cuando existen incidentes.
- Si la API no está disponible, la interfaz conserva un modo local de respaldo para visualización.

## Después de instalar
Reconstruir solo el frontend:
```powershell
docker compose up -d --build web
```

Luego en Chrome:
`Ctrl + F5`

Crear un incidente en Sentinel y volver a ejecutar el workflow de Reporte Ejecutivo.
