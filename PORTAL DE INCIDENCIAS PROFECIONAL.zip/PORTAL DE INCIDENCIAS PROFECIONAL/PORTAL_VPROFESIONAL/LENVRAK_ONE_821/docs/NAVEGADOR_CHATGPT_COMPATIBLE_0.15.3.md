# LENVRAK 0.15.3 — Compatibilidad con navegador integrado de ChatGPT

Problema:
- En Chrome el login funciona.
- En el navegador integrado de ChatGPT la página abre, pero el acceso no completa.

Solución:
1. La API conserva la cookie HttpOnly normal.
2. Además devuelve un token de sesión firmado.
3. `/auth/me` acepta cookie o `Authorization: Bearer`.
4. El navegador guarda el token:
   - localStorage si "Mantener sesión iniciada" está marcado;
   - sessionStorage si no está marcado.
5. Un controlador de login mínimo está integrado directamente en `index.html`.
   Funciona independientemente del gran `app.js`.
6. `app.js` también envía Bearer automáticamente como respaldo.
7. Logout elimina cookie y tokens locales.

Esto mantiene compatibilidad con Chrome y añade un camino alternativo para navegadores embebidos.

Credenciales iniciales:
Usuario: admin
Contraseña: LENVRAK-2026!
