# LENVRAK One 0.10.3 · Inicio profesional con un clic

## Objetivo
Después de la configuración inicial, el usuario no necesita abrir manualmente Docker Desktop, n8n, API, Web, Update Manager ni Edge Agent.

## Instalación inicial (una sola vez)
1. Instalar la actualización 0.10.3 desde el Centro de actualizaciones.
2. Ejecutar como administrador: `scripts\windows\08_INSTALAR_INICIO_PROFESIONAL.bat`.
3. Se crean en el Escritorio:
   - **Iniciar LENVRAK One**
   - **Detener LENVRAK One**
   - **Estado LENVRAK One**

## Uso diario
Doble clic en **Iniciar LENVRAK One**.

El lanzador:
- prepara la configuración persistente de Edge;
- abre Docker Desktop solo si hace falta;
- espera a que Docker Engine esté disponible;
- ejecuta `docker compose up -d` para DB, API, Web, n8n, Sandbox y SearXNG;
- inicia Update Manager en segundo plano;
- inicia Edge Agent elevado y oculto mediante una tarea programada;
- verifica Web, API, n8n y Edge Agent;
- abre únicamente `http://127.0.0.1:8090/`.

No se muestran ventanas técnicas durante el uso normal.

## Detener
**Detener LENVRAK One** detiene los contenedores y procesos locales de LENVRAK sin eliminar datos. Docker Desktop queda disponible para otros proyectos.

## Diagnóstico
**Estado LENVRAK One** muestra Web 8090, API 8000, n8n 5678, Update Manager 8765 y Edge Agent 8780.

Logs del lanzador: `.lenvrak\launcher\launcher.log`.
