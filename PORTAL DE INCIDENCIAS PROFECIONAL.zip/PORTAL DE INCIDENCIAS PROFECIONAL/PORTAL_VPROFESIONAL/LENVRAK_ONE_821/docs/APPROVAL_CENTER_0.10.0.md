# LENVRAK 0.10.0 · Approval Center

Cierra el ciclo de acciones que requieren aprobación humana.

## Flujo
1. Resolve AI propone un runbook AMARILLO/ROJO.
2. n8n registra la ejecución como `approval_required`.
3. Sentinel muestra `esperando_aprobacion`.
4. **Autorizaciones → Solicitudes pendientes** muestra el incidente.
5. **Aprobar y continuar** ejecuta el runbook mediante Edge Agent y verifica el resultado.
6. Si la verificación pasa: `resuelto`. Si falla: `escalado`.
7. **Rechazar / escalar** cierra la espera y mueve el incidente a `escalado`.

No quedan solicitudes indefinidamente en `esperando_aprobacion` una vez que el operador decide.
