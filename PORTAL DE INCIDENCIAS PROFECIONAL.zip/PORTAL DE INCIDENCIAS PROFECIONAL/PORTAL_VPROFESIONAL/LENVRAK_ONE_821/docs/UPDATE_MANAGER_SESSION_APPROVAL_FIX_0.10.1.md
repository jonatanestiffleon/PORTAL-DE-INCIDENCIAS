# LENVRAK 0.10.1 · Approval Center + Update Manager sin token repetitivo

## Approval Center
- Hace visible la bandeja **Solicitudes pendientes** en Autorizaciones.
- `INC-1006` y cualquier ejecución `approval_required` aparecen con **Aprobar y continuar** o **Rechazar / escalar**.
- Se agrega identificador visual `APPROVAL CENTER · v0.10.1` para comprobar que el frontend nuevo está activo.
- Los assets web usan versión `?v=0.10.1` para evitar servir JavaScript antiguo desde caché.

## Update Manager 1.1
- El token aleatorio deja de cambiar en cada arranque y se guarda localmente en `.lenvrak/update_manager_token`.
- El token **no se incrusta en el frontend ni se guarda en localStorage**.
- La interfaz obtiene una sesión local mediante cookie **HttpOnly + SameSite=Strict**; en uso normal ya no se pega token.
- El campo de token queda solamente como mecanismo de recuperación manual.
- Cuando una actualización modifica `apps/api` o `apps/web`, el Update Manager intenta reconstruir automáticamente los servicios Docker afectados.
- Si una actualización cambia el propio Update Manager, indica que debe reiniciarse una vez para cargar el nuevo motor.

## Activación inicial de 0.10.1
Esta actualización se instala todavía con el Update Manager anterior. Por ello, después de instalar 0.10.1 se requiere **una última reconstrucción manual de `api web` y un único reinicio del Update Manager**. A partir de la siguiente actualización, la sesión y el redeploy son automáticos.
