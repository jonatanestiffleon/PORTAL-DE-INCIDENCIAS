# LENVRAK 0.10.6 · Detalles, autorización comprensible y alertas

## Sentinel
- Un incidente `escalado` ya no muestra **Resolver**.
- Todos los incidentes muestran **Detalles**.
- Detalles incluye diagnóstico, runbook, evidencia de ejecución/verificación, resolución o motivo de escalamiento.
- `esperando_aprobacion` muestra **Autorizar**; no vuelve a lanzar Resolve AI.

## Approval Center
Cada solicitud explica:
- qué acción exacta se autoriza;
- qué hará Edge Agent;
- cómo se verificará;
- qué NO hará;
- qué pasa si no funciona.

Ejemplo ATT-CONN-001:
Autoriza una prueba activa de conectividad a la IP registrada. No repara hardware, no cambia IP y no reinicia físicamente la terminal. Si no responde, se escala.

## Correo
El motor de alertas ya existía en 0.10.5. Para que Gmail reciba las alertas debe estar publicado en n8n:
`LENVRAK - Alertas de incidentes` (`05_incident_alerts.template.json`).

Después de publicarlo puede reenviarse una alerta existente:
POST `/api/v1/incidents/INC-1006/notify?event=escalated`.

## Estados
- `resuelto`: reparación ejecutada y verificada.
- `esperando_aprobacion`: una acción sensible está detenida a la espera de decisión humana.
- `escalado`: la automatización terminó sin solución verificable; pasa a soporte técnico/proveedor/hardware.
