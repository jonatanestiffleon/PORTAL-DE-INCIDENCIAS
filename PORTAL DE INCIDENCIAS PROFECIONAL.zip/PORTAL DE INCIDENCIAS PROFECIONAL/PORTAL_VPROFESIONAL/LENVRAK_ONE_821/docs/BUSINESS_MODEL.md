# Modelo comercial
Módulos:
- Access: asistencia.
- Sentinel: incidentes.
- Edge: telemetría.
- Resolve AI: diagnóstico.
- Automate: n8n.
- Network Lab: redes.
- Operator: asistencia sobre software.
- Economics: impacto económico.
- Procurement: proveedores y cotizaciones.
- Leo: asistente.

Modelo sugerido: suscripción por organización + capacidad + analistas + módulos + integraciones.
Los precios deben validarse con costos reales de nube, soporte, impuestos, mensajería y mercado antes de vender.
