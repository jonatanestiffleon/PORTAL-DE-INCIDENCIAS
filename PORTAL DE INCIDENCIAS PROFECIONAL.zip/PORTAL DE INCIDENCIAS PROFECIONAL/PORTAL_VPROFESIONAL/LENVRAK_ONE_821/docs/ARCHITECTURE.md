# Arquitectura LENVRAK One

```text
                         Usuarios
                            |
                  Namecheap (dominio)
                            |
                     Cloudflare
              DNS / TLS / WAF / Access
                            |
             +--------------+--------------+
             |                             |
          Web/PWA                        API
             |                             |
             +--------- LENVRAK CORE ------+
                       /    |    \
                  Sentinel  |   Network Lab
                    Edge  Resolve  Operator
                      \      |      /
                         n8n
                       Automate
                          |
          +---------------+----------------+
          |               |                |
       AWS SSM          Gmail           Procurement
          |                                |
     equipos/nodos                   técnicos/proveedores

Access (sistema escolar) --> API de eventos --> Sentinel
Economics <--- incidentes + tiempos + costos + cotizaciones
Reports   <--- técnico / TI / administración / gerencia / dueño
```

## Principio
Sentinel sigue siendo el **Portal de Reporte de Incidentes**. Los demás módulos amplían su valor comercial.
