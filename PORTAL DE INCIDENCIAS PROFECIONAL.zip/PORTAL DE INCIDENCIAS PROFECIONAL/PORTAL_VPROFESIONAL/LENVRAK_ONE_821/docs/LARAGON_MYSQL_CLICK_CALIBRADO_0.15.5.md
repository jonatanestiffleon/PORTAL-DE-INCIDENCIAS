# LENVRAK 0.15.5 — Click MySQL calibrado para Laragon 2026 v8.7.0

Corrige el clic nativo de 0.15.4 que quedaba demasiado a la derecha.

Calibración:
- X ≈ 13.0 % del ancho del área cliente de Laragon.
- Y ≈ 28.7 % de la altura del área cliente.
- Se prueban tres posiciones muy cercanas.
- Después de cada clic se verifica TCP 3306.
- Si 3306 abre, el helper devuelve MYSQL_NATIVE_CLICK_OK.
- Si no abre, devuelve error sin dejar la petición bloqueada durante tanto tiempo.

No se usan coordenadas absolutas de pantalla.
