# LENVRAK 0.11.4 · Acciones sin redundancia

Corrige la columna **Acción** de Sentinel.

Antes:
- Estado: Resuelto | Acción: Resuelto
- Estado: Escalado | Acción: Escalado

Ahora:
- Detectado / diagnosticable → Resolver | Detalles | Enviar reporte
- Esperando aprobación → Autorizar | Detalles | Enviar reporte
- Procesando / esperando agente → Ver proceso | Detalles | Enviar reporte
- Resuelto → Detalles | Enviar reporte
- Escalado → Detalles | Enviar reporte

Principio:
- **Estado** informa la condición actual.
- **Acción** muestra únicamente lo que el usuario puede hacer.
