# LENVRAK 0.15.1 — Fix del botón de login

Corrige un error de sintaxis JavaScript introducido en 0.15.0 por un fragmento duplicado
del login anterior.

Síntoma:
- La pantalla de login aparece.
- Al pulsar "Entrar a LENVRAK" no ocurre nada.

Corrección:
- Se elimina el fragmento duplicado.
- Se valida `app.js` con `node --check`.
- El botón muestra "Ingresando..." mientras la API valida las credenciales.
- Se mantienen sesión persistente, restauración automática y logout explícito.

Credenciales iniciales:
- Usuario: admin
- Contraseña: LENVRAK-2026!
