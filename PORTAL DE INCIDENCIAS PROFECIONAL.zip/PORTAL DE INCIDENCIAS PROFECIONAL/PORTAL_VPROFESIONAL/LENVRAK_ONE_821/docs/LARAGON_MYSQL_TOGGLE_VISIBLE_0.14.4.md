# LENVRAK 0.14.4 — MySQL Toggle visible en Laragon 2026

Corrige `START_ALL_BUTTON_NOT_EXPOSED`.

Laragon 2026 v8.7 usa interruptores por servicio (Apache / MySQL / Mailpit), no un botón
automatizable `Start All`.

Nuevo flujo:
1. Laragon Desktop Helper localiza un AutomationElement cuyo nombre contenga `MySQL`.
2. Intenta TogglePattern / InvokePattern.
3. Si MySQL no expone patrón, busca un control inmediatamente a la izquierda en la misma fila.
4. Si tampoco lo expone, hace un clic RELATIVO al BoundingRectangle de la etiqueta MySQL.
   No usa coordenadas absolutas de pantalla.
5. Edge espera y verifica TCP 3306.
6. Solo si 3306 responde se marca RESUELTO.

El helper continúa limitado a 127.0.0.1:8790 y protegido por EDGE_AGENT_TOKEN.
