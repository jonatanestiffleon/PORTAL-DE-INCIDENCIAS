# LENVRAK 0.13.0 · Multiinstitución + monitoreo real

Esta actualización es acumulativa: incluye TODO lo de 0.12.0.
No instale 0.12.0 primero.

## Multiinstitución
Puede registrar múltiples clientes:
- colegios
- empresas
- universidades
- instituciones

Cada institución puede tener cantidad ilimitada de dispositivos:
- huelleros
- lectores QR
- terminales biométricas

Jerarquía:
Institución → Sede → Área → Puerta/Ubicación → Dispositivo

## Ejemplo
Colegio A:
- HUELLA-ENTRADA-01
- HUELLA-ENTRADA-02
- QR-SECUNDARIA-01

Colegio B:
- HUELLA-PUERTA-01
- HUELLA-PUERTA-02
- HUELLA-PUERTA-03
- ...

## Pruebas reales
MySQL:
- preset TCP 127.0.0.1:3306
- detener MySQL en Laragon
- LENVRAK debe detectar la caída y crear incidente.

GNS3:
- preset HTTP 127.0.0.1:3080/v2/version
- cerrar GNS3 Controller/Server
- LENVRAK debe detectar la caída y crear incidente.

No se recomienda corromper configuraciones o bases de datos para demostrar fallas.
