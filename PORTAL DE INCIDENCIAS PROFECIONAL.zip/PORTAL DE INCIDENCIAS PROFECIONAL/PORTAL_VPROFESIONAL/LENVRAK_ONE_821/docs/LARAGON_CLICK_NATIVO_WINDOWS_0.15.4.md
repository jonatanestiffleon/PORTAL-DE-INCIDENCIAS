# LENVRAK 0.15.4 — Laragon click nativo de Windows

Corrige definitivamente el bloqueo `MYSQL_UI_TARGET_NOT_FOUND`.

La interfaz de Laragon 2026 no expone los interruptores MySQL a UI Automation.
La nueva estrategia NO intenta descubrir controles internos.

Flujo:
1. El Helper enumera las ventanas visibles de Windows.
2. Selecciona la ventana Laragon visible con mayor área.
3. Obtiene el CLIENT RECT de esa ventana.
4. Calcula la posición del interruptor MySQL como porcentaje del tamaño de Laragon.
5. Hace clic dentro de la ventana Laragon.
6. El Helper verifica TCP 3306 durante hasta 12 s.
7. Solo devuelve éxito si 3306 realmente abre.
8. Edge vuelve a verificar antes de marcar RESUELTO.

No usa coordenadas absolutas del escritorio y no inicia mysqld.exe directamente.

Esta actualización está pensada para Laragon 2026 v8.7.x con el diseño de filas:
Apache / MySQL / Mailpit.
