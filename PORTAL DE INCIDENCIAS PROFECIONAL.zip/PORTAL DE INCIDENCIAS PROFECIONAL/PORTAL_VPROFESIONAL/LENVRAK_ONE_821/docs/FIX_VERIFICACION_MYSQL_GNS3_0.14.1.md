# LENVRAK 0.14.1 — Fix de verificación MySQL/GNS3

Corrige el caso observado en INC-1017:

- MYSQL-LARAGON-001 ejecutó correctamente y levantó mysqld.
- El verificador devolvía `Runbook no permitido: MYSQL-LARAGON-001`.
- El incidente terminaba en `verification_failed / escalado` aunque TCP 3306 ya estuviera operativo.

La 0.14.1 añade verificación explícita para:
- MYSQL-LARAGON-001 → TCP 127.0.0.1:3306
- GNS3-CTRL-001 → HTTP 127.0.0.1:3080/v2/version
- WIN-SVC-RESTART-001 → servicio Windows Running

MySQL y GNS3 usan varios reintentos para tolerar unos segundos de arranque.

Después de instalar y reiniciar Edge Agent, la ejecución 32 de INC-1017 se puede volver a verificar con:
POST /api/v1/runbooks/32/verify
Si 3306 está abierto, debe pasar a RESUELTO.
