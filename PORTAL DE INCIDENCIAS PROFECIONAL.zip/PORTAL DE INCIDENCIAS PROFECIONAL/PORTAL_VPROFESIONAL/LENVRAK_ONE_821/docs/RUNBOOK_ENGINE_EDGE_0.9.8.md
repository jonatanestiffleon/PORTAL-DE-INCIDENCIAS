# LENVRAK 0.9.8 · Runbook Engine + Edge Agent

Esta versión cierra la brecha entre **diagnosticar** y **resolver**.

## Regla de seguridad
LENVRAK no marca un incidente como resuelto por el solo hecho de generar un diagnóstico.

Flujo:

1. Sentinel registra el incidente.
2. Resolve AI propone diagnóstico, runbook y riesgo.
3. n8n decide si requiere aprobación.
4. Runbook Engine valida que el runbook esté en lista permitida.
5. Edge Agent ejecuta la acción local permitida.
6. Edge Agent verifica el resultado.
7. Solo con verificación positiva el incidente pasa a `resuelto`.
8. Si falla ejecución/verificación, pasa a `escalado` o `esperando_agente`.

## Runbooks iniciales

- `PRN-SVC-001` · VERDE · Reinicia Print Spooler y verifica que quede `Running`.
- `ATT-CONN-001` · AMARILLO · Verificación de conectividad de terminal cuando existe `evidence.ip`.
- `DIAG-GENERAL-001` · VERDE · Recolección diagnóstica; **no cierra automáticamente** el incidente.

## Instalación

Después de instalar la actualización y reconstruir la API:

```powershell
docker compose up -d --build api
```

Ejecutar como administrador:

```text
scripts\windows\07_CONFIGURAR_EDGE_AGENT.bat
```

Dejar la ventana del Edge Agent abierta durante la prueba.

## Comprobación

Desde PowerShell:

```powershell
Invoke-RestMethod http://127.0.0.1:8000/api/v1/runbooks/agent-health
```

Debe devolver `ok: true`, `state: online` y `administrator: true`.

## Nota de alcance
`PRN-SVC-001` actúa sobre el servicio Print Spooler del equipo Windows donde se ejecuta Edge Agent. En despliegues multi-equipo debe instalarse un agente por endpoint o usar un gateway/gestor remoto autorizado.
