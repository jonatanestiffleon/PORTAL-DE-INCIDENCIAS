# LENVRAK 0.16.0 — Helper con pythonw.exe

Problema:
La tarea `LENVRAK Laragon Helper` devolvía LastTaskResult=2147946720
(0x800710E0 / ERROR_REQUEST_REFUSED).

Solución:
- Laragon Helper deja de depender del Programador de tareas.
- `Iniciar LENVRAK One` busca `pythonw.exe` del mismo Python instalado.
- Limpia helpers viejos.
- Inicia exactamente una instancia del helper sin consola visible.
- Espera hasta 15 s por 127.0.0.1:8790.
- Guarda el PID.
- `Detener LENVRAK One` termina python/pythonw del helper.
- La tarea programada antigua del Helper se elimina en la reinstalación.

Edge Agent continúa usando su tarea programada porque ya funciona correctamente.

Resultado esperado:
un doble clic en `Iniciar LENVRAK One` -> 6/6 ONLINE sin PowerShell visibles.
